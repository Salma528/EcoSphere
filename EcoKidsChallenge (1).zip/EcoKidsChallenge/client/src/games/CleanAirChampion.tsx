import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useAudio } from "../lib/stores/useAudio";
import CharacterGuide from "../components/CharacterGuide";

interface PollutionSource {
  id: string;
  type: "factory" | "car" | "deforestation" | "powerplant";
  name: string;
  emoji: string;
  position: {
    x: number;
    y: number;
  };
  pollution: number; // 0-100
  active: boolean;
}

interface Solution {
  id: string;
  type: "tree" | "renewable" | "electricCar" | "filter";
  name: string;
  emoji: string;
  counters: ("factory" | "car" | "deforestation" | "powerplant")[];
  used: boolean;
  position: {
    x: number;
    y: number;
  };
}

interface CleanAirChampionProps {
  onComplete: (score: number) => void;
  onScoreChange: (score: number) => void;
}

const CleanAirChampion: React.FC<CleanAirChampionProps> = ({ onComplete, onScoreChange }) => {
  const [score, setScore] = useState(0);
  const [gameStarted, setGameStarted] = useState(false);
  const [pollutionSources, setPollutionSources] = useState<PollutionSource[]>([]);
  const [solutions, setSolutions] = useState<Solution[]>([]);
  const [airQuality, setAirQuality] = useState(50); // 0-100, where 100 is perfect
  const [timer, setTimer] = useState(60);
  const [message, setMessage] = useState<string | null>(null);
  const [selectedSolution, setSelectedSolution] = useState<string | null>(null);
  const [showInfo, setShowInfo] = useState<{ type: "solution" | "source", id: string } | null>(null);
  
  const gameAreaRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const pollutionIntervalRef = useRef<NodeJS.Timeout | null>(null);
  
  const { playHit, playSuccess } = useAudio();
  
  // Source data
  const sourceData: Omit<PollutionSource, "position" | "pollution" | "active">[] = [
    {
      id: "source-1",
      type: "factory",
      name: "Factory",
      emoji: "🏭"
    },
    {
      id: "source-2",
      type: "car",
      name: "Gas Car",
      emoji: "🚗"
    },
    {
      id: "source-3",
      type: "deforestation",
      name: "Deforestation",
      emoji: "🪓"
    },
    {
      id: "source-4",
      type: "powerplant",
      name: "Coal Power Plant",
      emoji: "🔥"
    }
  ];
  
  // Solution data
  const solutionData: Omit<Solution, "position" | "used">[] = [
    {
      id: "solution-1",
      type: "tree",
      name: "Plant Trees",
      emoji: "🌳",
      counters: ["factory", "deforestation"]
    },
    {
      id: "solution-2",
      type: "renewable",
      name: "Solar Power",
      emoji: "☀️",
      counters: ["powerplant"]
    },
    {
      id: "solution-3",
      type: "electricCar",
      name: "Electric Vehicle",
      emoji: "🚙",
      counters: ["car"]
    },
    {
      id: "solution-4",
      type: "filter",
      name: "Air Filter",
      emoji: "🔬",
      counters: ["factory", "powerplant"]
    }
  ];
  
  // Start the game
  const handleStart = () => {
    setGameStarted(true);
    initializeGame();
    
    // Start timer
    timerRef.current = setInterval(() => {
      setTimer(prev => {
        if (prev <= 1) {
          // End game
          endGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    // Start pollution increase
    pollutionIntervalRef.current = setInterval(() => {
      increasePollution();
    }, 3000);
  };
  
  // Initialize the game
  const initializeGame = () => {
    if (!gameAreaRef.current) return;
    
    const gameArea = gameAreaRef.current.getBoundingClientRect();
    
    // Position pollution sources around the city
    const positionedSources: PollutionSource[] = sourceData.map((source, index) => {
      const angleStep = (2 * Math.PI) / sourceData.length;
      const angle = angleStep * index;
      const radius = Math.min(gameArea.width, gameArea.height) * 0.3;
      
      return {
        ...source,
        position: {
          x: gameArea.width / 2 + radius * Math.cos(angle),
          y: gameArea.height / 2 + radius * Math.sin(angle)
        },
        pollution: 50,
        active: true
      };
    });
    
    setPollutionSources(positionedSources);
    
    // Position solutions at bottom of screen
    const positionedSolutions: Solution[] = solutionData.map((solution, index) => {
      const width = gameArea.width / (solutionData.length + 1);
      
      return {
        ...solution,
        position: {
          x: width * (index + 1),
          y: gameArea.height - 80
        },
        used: false
      };
    });
    
    setSolutions(positionedSolutions);
  };
  
  // Increase pollution from active sources
  const increasePollution = () => {
    setPollutionSources(prev => {
      const updated = prev.map(source => {
        if (source.active) {
          return {
            ...source,
            pollution: Math.min(100, source.pollution + 5)
          };
        }
        return source;
      });
      
      // Calculate overall air quality
      const totalPollution = updated.reduce((sum, source) => sum + source.pollution, 0);
      const avgPollution = totalPollution / (updated.length * 100) * 100;
      const newAirQuality = 100 - avgPollution;
      
      setAirQuality(newAirQuality);
      
      // Award points for keeping air clean
      if (newAirQuality > 75) {
        const pointsEarned = 5;
        setScore(prevScore => {
          const newScore = prevScore + pointsEarned;
          onScoreChange(newScore);
          return newScore;
        });
      }
      
      return updated;
    });
  };
  
  // End the game
  const endGame = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (pollutionIntervalRef.current) clearInterval(pollutionIntervalRef.current);
    
    // Bonus points based on air quality
    const airQualityBonus = Math.floor(airQuality * 2);
    
    setScore(prevScore => {
      const newScore = prevScore + airQualityBonus;
      onScoreChange(newScore);
      return newScore;
    });
    
    setMessage(`Game Over! Air Quality Bonus: +${airQualityBonus} points!`);
    setTimeout(() => {
      onComplete(score + airQualityBonus);
    }, 2000);
  };
  
  // Handle selecting a solution
  const handleSelectSolution = (solutionId: string) => {
    const solution = solutions.find(s => s.id === solutionId);
    if (!solution || solution.used) return;
    
    setSelectedSolution(solutionId);
    setMessage(`Selected: ${solution.name}. Click on a pollution source to use it!`);
  };
  
  // Handle using a solution on a pollution source
  const handleUseSolution = (sourceId: string) => {
    if (!selectedSolution) return;
    
    const solution = solutions.find(s => s.id === selectedSolution);
    const source = pollutionSources.find(src => src.id === sourceId);
    
    if (!solution || !source) return;
    
    // Check if solution counters this source type
    if (solution.counters.includes(source.type)) {
      // Effective solution
      const pollutionReduction = 30;
      const pointsEarned = 20;
      
      setPollutionSources(prev => 
        prev.map(src => 
          src.id === sourceId ? {
            ...src,
            pollution: Math.max(0, src.pollution - pollutionReduction),
            active: false // Temporarily deactivate the source
          } : src
        )
      );
      
      // Mark solution as used
      setSolutions(prev => 
        prev.map(sol => 
          sol.id === selectedSolution ? {
            ...sol,
            used: true
          } : sol
        )
      );
      
      // Award points
      setScore(prevScore => {
        const newScore = prevScore + pointsEarned;
        onScoreChange(newScore);
        return newScore;
      });
      
      playSuccess();
      setMessage(`+${pointsEarned} points! ${solution.name} reduced pollution from ${source.name}!`);
      
      // Reactivate source after some time
      setTimeout(() => {
        setPollutionSources(prev => 
          prev.map(src => 
            src.id === sourceId ? {
              ...src,
              active: true
            } : src
          )
        );
      }, 10000);
    } else {
      // Ineffective solution
      playHit();
      setMessage(`${solution.name} isn't effective against ${source.name}. Try a different solution!`);
    }
    
    setSelectedSolution(null);
    setTimeout(() => setMessage(null), 2000);
  };
  
  // Show info about a solution or source
  const handleInfoClick = (type: "solution" | "source", id: string) => {
    setShowInfo({ type, id });
  };
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (pollutionIntervalRef.current) clearInterval(pollutionIntervalRef.current);
    };
  }, []);

  return (
    <div className="h-full w-full relative overflow-hidden">
      {/* Game background */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-100 to-blue-300"></div>
      
      {!gameStarted ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl p-6 shadow-lg max-w-md text-center"
          >
            <h2 className="text-2xl font-bold text-blue-700 mb-3">Clean Air Champion</h2>
            <p className="text-gray-700 mb-4">
              Help reduce air pollution by using eco-friendly solutions! Keep the air clean for everyone.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-blue-500 text-white font-bold py-3 px-8 rounded-full"
              onClick={handleStart}
            >
              Start Cleaning!
            </motion.button>
          </motion.div>
          
          <div className="absolute bottom-10 left-10">
            <CharacterGuide text="Clean air is important for all living things! Let's find ways to reduce pollution." />
          </div>
        </div>
      ) : (
        <div className="h-full w-full relative" ref={gameAreaRef}>
          {/* Game UI */}
          <div className="absolute top-4 left-4 bg-white/80 backdrop-blur-sm rounded-lg p-3 shadow flex space-x-4">
            <div>
              <div className="text-xs text-gray-500">Score</div>
              <div className="text-2xl font-bold text-blue-700">{score}</div>
            </div>
            <div>
              <div className="text-xs text-gray-500">Time</div>
              <div className={`text-2xl font-bold ${timer <= 10 ? 'text-red-500' : 'text-blue-600'}`}>
                {timer}s
              </div>
            </div>
          </div>
          
          {/* Air quality indicator */}
          <div className="absolute top-4 right-4 bg-white/80 backdrop-blur-sm rounded-lg p-3 shadow">
            <div className="text-xs text-gray-500 mb-1">Air Quality</div>
            <div className="w-32 h-4 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className={`h-full ${
                  airQuality > 66 ? 'bg-green-500' : 
                  airQuality > 33 ? 'bg-yellow-500' : 
                  'bg-red-500'
                }`}
                style={{ width: `${airQuality}%` }}
              />
            </div>
            <div className="text-xs text-right mt-1">
              {airQuality < 33 ? 'Poor' : airQuality < 66 ? 'Moderate' : 'Good'}
            </div>
          </div>
          
          {/* Message */}
          {message && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="absolute top-16 left-1/2 transform -translate-x-1/2 py-2 px-4 rounded-lg bg-blue-100 text-blue-800"
            >
              {message}
            </motion.div>
          )}
          
          {/* City center */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <div className="relative">
              {/* City buildings */}
              <div className="w-60 h-60 rounded-full bg-gray-200 flex items-center justify-center">
                <div className="flex flex-wrap justify-center items-center">
                  <div className="w-10 h-20 bg-gray-400 mx-1"></div>
                  <div className="w-10 h-30 bg-gray-500 mx-1"></div>
                  <div className="w-10 h-24 bg-gray-600 mx-1"></div>
                  <div className="w-10 h-16 bg-gray-700 mx-1"></div>
                  <div className="w-10 h-28 bg-gray-500 mx-1"></div>
                </div>
              </div>
              
              {/* Air quality visualization */}
              <div 
                className={`absolute inset-0 rounded-full ${
                  airQuality > 66 ? 'bg-green-500/20' : 
                  airQuality > 33 ? 'bg-yellow-500/30' : 
                  'bg-red-500/40'
                }`}
              ></div>
            </div>
          </div>
          
          {/* Pollution sources */}
          {pollutionSources.map(source => (
            <div
              key={source.id}
              className="absolute"
              style={{ 
                left: source.position.x - 40, 
                top: source.position.y - 40 
              }}
            >
              <motion.div
                className={`relative bg-white/70 backdrop-blur-sm rounded-lg p-3 shadow-md cursor-pointer ${
                  source.active ? 'opacity-100' : 'opacity-50'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => selectedSolution ? handleUseSolution(source.id) : handleInfoClick("source", source.id)}
              >
                <div className="flex flex-col items-center">
                  <div className="text-4xl mb-2">{source.emoji}</div>
                  <div className="text-sm font-semibold">{source.name}</div>
                </div>
                
                {/* Pollution visualization */}
                <motion.div
                  className="absolute -top-2 -right-2 left-0 rounded-full bg-gray-800/40"
                  style={{ 
                    height: `${source.pollution / 2}px`,
                    width: `${source.pollution / 2}px`,
                  }}
                  animate={{
                    scale: [1, 1.1, 1],
                    opacity: [0.4, 0.3, 0.4]
                  }}
                  transition={{ repeat: Infinity, duration: 2 }}
                ></motion.div>
              </motion.div>
            </div>
          ))}
          
          {/* Solutions */}
          <div className="absolute bottom-4 left-4 right-4 bg-white/80 backdrop-blur-sm rounded-lg p-3 shadow">
            <h3 className="font-semibold text-blue-800 mb-2">Clean Air Solutions</h3>
            <div className="flex justify-around">
              {solutions.map(solution => (
                <motion.div
                  key={solution.id}
                  whileHover={!solution.used ? { scale: 1.05 } : {}}
                  whileTap={!solution.used ? { scale: 0.95 } : {}}
                  className={`px-3 py-2 rounded-lg cursor-pointer flex flex-col items-center ${
                    solution.used ? 'opacity-50 cursor-not-allowed' : 
                    selectedSolution === solution.id ? 'bg-blue-500 text-white' : 
                    'bg-blue-100 text-blue-800'
                  }`}
                  onClick={() => !solution.used && handleSelectSolution(solution.id)}
                >
                  <span className="text-2xl mb-1">{solution.emoji}</span>
                  <span className="text-xs font-medium">{solution.name}</span>
                  
                  {/* Info button */}
                  {!solution.used && (
                    <button
                      className="mt-1 w-5 h-5 bg-gray-200 rounded-full text-xs flex items-center justify-center text-gray-600"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleInfoClick("solution", solution.id);
                      }}
                    >
                      i
                    </button>
                  )}
                </motion.div>
              ))}
            </div>
          </div>
          
          {/* Info popup */}
          {showInfo && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-xl p-4 shadow-xl max-w-sm"
            >
              {showInfo.type === "solution" && (() => {
                const solution = solutions.find(s => s.id === showInfo.id);
                if (!solution) return null;
                return (
                  <>
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-xl font-bold text-blue-700">{solution.name}</h3>
                      <button 
                        className="text-gray-500 hover:text-gray-700"
                        onClick={() => setShowInfo(null)}
                      >
                        ✕
                      </button>
                    </div>
                    
                    <div className="flex items-center justify-center my-3">
                      <span className="text-6xl">{solution.emoji}</span>
                    </div>
                    
                    <div className="mb-3">
                      <p className="text-gray-700">
                        {solution.type === "tree" && "Trees absorb carbon dioxide and release oxygen, helping clean the air naturally."}
                        {solution.type === "renewable" && "Solar power generates electricity without releasing pollutants into the air."}
                        {solution.type === "electricCar" && "Electric vehicles don't emit exhaust gases, keeping our air cleaner."}
                        {solution.type === "filter" && "Air filters can capture pollutants before they enter the atmosphere."}
                      </p>
                    </div>
                    
                    <div className="mb-3">
                      <h4 className="font-semibold text-gray-700 mb-1">Effective Against:</h4>
                      <div className="flex flex-wrap gap-2">
                        {solution.counters.map(counter => (
                          <div key={counter} className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                            {counter === "factory" && "Factory"}
                            {counter === "car" && "Gas Car"}
                            {counter === "deforestation" && "Deforestation"}
                            {counter === "powerplant" && "Coal Power Plant"}
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex justify-end">
                      <button 
                        className="bg-blue-100 text-blue-800 px-3 py-1 rounded-lg text-sm font-medium"
                        onClick={() => setShowInfo(null)}
                      >
                        Close
                      </button>
                    </div>
                  </>
                );
              })()}
              
              {showInfo.type === "source" && (() => {
                const source = pollutionSources.find(s => s.id === showInfo.id);
                if (!source) return null;
                return (
                  <>
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-xl font-bold text-red-700">{source.name}</h3>
                      <button 
                        className="text-gray-500 hover:text-gray-700"
                        onClick={() => setShowInfo(null)}
                      >
                        ✕
                      </button>
                    </div>
                    
                    <div className="flex items-center justify-center my-3">
                      <span className="text-6xl">{source.emoji}</span>
                    </div>
                    
                    <div className="mb-3">
                      <p className="text-gray-700">
                        {source.type === "factory" && "Factories can release smoke and chemicals into the air, causing pollution."}
                        {source.type === "car" && "Gas-powered cars emit exhaust gases that contribute to smog and air pollution."}
                        {source.type === "deforestation" && "Cutting down trees reduces the Earth's ability to clean the air naturally."}
                        {source.type === "powerplant" && "Coal power plants release a lot of carbon dioxide and other pollutants."}
                      </p>
                    </div>
                    
                    <div className="mb-3">
                      <h4 className="font-semibold text-gray-700 mb-1">Current Pollution Level:</h4>
                      <div className="w-full h-4 bg-gray-200 rounded-full overflow-hidden">
                        <div 
                          className={`h-full ${
                            source.pollution < 33 ? 'bg-green-500' : 
                            source.pollution < 66 ? 'bg-yellow-500' : 
                            'bg-red-500'
                          }`}
                          style={{ width: `${source.pollution}%` }}
                        />
                      </div>
                    </div>
                    
                    <div className="flex justify-end">
                      <button 
                        className="bg-blue-100 text-blue-800 px-3 py-1 rounded-lg text-sm font-medium"
                        onClick={() => setShowInfo(null)}
                      >
                        Close
                      </button>
                    </div>
                  </>
                );
              })()}
            </motion.div>
          )}
          
          {/* Terra character with tips */}
          <div className="absolute top-16 right-4">
            <CharacterGuide 
              text="Select a solution and click on a pollution source to use it! Different solutions work on different types of pollution."
              position="right"
              size="small"
              autoHide={true}
              hideDelay={8000}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default CleanAirChampion;
