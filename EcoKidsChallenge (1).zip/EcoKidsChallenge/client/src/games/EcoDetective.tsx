import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useAudio } from "../lib/stores/useAudio";
import CharacterGuide from "../components/CharacterGuide";

interface EcoMystery {
  id: string;
  title: string;
  description: string;
  location: string;
  clues: EcoClue[];
  solution: string;
  fact: string;
  solved: boolean;
}

interface EcoClue {
  id: string;
  text: string;
  hint: string;
  found: boolean;
  position: {
    x: number;
    y: number;
  };
}

interface EnvironmentalProblem {
  id: string;
  type: "pollution" | "waste" | "habitat" | "water";
  description: string;
  fixed: boolean;
  position: {
    x: number;
    y: number;
  };
}

interface EcoDetectiveProps {
  onComplete: (score: number) => void;
  onScoreChange: (score: number) => void;
}

const EcoDetective: React.FC<EcoDetectiveProps> = ({ onComplete, onScoreChange }) => {
  const [score, setScore] = useState(0);
  const [gameStarted, setGameStarted] = useState(false);
  const [currentLevel, setCurrentLevel] = useState(1);
  const [mysteries, setMysteries] = useState<EcoMystery[]>([]);
  const [activeMystery, setActiveMystery] = useState<string | null>(null);
  const [problems, setProblems] = useState<EnvironmentalProblem[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [foundClueCount, setFoundClueCount] = useState(0);
  const [fixedProblemCount, setFixedProblemCount] = useState(0);
  const [showSolution, setShowSolution] = useState(false);
  const [timeLeft, setTimeLeft] = useState(120); // 2 minutes per level
  
  const gameAreaRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  const { playHit, playSuccess } = useAudio();
  
  // Mystery data
  const mysteryData: Omit<EcoMystery, "solved">[] = [
    {
      id: "mystery-1",
      title: "The Missing Fish",
      description: "The lake's fish population has decreased dramatically. What's causing this?",
      location: "Lake Clearwater",
      clues: [
        {
          id: "clue-1-1",
          text: "Factory discharge pipe near the lake",
          hint: "Check what's flowing into the water",
          found: false,
          position: { x: 150, y: 200 }
        },
        {
          id: "clue-1-2",
          text: "Chemical residue on lake shore",
          hint: "Look closely at the water's edge",
          found: false,
          position: { x: 300, y: 350 }
        },
        {
          id: "clue-1-3",
          text: "pH testing results show acidic water",
          hint: "Science equipment might help",
          found: false,
          position: { x: 450, y: 180 }
        }
      ],
      solution: "Water pollution from the factory is making the lake too acidic for fish to survive",
      fact: "Factory waste can change water pH levels, making it uninhabitable for many aquatic species"
    },
    {
      id: "mystery-2",
      title: "The Vanishing Bees",
      description: "Local farms are reporting fewer bees pollinating their crops. What's happening?",
      location: "Meadow Valley Farms",
      clues: [
        {
          id: "clue-2-1",
          text: "Empty pesticide containers",
          hint: "What are farmers spraying?",
          found: false,
          position: { x: 200, y: 150 }
        },
        {
          id: "clue-2-2",
          text: "Few wildflowers in the area",
          hint: "What do bees need to eat?",
          found: false,
          position: { x: 350, y: 250 }
        },
        {
          id: "clue-2-3",
          text: "New monoculture farming technique guide",
          hint: "Check the farm office",
          found: false,
          position: { x: 500, y: 300 }
        }
      ],
      solution: "The combination of pesticides and lack of diverse flowers is harming the bee population",
      fact: "Bees pollinate approximately 35% of the world's food crops and are essential for our food supply"
    },
    {
      id: "mystery-3",
      title: "The Sick Birds",
      description: "Many birds in the park have become ill. What could be the cause?",
      location: "Greenleaf Park",
      clues: [
        {
          id: "clue-3-1",
          text: "Plastic pieces in bird nests",
          hint: "Look up in the trees",
          found: false,
          position: { x: 180, y: 220 }
        },
        {
          id: "clue-3-2",
          text: "Overflowing trash bins",
          hint: "Check the picnic areas",
          found: false,
          position: { x: 320, y: 180 }
        },
        {
          id: "clue-3-3",
          text: "Bird with plastic ring stuck around its neck",
          hint: "Observe the birds carefully",
          found: false,
          position: { x: 470, y: 250 }
        }
      ],
      solution: "Birds are ingesting and getting tangled in plastic waste that visitors leave in the park",
      fact: "Over 1 million seabirds die each year from plastic ingestion or entanglement"
    }
  ];
  
  // Environmental problem data
  const problemData: Omit<EnvironmentalProblem, "fixed" | "position">[] = [
    {
      id: "problem-1",
      type: "pollution",
      description: "Smoke-belching factory without filters"
    },
    {
      id: "problem-2",
      type: "waste",
      description: "Overflowing garbage bins without recycling separation"
    },
    {
      id: "problem-3",
      type: "habitat",
      description: "Construction site destroying animal homes"
    },
    {
      id: "problem-4",
      type: "water",
      description: "Oil spill in the river"
    },
    {
      id: "problem-5",
      type: "pollution",
      description: "Cars with excessive exhaust emissions"
    },
    {
      id: "problem-6",
      type: "waste",
      description: "Plastic litter scattered across the beach"
    }
  ];
  
  // Start the game
  const handleStart = () => {
    setGameStarted(true);
    loadLevel(1);
    
    // Start timer
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          // Time's up for this level, move to next or end game
          if (currentLevel < 3) {
            loadLevel(currentLevel + 1);
            return 120; // Reset timer for next level
          } else {
            endGame();
            return 0;
          }
        }
        return prev - 1;
      });
    }, 1000);
  };
  
  // Load a level
  const loadLevel = (levelNum: number) => {
    setCurrentLevel(levelNum);
    setFoundClueCount(0);
    setFixedProblemCount(0);
    setShowSolution(false);
    setMessage(`Level ${levelNum}: Solve the eco-mystery!`);
    setTimeout(() => setMessage(null), 2000);
    
    // Set the active mystery based on level
    const mystery = { ...mysteryData[levelNum - 1], solved: false };
    
    // Randomize clue positions
    if (gameAreaRef.current) {
      const rect = gameAreaRef.current.getBoundingClientRect();
      const padding = 80; // Keep clues away from edges
      
      mystery.clues = mystery.clues.map(clue => ({
        ...clue,
        position: {
          x: padding + Math.random() * (rect.width - padding * 2),
          y: padding + Math.random() * (rect.height - padding * 2)
        }
      }));
    }
    
    setMysteries([mystery]);
    setActiveMystery(mystery.id);
    
    // Set environmental problems
    if (gameAreaRef.current) {
      const rect = gameAreaRef.current.getBoundingClientRect();
      const padding = 80;
      
      // Select problems based on level (more problems in higher levels)
      const problemCount = 2 + levelNum;
      const shuffledProblems = [...problemData].sort(() => Math.random() - 0.5).slice(0, problemCount);
      
      const positionedProblems = shuffledProblems.map(problem => ({
        ...problem,
        fixed: false,
        position: {
          x: padding + Math.random() * (rect.width - padding * 2),
          y: padding + Math.random() * (rect.height - padding * 2)
        }
      }));
      
      setProblems(positionedProblems);
    }
  };
  
  // Handle finding a clue
  const handleFindClue = (mysteryId: string, clueId: string) => {
    setMysteries(prevMysteries => {
      return prevMysteries.map(mystery => {
        if (mystery.id === mysteryId) {
          const updatedClues = mystery.clues.map(clue => 
            clue.id === clueId ? { ...clue, found: true } : clue
          );
          
          // Award points for finding a clue
          const pointsEarned = 20;
          setScore(prevScore => {
            const newScore = prevScore + pointsEarned;
            onScoreChange(newScore);
            return newScore;
          });
          
          setFoundClueCount(prev => prev + 1);
          
          playSuccess();
          setMessage(`Clue found! +${pointsEarned} points`);
          setTimeout(() => setMessage(null), 1500);
          
          // Check if all clues are found
          if (updatedClues.every(c => c.found)) {
            setTimeout(() => {
              setShowSolution(true);
              
              // Bonus for finding all clues
              const bonusPoints = 50;
              setScore(prevScore => {
                const newScore = prevScore + bonusPoints;
                onScoreChange(newScore);
                return newScore;
              });
              
              setMessage(`All clues found! Mystery solved! +${bonusPoints} bonus points!`);
            }, 1000);
          }
          
          return { ...mystery, clues: updatedClues };
        }
        return mystery;
      });
    });
  };
  
  // Handle fixing an environmental problem
  const handleFixProblem = (problemId: string) => {
    setProblems(prevProblems => {
      return prevProblems.map(problem => {
        if (problem.id === problemId && !problem.fixed) {
          // Award points for fixing a problem
          const pointsEarned = 30;
          setScore(prevScore => {
            const newScore = prevScore + pointsEarned;
            onScoreChange(newScore);
            return newScore;
          });
          
          setFixedProblemCount(prev => prev + 1);
          
          playSuccess();
          setMessage(`Environmental problem fixed! +${pointsEarned} points`);
          setTimeout(() => setMessage(null), 1500);
          
          return { ...problem, fixed: true };
        }
        return problem;
      });
    });
    
    // Check if all problems are fixed
    if (fixedProblemCount + 1 >= problems.length) {
      // Level completed when all problems are fixed
      setTimeout(() => {
        if (currentLevel < 3) {
          // Award level completion bonus
          const levelBonus = currentLevel * 50;
          setScore(prevScore => {
            const newScore = prevScore + levelBonus;
            onScoreChange(newScore);
            return newScore;
          });
          
          setMessage(`Level ${currentLevel} complete! +${levelBonus} bonus points! Moving to next level...`);
          setTimeout(() => {
            loadLevel(currentLevel + 1);
            setTimeLeft(120); // Reset timer
          }, 2000);
        } else {
          // Game completed
          endGame();
        }
      }, 1500);
    }
  };
  
  // End the game
  const endGame = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    
    // Final bonus based on level reached
    const finalBonus = currentLevel * 100;
    setScore(prevScore => {
      const newScore = prevScore + finalBonus;
      onScoreChange(newScore);
      return newScore;
    });
    
    setMessage(`Game Over! Final bonus: +${finalBonus} points!`);
    setTimeout(() => {
      onComplete(score + finalBonus);
    }, 2000);
  };
  
  // Get the active mystery
  const getActiveMystery = () => {
    return mysteries.find(m => m.id === activeMystery);
  };
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  return (
    <div className="h-full w-full relative overflow-hidden">
      {/* Game background */}
      <div className="absolute inset-0 bg-gradient-to-b from-amber-100 to-green-100"></div>
      
      {!gameStarted ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl p-6 shadow-lg max-w-md text-center"
          >
            <h2 className="text-2xl font-bold text-amber-700 mb-3">Eco Detective</h2>
            <p className="text-gray-700 mb-4">
              Solve environmental mysteries by finding clues and fixing eco-problems! Use your detective skills to help the environment.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-amber-500 text-white font-bold py-3 px-8 rounded-full"
              onClick={handleStart}
            >
              Start Investigating!
            </motion.button>
          </motion.div>
          
          <div className="absolute bottom-10 left-10">
            <CharacterGuide text="Environmental detectives help solve nature's mysteries! Let's gather clues and fix problems!" />
          </div>
        </div>
      ) : (
        <div className="h-full w-full relative" ref={gameAreaRef}>
          {/* Game UI */}
          <div className="absolute top-4 left-4 bg-white/80 backdrop-blur-sm rounded-lg p-3 shadow flex space-x-4">
            <div>
              <div className="text-xs text-gray-500">Score</div>
              <div className="text-2xl font-bold text-amber-700">{score}</div>
            </div>
            <div>
              <div className="text-xs text-gray-500">Level</div>
              <div className="text-2xl font-bold text-green-600">{currentLevel}/3</div>
            </div>
            <div>
              <div className="text-xs text-gray-500">Time</div>
              <div className={`text-2xl font-bold ${timeLeft <= 30 ? 'text-red-500' : 'text-blue-600'}`}>
                {timeLeft}s
              </div>
            </div>
          </div>
          
          {/* Mystery info */}
          <div className="absolute top-4 right-4 bg-white/80 backdrop-blur-sm rounded-lg p-3 shadow max-w-xs">
            <h3 className="font-semibold text-amber-800 mb-1">
              {getActiveMystery()?.title}
            </h3>
            <p className="text-sm text-gray-700 mb-2">
              {getActiveMystery()?.description}
            </p>
            <div className="text-xs text-gray-600">
              Location: {getActiveMystery()?.location}
            </div>
            <div className="mt-2 text-xs">
              <span className="font-medium text-amber-700">Clues Found:</span> {foundClueCount}/{getActiveMystery()?.clues.length || 0}
            </div>
            <div className="text-xs">
              <span className="font-medium text-green-700">Problems Fixed:</span> {fixedProblemCount}/{problems.length}
            </div>
          </div>
          
          {/* Message */}
          {message && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="absolute top-20 left-1/2 transform -translate-x-1/2 py-2 px-4 rounded-lg bg-amber-100 text-amber-800"
            >
              {message}
            </motion.div>
          )}
          
          {/* Mystery background elements */}
          <div className="absolute inset-0 pointer-events-none">
            {currentLevel === 1 && (
              // Lake background
              <>
                <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-blue-300 opacity-60" />
                <div className="absolute bottom-1/3 left-1/4 w-20 h-40 bg-gray-400" /> {/* Factory */}
                <div className="absolute bottom-0 right-0 w-full h-5 bg-brown-500 opacity-30" /> {/* Shoreline */}
              </>
            )}
            
            {currentLevel === 2 && (
              // Farm background
              <>
                <div className="absolute bottom-0 left-0 right-0 h-1/4 bg-green-300 opacity-60" /> {/* Fields */}
                <div className="absolute bottom-1/4 left-1/3 w-40 h-30 bg-red-700 opacity-40" /> {/* Barn */}
                <div className="absolute top-1/4 right-1/4 w-30 h-20 bg-yellow-200 opacity-30" /> {/* Flowers */}
              </>
            )}
            
            {currentLevel === 3 && (
              // Park background
              <>
                <div className="absolute bottom-0 left-0 right-0 h-1/5 bg-green-400 opacity-40" /> {/* Grass */}
                <div className="absolute top-10 left-10 w-20 h-60 bg-brown-700 opacity-30" /> {/* Tree trunk */}
                <div className="absolute top-0 left-0 w-40 h-40 bg-green-800 opacity-20 rounded-full" /> {/* Tree top */}
                <div className="absolute top-20 right-20 w-15 h-30 bg-brown-800 opacity-30" /> {/* Tree trunk */}
                <div className="absolute top-10 right-10 w-30 h-30 bg-green-800 opacity-20 rounded-full" /> {/* Tree top */}
              </>
            )}
          </div>
          
          {/* Clues */}
          {getActiveMystery()?.clues.map(clue => (
            !clue.found ? (
              <motion.div
                key={clue.id}
                className="absolute cursor-pointer"
                style={{ 
                  left: clue.position.x - 20, 
                  top: clue.position.y - 20 
                }}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => handleFindClue(activeMystery!, clue.id)}
              >
                <div className="relative">
                  <div className="w-10 h-10 bg-amber-400 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                      <circle cx="12" cy="12" r="10"></circle>
                      <line x1="12" y1="8" x2="12" y2="12"></line>
                      <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                  </div>
                  
                  {/* Hint visible on hover */}
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-white px-2 py-1 rounded shadow text-xs w-32 text-center opacity-0 group-hover:opacity-100 pointer-events-none">
                    {clue.hint}
                  </div>
                </div>
              </motion.div>
            ) : null
          ))}
          
          {/* Environmental problems */}
          {problems.map(problem => (
            !problem.fixed ? (
              <motion.div
                key={problem.id}
                className="absolute cursor-pointer"
                style={{ 
                  left: problem.position.x - 25, 
                  top: problem.position.y - 25 
                }}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => handleFixProblem(problem.id)}
              >
                <div className="bg-white rounded-lg p-2 shadow-md w-48">
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white font-bold">
                      !
                    </div>
                    <div className="text-xs font-medium text-gray-700">
                      {problem.description}
                    </div>
                  </div>
                  <div className="mt-1 flex justify-end">
                    <button className="bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-medium">
                      Fix Problem
                    </button>
                  </div>
                </div>
              </motion.div>
            ) : null
          ))}
          
          {/* Solution popup */}
          {showSolution && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-xl p-4 shadow-xl max-w-md"
            >
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-xl font-bold text-amber-700">Mystery Solved!</h3>
                <button 
                  className="text-gray-500 hover:text-gray-700"
                  onClick={() => setShowSolution(false)}
                >
                  ✕
                </button>
              </div>
              
              <div className="mb-3">
                <p className="text-gray-700 font-medium mb-2">{getActiveMystery()?.solution}</p>
                <div className="p-3 bg-amber-50 rounded-lg">
                  <h4 className="text-sm font-semibold text-amber-800 mb-1">Environmental Fact:</h4>
                  <p className="text-sm text-amber-700">{getActiveMystery()?.fact}</p>
                </div>
              </div>
              
              <div className="flex justify-end">
                <button 
                  className="bg-amber-100 text-amber-800 px-3 py-1 rounded-lg text-sm font-medium"
                  onClick={() => setShowSolution(false)}
                >
                  Continue Investigating
                </button>
              </div>
            </motion.div>
          )}
          
          {/* Terra character with tips */}
          <div className="absolute bottom-4 right-4">
            <CharacterGuide 
              text={currentLevel === 1 ? 
                "Look for clues around the lake! What might be causing the fish to disappear?" : 
                currentLevel === 2 ? 
                "Bees are important pollinators! Find out what's happening to them." :
                "Birds might be getting sick from something in their environment. Investigate!"
              }
              position="right"
              size="small"
              autoHide={true}
              hideDelay={8000}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default EcoDetective;
