import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useAudio } from "../lib/stores/useAudio";
import CharacterGuide from "../components/CharacterGuide";

interface Animal {
  id: string;
  name: string;
  habitat: "forest" | "ocean" | "desert" | "arctic" | "grassland";
  endangered: boolean;
  emoji: string;
  fact: string;
  position: {
    x: number;
    y: number;
  };
  matched: boolean;
  dragging: boolean;
}

interface Habitat {
  id: string;
  type: "forest" | "ocean" | "desert" | "arctic" | "grassland";
  name: string;
  emoji: string;
  position: {
    x: number;
    y: number;
  };
}

interface WildlifeProtectorProps {
  onComplete: (score: number) => void;
  onScoreChange: (score: number) => void;
}

const WildlifeProtector: React.FC<WildlifeProtectorProps> = ({ onComplete, onScoreChange }) => {
  const [score, setScore] = useState(0);
  const [gameStarted, setGameStarted] = useState(false);
  const [animals, setAnimals] = useState<Animal[]>([]);
  const [habitats, setHabitats] = useState<Habitat[]>([]);
  const [draggedAnimal, setDraggedAnimal] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [showFact, setShowFact] = useState<string | null>(null);
  const [level, setLevel] = useState(1);
  const [matchedCount, setMatchedCount] = useState(0);
  
  const gameAreaRef = useRef<HTMLDivElement>(null);
  
  const { playHit, playSuccess } = useAudio();
  
  // Animal data
  const animalData: Omit<Animal, "position" | "matched" | "dragging">[] = [
    {
      id: "animal-1",
      name: "Wolf",
      habitat: "forest",
      endangered: true,
      emoji: "🐺",
      fact: "Wolves are social animals that live in packs and communicate with howls!"
    },
    {
      id: "animal-2",
      name: "Dolphin",
      habitat: "ocean",
      endangered: false,
      emoji: "🐬",
      fact: "Dolphins are among the most intelligent animals on Earth and can recognize themselves in mirrors!"
    },
    {
      id: "animal-3",
      name: "Camel",
      habitat: "desert",
      endangered: false,
      emoji: "🐪",
      fact: "Camels can drink up to 40 gallons of water at once and go for weeks without drinking again!"
    },
    {
      id: "animal-4",
      name: "Polar Bear",
      habitat: "arctic",
      endangered: true,
      emoji: "🐻‍❄️",
      fact: "Polar bears have black skin under their white fur to help absorb heat from the sun!"
    },
    {
      id: "animal-5",
      name: "Lion",
      habitat: "grassland",
      endangered: false,
      emoji: "🦁",
      fact: "Lions are the only cats that live in groups called prides!"
    },
    {
      id: "animal-6",
      name: "Fox",
      habitat: "forest",
      endangered: false,
      emoji: "🦊",
      fact: "Foxes have whiskers on their legs that help them navigate!"
    },
    {
      id: "animal-7",
      name: "Whale",
      habitat: "ocean",
      endangered: true,
      emoji: "🐋",
      fact: "Blue whales are the largest animals ever known to have lived on Earth!"
    },
    {
      id: "animal-8",
      name: "Scorpion",
      habitat: "desert",
      endangered: false,
      emoji: "🦂",
      fact: "Scorpions glow under ultraviolet light!"
    },
    {
      id: "animal-9",
      name: "Penguin",
      habitat: "arctic",
      endangered: false,
      emoji: "🐧",
      fact: "Emperor penguins can dive up to 1,800 feet deep in the ocean!"
    },
    {
      id: "animal-10",
      name: "Elephant",
      habitat: "grassland",
      endangered: true,
      emoji: "🐘",
      fact: "Elephants can recognize themselves in mirrors and show empathy for other elephants!"
    }
  ];
  
  // Habitat data
  const habitatData: Omit<Habitat, "position">[] = [
    {
      id: "habitat-1",
      type: "forest",
      name: "Forest",
      emoji: "🌲"
    },
    {
      id: "habitat-2",
      type: "ocean",
      name: "Ocean",
      emoji: "🌊"
    },
    {
      id: "habitat-3",
      type: "desert",
      name: "Desert",
      emoji: "🏜️"
    },
    {
      id: "habitat-4",
      type: "arctic",
      name: "Arctic",
      emoji: "❄️"
    },
    {
      id: "habitat-5",
      type: "grassland",
      name: "Grassland",
      emoji: "🌾"
    }
  ];
  
  // Start the game
  const handleStart = () => {
    setGameStarted(true);
    loadLevel(1);
  };
  
  // Load a level
  const loadLevel = (levelNum: number) => {
    setLevel(levelNum);
    
    // Reset state
    setMatchedCount(0);
    setMessage(null);
    setShowFact(null);
    
    // Determine number of animals for this level
    const animalsPerLevel = levelNum < 3 ? 5 : 10;
    
    // Shuffle and select animals
    const shuffledAnimals = [...animalData].sort(() => Math.random() - 0.5);
    const selectedAnimals = shuffledAnimals.slice(0, animalsPerLevel);
    
    // Position animals on the left side
    const positionedAnimals: Animal[] = selectedAnimals.map((animal, index) => ({
      ...animal,
      position: {
        x: 50,
        y: 100 + index * 70
      },
      matched: false,
      dragging: false
    }));
    
    setAnimals(positionedAnimals);
    
    // Position habitats on the right side
    const uniqueHabitats = [...new Set(selectedAnimals.map(a => a.habitat))];
    const habitats = uniqueHabitats.map((habitatType, index) => {
      const habitatInfo = habitatData.find(h => h.type === habitatType);
      if (!habitatInfo) throw new Error(`No habitat info for ${habitatType}`);
      
      return {
        ...habitatInfo,
        position: {
          x: window.innerWidth - 150,
          y: 150 + index * 120
        }
      };
    });
    
    setHabitats(habitats);
  };
  
  // Handle dragging an animal
  const handleDragStart = (animalId: string) => {
    setDraggedAnimal(animalId);
    
    setAnimals(prevAnimals => 
      prevAnimals.map(animal => 
        animal.id === animalId ? { ...animal, dragging: true } : animal
      )
    );
  };
  
  // Handle dropping an animal
  const handleDragEnd = (animalId: string) => {
    const animal = animals.find(a => a.id === animalId);
    if (!animal) return;
    
    setAnimals(prevAnimals => 
      prevAnimals.map(a => 
        a.id === animalId ? { ...a, dragging: false } : a
      )
    );
    
    // Check if dropped on correct habitat
    const animalElement = document.getElementById(animalId);
    if (!animalElement) return;
    
    const animalRect = animalElement.getBoundingClientRect();
    const animalCenter = {
      x: animalRect.left + animalRect.width / 2,
      y: animalRect.top + animalRect.height / 2
    };
    
    // Check collision with habitats
    let matchedHabitat = false;
    
    for (const habitat of habitats) {
      const habitatElement = document.getElementById(habitat.id);
      if (!habitatElement) continue;
      
      const habitatRect = habitatElement.getBoundingClientRect();
      
      // Check if animal center is inside habitat
      if (
        animalCenter.x >= habitatRect.left &&
        animalCenter.x <= habitatRect.right &&
        animalCenter.y >= habitatRect.top &&
        animalCenter.y <= habitatRect.bottom
      ) {
        // Check if correct habitat
        if (animal.habitat === habitat.type) {
          // Correct match
          const pointsEarned = animal.endangered ? 100 : 50; // Bonus for endangered species
          
          setScore(prevScore => {
            const newScore = prevScore + pointsEarned;
            onScoreChange(newScore);
            return newScore;
          });
          
          // Update animal position to center of habitat
          setAnimals(prevAnimals => 
            prevAnimals.map(a => 
              a.id === animalId ? { 
                ...a, 
                matched: true,
                position: {
                  x: habitat.position.x,
                  y: habitat.position.y
                }
              } : a
            )
          );
          
          setMatchedCount(prev => prev + 1);
          
          playSuccess();
          setMessage(`+${pointsEarned} points! Correct habitat!`);
          setTimeout(() => {
            setMessage(null);
            // Show fact about the animal
            setShowFact(animalId);
          }, 1500);
        } else {
          // Wrong habitat
          playHit();
          setMessage(`Oops! ${animal.name} doesn't live in the ${habitat.name}!`);
          setTimeout(() => setMessage(null), 1500);
          
          // Return animal to original position
          setAnimals(prevAnimals => 
            prevAnimals.map(a => 
              a.id === animalId ? { 
                ...a,
                position: {
                  x: 50,
                  y: 100 + prevAnimals.indexOf(a) * 70
                }
              } : a
            )
          );
        }
        
        matchedHabitat = true;
        break;
      }
    }
    
    // If not dropped on any habitat, return to original position
    if (!matchedHabitat) {
      setAnimals(prevAnimals => 
        prevAnimals.map(a => 
          a.id === animalId ? { 
            ...a,
            position: {
              x: 50,
              y: 100 + prevAnimals.indexOf(a) * 70
            }
          } : a
        )
      );
    }
    
    setDraggedAnimal(null);
  };
  
  // Update animal position during drag
  const handleDrag = (animalId: string, newPosition: { x: number; y: number }) => {
    setAnimals(prevAnimals => 
      prevAnimals.map(animal => 
        animal.id === animalId ? { 
          ...animal, 
          position: newPosition 
        } : animal
      )
    );
  };
  
  // Check level completion
  useEffect(() => {
    if (matchedCount > 0 && matchedCount === animals.filter(a => !a.matched).length + matchedCount) {
      // All animals matched, level complete
      setTimeout(() => {
        if (level < 3) {
          // Load next level
          setMessage(`Level ${level} complete! Moving to level ${level + 1}...`);
          setTimeout(() => {
            loadLevel(level + 1);
          }, 2000);
        } else {
          // Game complete
          onComplete(score);
        }
      }, 1500);
    }
  }, [matchedCount, animals.length, level, score, onComplete]);
  
  return (
    <div className="h-full w-full relative overflow-hidden">
      {/* Game background */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-100 to-green-100"></div>
      
      {!gameStarted ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl p-6 shadow-lg max-w-md text-center"
          >
            <h2 className="text-2xl font-bold text-emerald-700 mb-3">Wildlife Protector</h2>
            <p className="text-gray-700 mb-4">
              Help animals find their correct habitats! Learn about different species and which ones are endangered.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-emerald-500 text-white font-bold py-3 px-8 rounded-full"
              onClick={handleStart}
            >
              Start Protecting!
            </motion.button>
          </motion.div>
          
          <div className="absolute bottom-10 left-10">
            <CharacterGuide text="Animals need our help to protect their homes! Let's learn about where they live." />
          </div>
        </div>
      ) : (
        <div className="h-full w-full relative" ref={gameAreaRef}>
          {/* Game UI */}
          <div className="absolute top-4 left-4 bg-white/80 backdrop-blur-sm rounded-lg p-3 shadow flex space-x-4">
            <div>
              <div className="text-xs text-gray-500">Score</div>
              <div className="text-2xl font-bold text-emerald-700">{score}</div>
            </div>
            <div>
              <div className="text-xs text-gray-500">Level</div>
              <div className="text-2xl font-bold text-blue-600">{level}/3</div>
            </div>
            <div>
              <div className="text-xs text-gray-500">Matched</div>
              <div className="text-2xl font-bold text-amber-600">
                {matchedCount}/{animals.length}
              </div>
            </div>
          </div>
          
          {/* Message */}
          {message && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="absolute top-16 left-1/2 transform -translate-x-1/2 py-2 px-4 rounded-lg bg-emerald-100 text-emerald-800"
            >
              {message}
            </motion.div>
          )}
          
          {/* Habitats */}
          {habitats.map(habitat => (
            <motion.div
              key={habitat.id}
              id={habitat.id}
              className="absolute bg-white/50 backdrop-blur-sm rounded-lg p-4 shadow-md w-40 h-40 flex flex-col items-center justify-center"
              style={{ 
                left: habitat.position.x - 40, 
                top: habitat.position.y - 40 
              }}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              <div className="text-5xl mb-2">{habitat.emoji}</div>
              <div className="text-lg font-bold text-gray-800">{habitat.name}</div>
            </motion.div>
          ))}
          
          {/* Animals */}
          {animals.map(animal => (
            !animal.matched ? (
              <motion.div
                key={animal.id}
                id={animal.id}
                className={`absolute cursor-grab active:cursor-grabbing bg-white rounded-lg p-3 shadow-md ${
                  animal.dragging ? 'z-10 shadow-xl' : 'z-0'
                } ${animal.endangered ? 'border-2 border-red-400' : ''}`}
                drag
                dragConstraints={gameAreaRef}
                onDragStart={() => handleDragStart(animal.id)}
                onDrag={(_, info) => handleDrag(animal.id, { x: info.point.x, y: info.point.y })}
                onDragEnd={() => handleDragEnd(animal.id)}
                style={{
                  left: animal.position.x - 40,
                  top: animal.position.y - 20,
                  opacity: animal.dragging ? 0.8 : 1
                }}
              >
                <div className="flex items-center space-x-3">
                  <div className="text-4xl">{animal.emoji}</div>
                  <div>
                    <div className="font-semibold">{animal.name}</div>
                    {animal.endangered && (
                      <div className="text-xs text-red-600 font-medium">Endangered</div>
                    )}
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key={animal.id}
                className="absolute pointer-events-none"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ 
                  opacity: 1, 
                  scale: 1,
                  x: animal.position.x - 20, 
                  y: animal.position.y - 20 
                }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
              >
                <div className="text-4xl">{animal.emoji}</div>
              </motion.div>
            )
          ))}
          
          {/* Animal fact popup */}
          {showFact && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-xl p-4 shadow-xl max-w-sm"
            >
              {(() => {
                const animal = animals.find(a => a.id === showFact);
                if (!animal) return null;
                return (
                  <>
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-xl font-bold text-emerald-700">{animal.name}</h3>
                      <button 
                        className="text-gray-500 hover:text-gray-700"
                        onClick={() => setShowFact(null)}
                      >
                        ✕
                      </button>
                    </div>
                    
                    <div className="flex items-center justify-center my-3">
                      <span className="text-6xl">{animal.emoji}</span>
                    </div>
                    
                    <div className="mb-3">
                      <p className="text-gray-700">{animal.fact}</p>
                    </div>
                    
                    <div className="flex flex-wrap gap-2 mb-3">
                      <div className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                        Habitat: {animal.habitat}
                      </div>
                      {animal.endangered && (
                        <div className="px-2 py-1 bg-red-100 text-red-800 rounded-full text-xs font-medium">
                          Endangered Species
                        </div>
                      )}
                    </div>
                    
                    <div className="flex justify-end">
                      <button 
                        className="bg-emerald-100 text-emerald-800 px-3 py-1 rounded-lg text-sm font-medium"
                        onClick={() => setShowFact(null)}
                      >
                        Got It!
                      </button>
                    </div>
                  </>
                );
              })()}
            </motion.div>
          )}
          
          {/* Terra character with tips */}
          <div className="absolute top-16 right-4">
            <CharacterGuide 
              text={`Drag the animals to their correct habitats! ${level > 1 ? 'Pay special attention to endangered species!' : 'Can you match them all?'}`}
              position="right"
              size="small"
              autoHide={true}
              hideDelay={8000}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default WildlifeProtector;
