import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAudio } from "../lib/stores/useAudio";
import CharacterGuide from "../components/CharacterGuide";

interface Plant {
  id: string;
  name: string;
  type: "flower" | "vegetable" | "tree" | "herb";
  stage: "seed" | "sprout" | "growing" | "mature";
  health: number;
  waterLevel: number;
  x: number;
  y: number;
  planted: boolean;
  fact: string;
  emoji: {
    seed: string;
    sprout: string;
    growing: string;
    mature: string;
  };
}

interface PlantInfo {
  id: string;
  name: string;
  type: "flower" | "vegetable" | "tree" | "herb";
  fact: string;
  emoji: {
    seed: string;
    sprout: string;
    growing: string;
    mature: string;
  };
}

interface GardenGuardianProps {
  onComplete: (score: number) => void;
  onScoreChange: (score: number) => void;
}

const GardenGuardian: React.FC<GardenGuardianProps> = ({ onComplete, onScoreChange }) => {
  const [score, setScore] = useState(0);
  const [gameStarted, setGameStarted] = useState(false);
  const [plants, setPlants] = useState<Plant[]>([]);
  const [availableSeeds, setAvailableSeeds] = useState<PlantInfo[]>([]);
  const [selectedSeed, setSelectedSeed] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [showPlantInfo, setShowPlantInfo] = useState<string | null>(null);
  const [toolSelected, setToolSelected] = useState<"water" | "fertilize" | "none">("none");
  const [daysPassed, setDaysPassed] = useState(0);
  
  const gardenRef = useRef<HTMLDivElement>(null);
  const dayIntervalRef = useRef<NodeJS.Timeout | null>(null);
  
  const { playHit, playSuccess } = useAudio();
  
  // Plant data
  const plantData: PlantInfo[] = [
    {
      id: "plant-1",
      name: "Sunflower",
      type: "flower",
      fact: "Sunflowers follow the sun from east to west during the day!",
      emoji: {
        seed: "🌱",
        sprout: "🌿",
        growing: "🌻",
        mature: "🌻"
      }
    },
    {
      id: "plant-2",
      name: "Tomato",
      type: "vegetable",
      fact: "Tomatoes are actually fruits, not vegetables!",
      emoji: {
        seed: "🌱",
        sprout: "🌿",
        growing: "🍅",
        mature: "🍅"
      }
    },
    {
      id: "plant-3",
      name: "Apple Tree",
      type: "tree",
      fact: "Apple trees can live for over 100 years!",
      emoji: {
        seed: "🌱",
        sprout: "🌿",
        growing: "🌳",
        mature: "🌳"
      }
    },
    {
      id: "plant-4",
      name: "Basil",
      type: "herb",
      fact: "Basil is used in many cuisines and has antibacterial properties!",
      emoji: {
        seed: "🌱",
        sprout: "🌿",
        growing: "🌿",
        mature: "🌿"
      }
    },
    {
      id: "plant-5",
      name: "Carrot",
      type: "vegetable",
      fact: "Carrots were originally purple, not orange!",
      emoji: {
        seed: "🌱",
        sprout: "🌿",
        growing: "🥕",
        mature: "🥕"
      }
    },
    {
      id: "plant-6",
      name: "Rose",
      type: "flower",
      fact: "There are over 300 species of roses!",
      emoji: {
        seed: "🌱",
        sprout: "🌿",
        growing: "🌹",
        mature: "🌹"
      }
    },
    {
      id: "plant-7",
      name: "Oak Tree",
      type: "tree",
      fact: "Oak trees can live for over 1,000 years!",
      emoji: {
        seed: "🌱",
        sprout: "🌿",
        growing: "🌳",
        mature: "🌳"
      }
    },
    {
      id: "plant-8",
      name: "Mint",
      type: "herb",
      fact: "Mint helps keep insects away from your garden!",
      emoji: {
        seed: "🌱",
        sprout: "🌿",
        growing: "🌿",
        mature: "🌿"
      }
    }
  ];
  
  // Start the game
  const handleStart = () => {
    setGameStarted(true);
    
    // Set available seeds (start with 3)
    const shuffled = [...plantData].sort(() => Math.random() - 0.5);
    setAvailableSeeds(shuffled.slice(0, 3));
    
    // Start day cycle
    dayIntervalRef.current = setInterval(() => {
      advanceDay();
    }, 15000); // New day every 15 seconds
  };
  
  // Advance to next day
  const advanceDay = () => {
    setDaysPassed(prev => prev + 1);
    setMessage(`Day ${daysPassed + 1} has begun!`);
    setTimeout(() => setMessage(null), 1500);
    
    // Update plants
    setPlants(prevPlants => {
      return prevPlants.map(plant => {
        // Reduce water level each day
        let newWaterLevel = plant.waterLevel - 20;
        if (newWaterLevel < 0) newWaterLevel = 0;
        
        // Reduce health if water level is too low
        let newHealth = plant.health;
        if (newWaterLevel <= 20) {
          newHealth -= 10;
        }
        
        // Advance plant stage based on health and days
        let newStage = plant.stage;
        if (plant.health >= 80) {
          if (daysPassed % 2 === 0) { // Every 2 days
            if (plant.stage === "seed") newStage = "sprout";
            else if (plant.stage === "sprout") newStage = "growing";
            else if (plant.stage === "growing") newStage = "mature";
          }
        }
        
        // Award points for growing plants
        if (newStage !== plant.stage && newStage === "mature") {
          const pointsEarned = 100;
          setScore(prevScore => {
            const newScore = prevScore + pointsEarned;
            onScoreChange(newScore);
            return newScore;
          });
          playSuccess();
          setMessage(`+${pointsEarned} points! ${plant.name} is fully grown!`);
        }
        
        return {
          ...plant,
          waterLevel: newWaterLevel,
          health: Math.max(0, newHealth),
          stage: newStage
        };
      });
    });
    
    // Add a new seed type occasionally
    if (daysPassed % 3 === 0 && availableSeeds.length < plantData.length) {
      const currentSeedIds = availableSeeds.map(seed => seed.id);
      const newSeeds = plantData.filter(plant => !currentSeedIds.includes(plant.id));
      if (newSeeds.length > 0) {
        const randomSeed = newSeeds[Math.floor(Math.random() * newSeeds.length)];
        setAvailableSeeds(prev => [...prev, randomSeed]);
        setMessage(`A new seed type is available: ${randomSeed.name}!`);
      }
    }
    
    // Check if game should end (after 10 days or 5 mature plants)
    const maturePlants = plants.filter(p => p.stage === "mature").length;
    if (daysPassed + 1 >= 10 || maturePlants >= 5) {
      if (dayIntervalRef.current) clearInterval(dayIntervalRef.current);
      setTimeout(() => {
        onComplete(score);
      }, 2000);
    }
  };
  
  // Handle selecting a seed
  const handleSelectSeed = (seedId: string) => {
    setSelectedSeed(seedId);
    setToolSelected("none");
    setMessage("Click on the garden to plant!");
  };
  
  // Handle planting a seed
  const handlePlant = (event: React.MouseEvent) => {
    if (!selectedSeed || !gardenRef.current) return;
    
    const gardenRect = gardenRef.current.getBoundingClientRect();
    const x = event.clientX - gardenRect.left;
    const y = event.clientY - gardenRect.top;
    
    // Check if too close to other plants
    const minDistance = 80;
    const tooClose = plants.some(plant => {
      const distance = Math.sqrt(Math.pow(plant.x - x, 2) + Math.pow(plant.y - y, 2));
      return distance < minDistance;
    });
    
    if (tooClose) {
      setMessage("Too close to another plant! Choose a different spot.");
      playHit();
      return;
    }
    
    // Find the seed data
    const seedData = availableSeeds.find(seed => seed.id === selectedSeed);
    if (!seedData) return;
    
    // Create new plant
    const newPlant: Plant = {
      ...seedData,
      stage: "seed",
      health: 100,
      waterLevel: 100,
      x,
      y,
      planted: true
    };
    
    setPlants(prev => [...prev, newPlant]);
    setSelectedSeed(null);
    
    // Award points for planting
    const pointsEarned = 10;
    setScore(prevScore => {
      const newScore = prevScore + pointsEarned;
      onScoreChange(newScore);
      return newScore;
    });
    
    playSuccess();
    setMessage(`+${pointsEarned} points! ${seedData.name} planted!`);
    setTimeout(() => setMessage(null), 1500);
  };
  
  // Handle selecting a tool
  const handleSelectTool = (tool: "water" | "fertilize" | "none") => {
    setToolSelected(tool);
    setSelectedSeed(null);
    setMessage(`${tool === "water" ? "Watering" : "Fertilizing"} tool selected!`);
  };
  
  // Handle using a tool on a plant
  const handleUseTool = (plantId: string) => {
    if (toolSelected === "none") {
      // Show plant info instead of using a tool
      setShowPlantInfo(plantId);
      return;
    }
    
    setPlants(prevPlants => {
      return prevPlants.map(plant => {
        if (plant.id === plantId) {
          if (toolSelected === "water") {
            // Water the plant
            const newWaterLevel = Math.min(100, plant.waterLevel + 30);
            
            // Award points for watering
            if (newWaterLevel > plant.waterLevel) {
              const pointsEarned = 5;
              setScore(prevScore => {
                const newScore = prevScore + pointsEarned;
                onScoreChange(newScore);
                return newScore;
              });
              
              playSuccess();
              setMessage(`+${pointsEarned} points! ${plant.name} watered!`);
              setTimeout(() => setMessage(null), 1500);
            }
            
            return { ...plant, waterLevel: newWaterLevel };
          } else if (toolSelected === "fertilize") {
            // Fertilize the plant (boost health)
            const newHealth = Math.min(100, plant.health + 20);
            
            // Award points for fertilizing
            if (newHealth > plant.health) {
              const pointsEarned = 5;
              setScore(prevScore => {
                const newScore = prevScore + pointsEarned;
                onScoreChange(newScore);
                return newScore;
              });
              
              playSuccess();
              setMessage(`+${pointsEarned} points! ${plant.name} fertilized!`);
              setTimeout(() => setMessage(null), 1500);
            }
            
            return { ...plant, health: newHealth };
          }
        }
        return plant;
      });
    });
  };
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (dayIntervalRef.current) clearInterval(dayIntervalRef.current);
    };
  }, []);

  return (
    <div className="h-full w-full relative overflow-hidden">
      {/* Garden background */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-200 to-green-200"></div>
      
      {!gameStarted ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl p-6 shadow-lg max-w-md text-center"
          >
            <h2 className="text-2xl font-bold text-green-700 mb-3">Garden Guardian</h2>
            <p className="text-gray-700 mb-4">
              Plant and grow your own garden! Learn about different plants and how to care for them.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-green-500 text-white font-bold py-3 px-8 rounded-full"
              onClick={handleStart}
            >
              Start Gardening!
            </motion.button>
          </motion.div>
          
          <div className="absolute bottom-10 left-10">
            <CharacterGuide text="Plants are amazing! They clean our air and provide food. Let's learn how to grow them!" />
          </div>
        </div>
      ) : (
        <div className="h-full w-full relative">
          {/* Garden area */}
          <div 
            ref={gardenRef}
            className="absolute inset-0 cursor-pointer"
            style={{ backgroundColor: "#8B4513" }}
            onClick={selectedSeed ? handlePlant : undefined}
          >
            {/* Soil texture */}
            <div className="absolute inset-0 bg-repeat opacity-60" style={{ 
              backgroundImage: `radial-gradient(#3e1e0d 2px, transparent 2px)`,
              backgroundSize: "20px 20px"
            }}></div>
            
            {/* Plants */}
            {plants.map(plant => (
              <div
                key={plant.id}
                className="absolute cursor-pointer"
                style={{ 
                  left: plant.x - 30, 
                  top: plant.y - 30, 
                  opacity: plant.health <= 0 ? 0.5 : 1 
                }}
                onClick={() => handleUseTool(plant.id)}
              >
                <div className="flex flex-col items-center">
                  <div className="text-5xl mb-1">
                    {plant.emoji[plant.stage]}
                  </div>
                  
                  {/* Health and water indicators */}
                  <div className="flex space-x-1">
                    {/* Health bar */}
                    <div className="w-10 h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-green-500" 
                        style={{ width: `${plant.health}%` }}
                      />
                    </div>
                    
                    {/* Water bar */}
                    <div className="w-10 h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-blue-500" 
                        style={{ width: `${plant.waterLevel}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Game UI */}
          <div className="absolute top-4 left-4 bg-white/80 backdrop-blur-sm rounded-lg p-3 shadow">
            <div className="flex space-x-4">
              <div>
                <div className="text-xs text-gray-500">Score</div>
                <div className="text-2xl font-bold text-green-700">{score}</div>
              </div>
              <div>
                <div className="text-xs text-gray-500">Day</div>
                <div className="text-2xl font-bold text-amber-600">{daysPassed + 1}/10</div>
              </div>
              <div>
                <div className="text-xs text-gray-500">Plants</div>
                <div className="text-2xl font-bold text-emerald-600">
                  {plants.filter(p => p.health > 0).length}
                </div>
              </div>
            </div>
          </div>
          
          {/* Message */}
          {message && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="absolute top-16 left-1/2 transform -translate-x-1/2 py-2 px-4 rounded-lg bg-green-100 text-green-800"
            >
              {message}
            </motion.div>
          )}
          
          {/* Seed selection */}
          <div className="absolute bottom-4 left-4 right-4 bg-white/80 backdrop-blur-sm rounded-lg p-3 shadow">
            <div className="mb-2 flex justify-between items-center">
              <h3 className="font-semibold text-green-800">Seeds</h3>
              <div className="flex space-x-2">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`px-3 py-1 rounded-lg text-sm font-semibold ${
                    toolSelected === "water" ? 'bg-blue-500 text-white' : 'bg-blue-100 text-blue-800'
                  }`}
                  onClick={() => handleSelectTool("water")}
                >
                  Water 💧
                </motion.button>
                
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`px-3 py-1 rounded-lg text-sm font-semibold ${
                    toolSelected === "fertilize" ? 'bg-amber-500 text-white' : 'bg-amber-100 text-amber-800'
                  }`}
                  onClick={() => handleSelectTool("fertilize")}
                >
                  Fertilize 💩
                </motion.button>
                
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`px-3 py-1 rounded-lg text-sm font-semibold ${
                    toolSelected === "none" && !selectedSeed ? 'bg-gray-500 text-white' : 'bg-gray-100 text-gray-800'
                  }`}
                  onClick={() => {
                    setToolSelected("none");
                    setSelectedSeed(null);
                  }}
                >
                  Info ℹ️
                </motion.button>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-2">
              {availableSeeds.map(seed => (
                <motion.div
                  key={seed.id}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`px-3 py-2 rounded-lg cursor-pointer flex items-center space-x-2 ${
                    selectedSeed === seed.id ? 'bg-green-500 text-white' : 'bg-green-100 text-green-800'
                  }`}
                  onClick={() => handleSelectSeed(seed.id)}
                >
                  <span className="text-xl">{seed.emoji.seed}</span>
                  <span className="font-medium">{seed.name}</span>
                </motion.div>
              ))}
            </div>
          </div>
          
          {/* Plant info popup */}
          <AnimatePresence>
            {showPlantInfo && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-xl p-4 shadow-xl max-w-sm"
              >
                {(() => {
                  const plant = plants.find(p => p.id === showPlantInfo);
                  if (!plant) return null;
                  return (
                    <>
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="text-xl font-bold text-green-700">{plant.name}</h3>
                        <button 
                          className="text-gray-500 hover:text-gray-700"
                          onClick={() => setShowPlantInfo(null)}
                        >
                          ✕
                        </button>
                      </div>
                      
                      <div className="flex items-center justify-center my-3">
                        <span className="text-6xl">{plant.emoji[plant.stage]}</span>
                      </div>
                      
                      <div className="mb-3">
                        <p className="text-gray-700 mb-2">{plant.fact}</p>
                        <div className="flex justify-between text-sm">
                          <div>
                            <span className="font-semibold">Type:</span> {plant.type}
                          </div>
                          <div>
                            <span className="font-semibold">Stage:</span> {plant.stage}
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Health:</span>
                            <span>{plant.health}%</span>
                          </div>
                          <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className={`h-full ${
                                plant.health > 66 ? 'bg-green-500' : 
                                plant.health > 33 ? 'bg-yellow-500' : 
                                'bg-red-500'
                              }`}
                              style={{ width: `${plant.health}%` }}
                            />
                          </div>
                        </div>
                        
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Water:</span>
                            <span>{plant.waterLevel}%</span>
                          </div>
                          <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className={`h-full ${
                                plant.waterLevel > 66 ? 'bg-blue-500' : 
                                plant.waterLevel > 33 ? 'bg-blue-400' : 
                                'bg-blue-300'
                              }`}
                              style={{ width: `${plant.waterLevel}%` }}
                            />
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex justify-end mt-4">
                        <button 
                          className="bg-green-100 text-green-800 px-3 py-1 rounded-lg text-sm font-medium"
                          onClick={() => setShowPlantInfo(null)}
                        >
                          Close
                        </button>
                      </div>
                    </>
                  );
                })()}
              </motion.div>
            )}
          </AnimatePresence>
          
          {/* Terra character with tips */}
          <div className="absolute top-16 right-4">
            <CharacterGuide 
              text="Plants need water and care to grow! Make sure to keep the water level high and use fertilizer to boost health."
              position="right"
              size="small"
              autoHide={true}
              hideDelay={8000}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default GardenGuardian;
