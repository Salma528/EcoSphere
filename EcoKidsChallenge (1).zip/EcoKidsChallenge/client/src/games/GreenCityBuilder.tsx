import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useAudio } from "../lib/stores/useAudio";
import CharacterGuide from "../components/CharacterGuide";

interface BuildingTile {
  id: string;
  type: BuildingType;
  name: string;
  emoji: string;
  energy: number; // Energy usage/production (negative for production)
  pollution: number; // Pollution level (negative for cleaning)
  happiness: number; // Happiness contribution
  placed: boolean;
  position: {
    x: number;
    y: number;
    gridX: number;
    gridY: number;
  };
  description: string;
  fact: string;
}

type BuildingType = 
  "house" | "apartment" | "park" | "solar" | "wind" | "factory" | 
  "office" | "school" | "hospital" | "recycling" | "transport";

interface CityMetrics {
  energy: number;
  pollution: number;
  happiness: number;
  population: number;
}

interface GridTile {
  x: number;
  y: number;
  occupied: boolean;
  buildingId: string | null;
}

interface GreenCityBuilderProps {
  onComplete: (score: number) => void;
  onScoreChange: (score: number) => void;
}

const GRID_SIZE = 5;
const TILE_SIZE = 80;

const GreenCityBuilder: React.FC<GreenCityBuilderProps> = ({ onComplete, onScoreChange }) => {
  const [score, setScore] = useState(0);
  const [gameStarted, setGameStarted] = useState(false);
  const [buildings, setBuildings] = useState<BuildingTile[]>([]);
  const [selectedBuilding, setSelectedBuilding] = useState<string | null>(null);
  const [grid, setGrid] = useState<GridTile[][]>([]);
  const [cityMetrics, setCityMetrics] = useState<CityMetrics>({
    energy: 0,
    pollution: 0,
    happiness: 0,
    population: 0
  });
  const [message, setMessage] = useState<string | null>(null);
  const [buildingInfo, setBuildingInfo] = useState<string | null>(null);
  const [level, setLevel] = useState(1);
  const [goalReached, setGoalReached] = useState(false);
  
  const gameAreaRef = useRef<HTMLDivElement>(null);
  
  const { playHit, playSuccess } = useAudio();
  
  // Building data
  const buildingData: Omit<BuildingTile, "placed" | "position">[] = [
    {
      id: "building-1",
      type: "house",
      name: "Eco-House",
      emoji: "🏡",
      energy: 2,
      pollution: 1,
      happiness: 3,
      description: "An energy-efficient house for a single family",
      fact: "Energy-efficient homes can reduce energy consumption by up to 30% compared to traditional houses."
    },
    {
      id: "building-2",
      type: "apartment",
      name: "Green Apartment",
      emoji: "🏢",
      energy: 5,
      pollution: 2,
      happiness: 2,
      description: "A multi-family apartment building with green roof",
      fact: "Green roofs can reduce building energy use by 15-30% and last twice as long as conventional roofs."
    },
    {
      id: "building-3",
      type: "park",
      name: "City Park",
      emoji: "🌳",
      energy: 0,
      pollution: -3,
      happiness: 5,
      description: "A green space with trees and recreational areas",
      fact: "A single mature tree can absorb up to 48 pounds of carbon dioxide per year."
    },
    {
      id: "building-4",
      type: "solar",
      name: "Solar Farm",
      emoji: "☀️",
      energy: -7,
      pollution: -2,
      happiness: 1,
      description: "A collection of solar panels generating clean energy",
      fact: "The amount of sunlight that strikes the earth's surface in an hour and a half is enough to handle the entire world's energy consumption for a full year."
    },
    {
      id: "building-5",
      type: "wind",
      name: "Wind Turbines",
      emoji: "🌬️",
      energy: -5,
      pollution: -1,
      happiness: 1,
      description: "Wind turbines harnessing wind power",
      fact: "Wind turbines can reduce carbon emissions by up to 99% compared to fossil fuel power plants."
    },
    {
      id: "building-6",
      type: "factory",
      name: "Green Factory",
      emoji: "🏭",
      energy: 8,
      pollution: 4,
      happiness: -2,
      description: "A factory with eco-friendly manufacturing processes",
      fact: "Eco-friendly factories can reduce water usage by up to 50% compared to traditional factories."
    },
    {
      id: "building-7",
      type: "office",
      name: "Smart Office",
      emoji: "🏬",
      energy: 4,
      pollution: 2,
      happiness: 1,
      description: "An office building with smart energy management",
      fact: "Smart buildings can reduce energy consumption by 15-20% on average."
    },
    {
      id: "building-8",
      type: "school",
      name: "Eco-School",
      emoji: "🏫",
      energy: 3,
      pollution: 1,
      happiness: 4,
      description: "A school teaching environmental education",
      fact: "Schools with environmental education programs see a 90% increase in student awareness of ecological issues."
    },
    {
      id: "building-9",
      type: "hospital",
      name: "Green Hospital",
      emoji: "🏥",
      energy: 6,
      pollution: 2,
      happiness: 3,
      description: "A hospital with sustainable healthcare practices",
      fact: "Green hospitals can reduce their carbon footprint by up to 30% through sustainable practices."
    },
    {
      id: "building-10",
      type: "recycling",
      name: "Recycling Center",
      emoji: "♻️",
      energy: 2,
      pollution: -4,
      happiness: 2,
      description: "A facility for processing recyclable materials",
      fact: "Recycling one ton of paper can save 17 trees, 7,000 gallons of water, and 463 gallons of oil."
    },
    {
      id: "building-11",
      type: "transport",
      name: "Green Transit Hub",
      emoji: "🚊",
      energy: 3,
      pollution: -3,
      happiness: 3,
      description: "A hub for electric public transportation",
      fact: "Public transportation produces 95% less carbon monoxide and nearly 50% less carbon dioxide and nitrogen oxide per passenger mile than private vehicles."
    }
  ];
  
  // Start the game
  const handleStart = () => {
    setGameStarted(true);
    initializeGame();
  };
  
  // Initialize the game
  const initializeGame = () => {
    // Initialize grid
    const initialGrid: GridTile[][] = [];
    for (let y = 0; y < GRID_SIZE; y++) {
      const row: GridTile[] = [];
      for (let x = 0; x < GRID_SIZE; x++) {
        row.push({
          x,
          y,
          occupied: false,
          buildingId: null
        });
      }
      initialGrid.push(row);
    }
    setGrid(initialGrid);
    
    // Initialize available buildings (fewer for level 1)
    const availableBuildingCount = 5 + level;
    const shuffledBuildings = [...buildingData].sort(() => Math.random() - 0.5).slice(0, availableBuildingCount);
    
    const positionedBuildings = shuffledBuildings.map(building => ({
      ...building,
      placed: false,
      position: {
        x: 0,
        y: 0,
        gridX: -1,
        gridY: -1
      }
    }));
    
    setBuildings(positionedBuildings);
    
    // Initialize city metrics
    setCityMetrics({
      energy: 0,
      pollution: 0,
      happiness: 0,
      population: 0
    });
    
    setMessage(`Level ${level}: Build a sustainable city!`);
    setTimeout(() => setMessage(null), 2000);
  };
  
  // Handle selecting a building
  const handleSelectBuilding = (buildingId: string) => {
    const building = buildings.find(b => b.id === buildingId);
    if (!building || building.placed) return;
    
    setSelectedBuilding(buildingId);
    setBuildingInfo(buildingId);
  };
  
  // Handle placing a building on the grid
  const handlePlaceBuilding = (gridX: number, gridY: number) => {
    if (!selectedBuilding) return;
    
    // Check if tile is occupied
    if (grid[gridY][gridX].occupied) {
      playHit();
      setMessage("This tile is already occupied!");
      return;
    }
    
    const building = buildings.find(b => b.id === selectedBuilding);
    if (!building) return;
    
    // Place the building
    setBuildings(prev => {
      return prev.map(b => {
        if (b.id === selectedBuilding) {
          return {
            ...b,
            placed: true,
            position: {
              ...b.position,
              gridX,
              gridY,
              x: gridX * TILE_SIZE,
              y: gridY * TILE_SIZE
            }
          };
        }
        return b;
      });
    });
    
    // Update grid
    setGrid(prev => {
      const newGrid = [...prev];
      newGrid[gridY][gridX] = {
        ...newGrid[gridY][gridX],
        occupied: true,
        buildingId: selectedBuilding
      };
      return newGrid;
    });
    
    // Update city metrics
    setCityMetrics(prev => {
      const newMetrics = {
        energy: prev.energy + building.energy,
        pollution: prev.pollution + building.pollution,
        happiness: prev.happiness + building.happiness,
        population: prev.population + (building.type === "house" ? 1 : building.type === "apartment" ? 3 : 0)
      };
      
      // Award points based on sustainability
      let pointsEarned = 10;
      
      // Bonus for renewable energy
      if (building.energy < 0) {
        pointsEarned += 5;
      }
      
      // Bonus for reducing pollution
      if (building.pollution < 0) {
        pointsEarned += 5;
      }
      
      // Bonus for increasing happiness
      if (building.happiness > 2) {
        pointsEarned += 5;
      }
      
      setScore(prevScore => {
        const newScore = prevScore + pointsEarned;
        onScoreChange(newScore);
        return newScore;
      });
      
      playSuccess();
      setMessage(`${building.name} placed! +${pointsEarned} points`);
      setTimeout(() => setMessage(null), 1500);
      
      // Check if level goals are met
      checkGoals(newMetrics);
      
      return newMetrics;
    });
    
    setSelectedBuilding(null);
    setBuildingInfo(null);
  };
  
  // Check if level goals are met
  const checkGoals = (metrics: CityMetrics) => {
    // Different goals based on level
    const goals = {
      1: {
        energy: 0, // Neutral or positive energy balance
        pollution: 0, // Low pollution
        happiness: 10, // Decent happiness
        population: 3 // Small population
      },
      2: {
        energy: -5, // Net energy production
        pollution: -5, // Negative pollution (cleaning)
        happiness: 15, // Good happiness
        population: 5 // Medium population
      },
      3: {
        energy: -10, // Major energy production
        pollution: -10, // Major pollution reduction
        happiness: 20, // Excellent happiness
        population: 8 // Large population
      }
    };
    
    const levelGoals = goals[level as keyof typeof goals];
    
    // Check if goals are met
    if (
      metrics.energy <= levelGoals.energy &&
      metrics.pollution <= levelGoals.pollution &&
      metrics.happiness >= levelGoals.happiness &&
      metrics.population >= levelGoals.population
    ) {
      // Goals met!
      setGoalReached(true);
      
      // Award bonus
      const levelBonus = level * 100;
      setScore(prevScore => {
        const newScore = prevScore + levelBonus;
        onScoreChange(newScore);
        return newScore;
      });
      
      playSuccess();
      setMessage(`Level ${level} goals achieved! +${levelBonus} bonus points!`);
      
      setTimeout(() => {
        if (level < 3) {
          // Move to next level
          setLevel(level + 1);
          setGoalReached(false);
          initializeGame();
        } else {
          // Game completed
          endGame();
        }
      }, 2000);
    }
  };
  
  // End the game
  const endGame = () => {
    // Final bonus based on city metrics
    const finalBonus = Math.max(0, 
      - cityMetrics.energy * 5 // Bonus for energy production
      - cityMetrics.pollution * 5 // Bonus for pollution reduction
      + cityMetrics.happiness * 5 // Bonus for happiness
    );
    
    setScore(prevScore => {
      const newScore = prevScore + finalBonus;
      onScoreChange(newScore);
      return newScore;
    });
    
    setMessage(`Game Over! City sustainability bonus: +${finalBonus} points!`);
    setTimeout(() => {
      onComplete(score + finalBonus);
    }, 2000);
  };
  
  return (
    <div className="h-full w-full relative overflow-hidden">
      {/* City background */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-200 to-green-100"></div>
      
      {!gameStarted ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl p-6 shadow-lg max-w-md text-center"
          >
            <h2 className="text-2xl font-bold text-emerald-700 mb-3">Green City Builder</h2>
            <p className="text-gray-700 mb-4">
              Design an eco-friendly city! Place buildings and renewable energy sources to create a sustainable urban environment.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-emerald-500 text-white font-bold py-3 px-8 rounded-full"
              onClick={handleStart}
            >
              Start Building!
            </motion.button>
          </motion.div>
          
          <div className="absolute bottom-10 left-10">
            <CharacterGuide text="Cities can be sustainable too! Let's build a green city with clean energy and lots of parks!" />
          </div>
        </div>
      ) : (
        <div className="h-full w-full relative flex" ref={gameAreaRef}>
          {/* City grid */}
          <div className="flex-1 p-6">
            <div className="bg-white/50 backdrop-blur-sm rounded-lg p-4 shadow-md mb-4 flex justify-between items-center">
              <div>
                <h2 className="text-lg font-bold text-emerald-800">Green City Builder - Level {level}</h2>
                <p className="text-sm text-gray-600">Place buildings on the grid to create a sustainable city</p>
              </div>
              <div className="text-2xl font-bold text-emerald-700">
                Score: {score}
              </div>
            </div>
            
            {/* City metrics */}
            <div className="grid grid-cols-4 gap-2 mb-4">
              <div className="bg-blue-100 rounded-lg p-2 text-center">
                <div className="text-xs text-gray-600">Energy Balance</div>
                <div className={`text-xl font-bold ${cityMetrics.energy <= 0 ? 'text-green-600' : 'text-red-500'}`}>
                  {cityMetrics.energy <= 0 ? cityMetrics.energy : `+${cityMetrics.energy}`}
                </div>
              </div>
              <div className="bg-green-100 rounded-lg p-2 text-center">
                <div className="text-xs text-gray-600">Pollution Level</div>
                <div className={`text-xl font-bold ${cityMetrics.pollution <= 0 ? 'text-green-600' : 'text-red-500'}`}>
                  {cityMetrics.pollution <= 0 ? cityMetrics.pollution : `+${cityMetrics.pollution}`}
                </div>
              </div>
              <div className="bg-yellow-100 rounded-lg p-2 text-center">
                <div className="text-xs text-gray-600">Happiness</div>
                <div className="text-xl font-bold text-yellow-600">
                  {cityMetrics.happiness}
                </div>
              </div>
              <div className="bg-purple-100 rounded-lg p-2 text-center">
                <div className="text-xs text-gray-600">Population</div>
                <div className="text-xl font-bold text-purple-600">
                  {cityMetrics.population}
                </div>
              </div>
            </div>
            
            {/* Message */}
            {message && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="mb-4 py-2 px-4 rounded-lg bg-emerald-100 text-emerald-800 text-center"
              >
                {message}
              </motion.div>
            )}
            
            {/* Grid */}
            <div className="bg-emerald-50 rounded-lg p-2 inline-block">
              {grid.map((row, y) => (
                <div key={`row-${y}`} className="flex">
                  {row.map((tile, x) => (
                    <div
                      key={`tile-${x}-${y}`}
                      className={`w-${TILE_SIZE / 4} h-${TILE_SIZE / 4} w-20 h-20 border border-emerald-200 m-0.5 ${
                        tile.occupied ? 'bg-emerald-100' : 'bg-white hover:bg-emerald-50 cursor-pointer'
                      }`}
                      onClick={() => !tile.occupied && selectedBuilding ? handlePlaceBuilding(x, y) : null}
                    >
                      {tile.buildingId && (
                        <motion.div 
                          initial={{ scale: 0.5, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          className="w-full h-full flex flex-col items-center justify-center"
                        >
                          <div className="text-4xl">
                            {buildings.find(b => b.id === tile.buildingId)?.emoji}
                          </div>
                          <div className="text-xs font-medium mt-1">
                            {buildings.find(b => b.id === tile.buildingId)?.name}
                          </div>
                        </motion.div>
                      )}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
          
          {/* Building selection panel */}
          <div className="w-72 bg-white/80 backdrop-blur-sm border-l border-emerald-100 p-4 overflow-y-auto">
            <h3 className="font-bold text-emerald-800 mb-2">Available Buildings</h3>
            
            <div className="space-y-2">
              {buildings.map(building => (
                <motion.div
                  key={building.id}
                  whileHover={!building.placed ? { scale: 1.02 } : {}}
                  whileTap={!building.placed ? { scale: 0.98 } : {}}
                  className={`p-2 rounded-lg cursor-pointer flex items-center space-x-3 ${
                    building.placed ? 'bg-gray-100 opacity-50 cursor-not-allowed' : 
                    selectedBuilding === building.id ? 'bg-emerald-200 ring-2 ring-emerald-500' : 
                    'bg-emerald-50 hover:bg-emerald-100'
                  }`}
                  onClick={() => !building.placed && handleSelectBuilding(building.id)}
                >
                  <div className="text-3xl">{building.emoji}</div>
                  <div>
                    <div className="font-medium text-sm">{building.name}</div>
                    <div className="flex space-x-2 text-xs mt-1">
                      <span className={`${building.energy <= 0 ? 'text-green-600' : 'text-red-500'}`}>
                        {building.energy <= 0 ? building.energy : `+${building.energy}`} ⚡
                      </span>
                      <span className={`${building.pollution <= 0 ? 'text-green-600' : 'text-red-500'}`}>
                        {building.pollution <= 0 ? building.pollution : `+${building.pollution}`} 🏭
                      </span>
                      <span className={`${building.happiness >= 0 ? 'text-green-600' : 'text-red-500'}`}>
                        {building.happiness >= 0 ? `+${building.happiness}` : building.happiness} 😊
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
            
            {/* Level goals */}
            <div className="mt-6 bg-blue-50 p-3 rounded-lg">
              <h4 className="font-bold text-blue-800 mb-2">Level {level} Goals</h4>
              <ul className="text-sm space-y-1">
                <li className="flex justify-between">
                  <span>Energy Balance:</span>
                  <span className={`font-medium ${cityMetrics.energy <= [0, -5, -10][level-1] ? 'text-green-600' : 'text-red-500'}`}>
                    {[0, -5, -10][level-1]} or less
                  </span>
                </li>
                <li className="flex justify-between">
                  <span>Pollution Level:</span>
                  <span className={`font-medium ${cityMetrics.pollution <= [0, -5, -10][level-1] ? 'text-green-600' : 'text-red-500'}`}>
                    {[0, -5, -10][level-1]} or less
                  </span>
                </li>
                <li className="flex justify-between">
                  <span>Happiness:</span>
                  <span className={`font-medium ${cityMetrics.happiness >= [10, 15, 20][level-1] ? 'text-green-600' : 'text-red-500'}`}>
                    {[10, 15, 20][level-1]} or more
                  </span>
                </li>
                <li className="flex justify-between">
                  <span>Population:</span>
                  <span className={`font-medium ${cityMetrics.population >= [3, 5, 8][level-1] ? 'text-green-600' : 'text-red-500'}`}>
                    {[3, 5, 8][level-1]} or more
                  </span>
                </li>
              </ul>
              
              {goalReached && (
                <div className="mt-2 p-2 bg-green-100 text-green-800 rounded text-sm font-medium text-center">
                  Level goals reached! 🎉
                </div>
              )}
            </div>
          </div>
          
          {/* Building info popup */}
          {buildingInfo && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-xl p-4 shadow-xl max-w-sm"
            >
              {(() => {
                const building = buildings.find(b => b.id === buildingInfo);
                if (!building) return null;
                return (
                  <>
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-xl font-bold text-emerald-700">{building.name}</h3>
                      <button 
                        className="text-gray-500 hover:text-gray-700"
                        onClick={() => setBuildingInfo(null)}
                      >
                        ✕
                      </button>
                    </div>
                    
                    <div className="flex items-center justify-center my-3">
                      <span className="text-6xl">{building.emoji}</span>
                    </div>
                    
                    <div className="mb-3">
                      <p className="text-gray-700">{building.description}</p>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-2 mb-3">
                      <div className={`p-2 rounded ${building.energy <= 0 ? 'bg-green-100' : 'bg-red-100'} text-center`}>
                        <div className="text-xs text-gray-600">Energy</div>
                        <div className={`font-bold ${building.energy <= 0 ? 'text-green-600' : 'text-red-500'}`}>
                          {building.energy <= 0 ? building.energy : `+${building.energy}`}
                        </div>
                      </div>
                      <div className={`p-2 rounded ${building.pollution <= 0 ? 'bg-green-100' : 'bg-red-100'} text-center`}>
                        <div className="text-xs text-gray-600">Pollution</div>
                        <div className={`font-bold ${building.pollution <= 0 ? 'text-green-600' : 'text-red-500'}`}>
                          {building.pollution <= 0 ? building.pollution : `+${building.pollution}`}
                        </div>
                      </div>
                      <div className={`p-2 rounded ${building.happiness >= 0 ? 'bg-green-100' : 'bg-red-100'} text-center`}>
                        <div className="text-xs text-gray-600">Happiness</div>
                        <div className={`font-bold ${building.happiness >= 0 ? 'text-green-600' : 'text-red-500'}`}>
                          {building.happiness >= 0 ? `+${building.happiness}` : building.happiness}
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-3 bg-blue-50 rounded-lg mb-3">
                      <h4 className="text-sm font-semibold text-blue-800 mb-1">Environmental Fact:</h4>
                      <p className="text-sm text-blue-700">{building.fact}</p>
                    </div>
                    
                    <div className="flex justify-end space-x-2">
                      <button 
                        className="bg-gray-100 text-gray-800 px-3 py-1 rounded-lg text-sm font-medium"
                        onClick={() => setBuildingInfo(null)}
                      >
                        Cancel
                      </button>
                      
                      {!building.placed && (
                        <button 
                          className="bg-emerald-100 text-emerald-800 px-3 py-1 rounded-lg text-sm font-medium"
                          onClick={() => {
                            setSelectedBuilding(building.id);
                            setBuildingInfo(null);
                          }}
                        >
                          Select
                        </button>
                      )}
                    </div>
                  </>
                );
              })()}
            </motion.div>
          )}
          
          {/* Terra character with tips */}
          <div className="absolute bottom-4 left-4">
            <CharacterGuide 
              text={level === 1 ? 
                "Start by placing some houses, then add parks to increase happiness!" : 
                level === 2 ? 
                "Try adding renewable energy like solar and wind to reduce your energy usage!" :
                "Balance population, pollution, and energy carefully to create a truly sustainable city!"
              }
              size="small"
              autoHide={true}
              hideDelay={8000}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default GreenCityBuilder;
