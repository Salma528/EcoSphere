import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useAudio } from "../lib/stores/useAudio";
import CharacterGuide from "../components/CharacterGuide";

// Weather types
type WeatherType = "sunny" | "rainy" | "snowy" | "stormy" | "drought";

interface Animal {
  id: string;
  name: string;
  type: string;
  emoji: string;
  needsHelp: boolean;
  adaptedTo: WeatherType[];
  position: {
    x: number;
    y: number;
  };
  helped: boolean;
  fact: string;
}

interface Adaptation {
  id: string;
  name: string;
  description: string;
  weatherType: WeatherType;
  emoji: string;
  used: boolean;
}

interface WeatherEvent {
  type: WeatherType;
  name: string;
  description: string;
  emoji: string;
  duration: number; // in seconds
  effects: string[];
}

interface WeatherWatcherProps {
  onComplete: (score: number) => void;
  onScoreChange: (score: number) => void;
}

const WeatherWatcher: React.FC<WeatherWatcherProps> = ({ onComplete, onScoreChange }) => {
  const [score, setScore] = useState(0);
  const [gameStarted, setGameStarted] = useState(false);
  const [currentWeather, setCurrentWeather] = useState<WeatherType>("sunny");
  const [weatherDuration, setWeatherDuration] = useState(0);
  const [animals, setAnimals] = useState<Animal[]>([]);
  const [adaptations, setAdaptations] = useState<Adaptation[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [selectedAdaptation, setSelectedAdaptation] = useState<string | null>(null);
  const [showFact, setShowFact] = useState<string | null>(null);
  const [animalsHelped, setAnimalsHelped] = useState(0);
  const [totalRounds, setTotalRounds] = useState(0);
  const [timeLeft, setTimeLeft] = useState(180); // 3 minutes total game time
  
  const gameAreaRef = useRef<HTMLDivElement>(null);
  const weatherIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  const { playHit, playSuccess } = useAudio();
  
  // Weather event data
  const weatherEvents: WeatherEvent[] = [
    {
      type: "sunny",
      name: "Sunny Day",
      description: "It's a warm sunny day with clear skies.",
      emoji: "☀️",
      duration: 15, // seconds
      effects: ["Plants grow well", "Solar energy is abundant", "Some animals may get too hot"]
    },
    {
      type: "rainy",
      name: "Heavy Rain",
      description: "Rain is pouring down heavily.",
      emoji: "🌧️",
      duration: 15,
      effects: ["Plants receive water", "Rivers may flood", "Some animals need shelter"]
    },
    {
      type: "snowy",
      name: "Snowfall",
      description: "Snow is covering the ground.",
      emoji: "❄️",
      duration: 15,
      effects: ["Plants dormant", "Water freezes", "Animals need warmth"]
    },
    {
      type: "stormy",
      name: "Severe Storm",
      description: "Strong winds and lightning sweep through the area.",
      emoji: "⛈️",
      duration: 15,
      effects: ["Trees may fall", "Power outages", "Animals need safe shelter"]
    },
    {
      type: "drought",
      name: "Drought Conditions",
      description: "It hasn't rained in weeks, causing drought.",
      emoji: "🏜️",
      duration: 15,
      effects: ["Plants wither", "Water sources dry up", "Animals struggle to find water"]
    }
  ];
  
  // Animal data
  const animalData: Omit<Animal, "position" | "needsHelp" | "helped">[] = [
    {
      id: "animal-1",
      name: "Polar Bear",
      type: "mammal",
      emoji: "🐻‍❄️",
      adaptedTo: ["snowy"],
      fact: "Polar bears have a layer of fat up to 4 inches thick and a water-repellent coat to help stay warm in cold conditions."
    },
    {
      id: "animal-2",
      name: "Camel",
      type: "mammal",
      emoji: "🐪",
      adaptedTo: ["sunny", "drought"],
      fact: "Camels can drink up to 40 gallons of water at once and go a week or more without water."
    },
    {
      id: "animal-3",
      name: "Frog",
      type: "amphibian",
      emoji: "🐸",
      adaptedTo: ["rainy"],
      fact: "Many frogs can absorb water through their skin, allowing them to stay hydrated without drinking."
    },
    {
      id: "animal-4",
      name: "Eagle",
      type: "bird",
      emoji: "🦅",
      adaptedTo: ["sunny", "stormy"],
      fact: "Eagles have special airways in their nostrils that reduce wind impact during high-speed dives."
    },
    {
      id: "animal-5",
      name: "Fox",
      type: "mammal",
      emoji: "🦊",
      adaptedTo: ["snowy", "sunny"],
      fact: "Arctic foxes change their coat color with the seasons - white in winter for camouflage in snow, and brown in summer."
    },
    {
      id: "animal-6",
      name: "Desert Tortoise",
      type: "reptile",
      emoji: "🐢",
      adaptedTo: ["sunny", "drought"],
      fact: "Desert tortoises can go up to a year without water and store water in their bladder for future use."
    },
    {
      id: "animal-7",
      name: "Penguin",
      type: "bird",
      emoji: "🐧",
      adaptedTo: ["snowy", "rainy"],
      fact: "Penguins have a special gland that removes salt from the seawater they drink."
    },
    {
      id: "animal-8",
      name: "Duck",
      type: "bird",
      emoji: "🦆",
      adaptedTo: ["rainy", "sunny"],
      fact: "Ducks have waterproof feathers that help them stay dry even in heavy rain."
    }
  ];
  
  // Adaptation data
  const adaptationData: Omit<Adaptation, "used">[] = [
    {
      id: "adapt-1",
      name: "Rain Shelter",
      description: "Provides shelter from rain and storms",
      weatherType: "rainy",
      emoji: "🏠"
    },
    {
      id: "adapt-2",
      name: "Warm Blanket",
      description: "Keeps animals warm in cold weather",
      weatherType: "snowy",
      emoji: "🧣"
    },
    {
      id: "adapt-3",
      name: "Shade Structure",
      description: "Provides shade during hot sunny days",
      weatherType: "sunny",
      emoji: "⛱️"
    },
    {
      id: "adapt-4",
      name: "Water Supply",
      description: "Provides water during drought conditions",
      weatherType: "drought",
      emoji: "💧"
    },
    {
      id: "adapt-5",
      name: "Wind Barrier",
      description: "Protects animals from strong winds during storms",
      weatherType: "stormy",
      emoji: "🧱"
    },
    {
      id: "adapt-6",
      name: "Cooling Fan",
      description: "Helps animals cool down in hot weather",
      weatherType: "sunny",
      emoji: "🌀"
    },
    {
      id: "adapt-7",
      name: "Flood Platform",
      description: "Keeps animals above rising water levels",
      weatherType: "rainy",
      emoji: "🏝️"
    },
    {
      id: "adapt-8",
      name: "Lightning Rod",
      description: "Diverts lightning away from animals during storms",
      weatherType: "stormy",
      emoji: "⚡"
    }
  ];
  
  // Start the game
  const handleStart = () => {
    setGameStarted(true);
    initializeGame();
    
    // Start main game timer
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          endGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    // Start weather cycle
    startWeatherCycle();
  };
  
  // Initialize the game
  const initializeGame = () => {
    // Position animals on the screen
    if (gameAreaRef.current) {
      const rect = gameAreaRef.current.getBoundingClientRect();
      const padding = 60; // Stay away from edges
      
      // Start with 5 random animals
      const shuffledAnimals = [...animalData].sort(() => Math.random() - 0.5).slice(0, 5);
      
      const positionedAnimals = shuffledAnimals.map(animal => {
        const x = padding + Math.random() * (rect.width - padding * 2);
        const y = padding + Math.random() * (rect.height - padding * 2);
        
        return {
          ...animal,
          position: { x, y },
          needsHelp: false,
          helped: false
        };
      });
      
      setAnimals(positionedAnimals);
    }
    
    // Initialize adaptations
    const initialAdaptations = adaptationData.map(adaptation => ({
      ...adaptation,
      used: false
    }));
    
    setAdaptations(initialAdaptations);
    
    // Set initial weather
    setCurrentWeather("sunny");
    setWeatherDuration(15);
  };
  
  // Start weather cycle
  const startWeatherCycle = () => {
    weatherIntervalRef.current = setInterval(() => {
      changeWeather();
    }, 15000); // Change weather every 15 seconds
  };
  
  // Change weather
  const changeWeather = () => {
    // Get available weather types (excluding current)
    const availableWeather = weatherEvents
      .filter(event => event.type !== currentWeather)
      .map(event => event.type);
    
    // Select random weather
    const newWeather = availableWeather[Math.floor(Math.random() * availableWeather.length)];
    
    setCurrentWeather(newWeather);
    setTotalRounds(prev => prev + 1);
    setMessage(`Weather changing to: ${weatherEvents.find(e => e.type === newWeather)?.name}`);
    
    // Reset weather duration
    const weatherEvent = weatherEvents.find(e => e.type === newWeather);
    if (weatherEvent) {
      setWeatherDuration(weatherEvent.duration);
    }
    
    // Update animals that need help
    updateAnimalsNeedingHelp(newWeather);
    
    setTimeout(() => setMessage(null), 2000);
  };
  
  // Update animals that need help based on weather
  const updateAnimalsNeedingHelp = (weatherType: WeatherType) => {
    setAnimals(prev => {
      return prev.map(animal => {
        // An animal needs help if it's not adapted to the current weather
        const needsHelp = !animal.adaptedTo.includes(weatherType) && !animal.helped;
        
        return {
          ...animal,
          needsHelp
        };
      });
    });
  };
  
  // Handle selecting an adaptation
  const handleSelectAdaptation = (adaptationId: string) => {
    const adaptation = adaptations.find(a => a.id === adaptationId);
    if (!adaptation || adaptation.used) return;
    
    setSelectedAdaptation(adaptationId);
    setMessage(`Selected: ${adaptation.name}. Click on an animal that needs help!`);
  };
  
  // Handle using an adaptation on an animal
  const handleHelpAnimal = (animalId: string) => {
    if (!selectedAdaptation) return;
    
    const animal = animals.find(a => a.id === animalId);
    const adaptation = adaptations.find(a => a.id === selectedAdaptation);
    
    if (!animal || !adaptation || animal.helped || !animal.needsHelp) return;
    
    // Check if adaptation works for current weather
    if (adaptation.weatherType === currentWeather) {
      // Effective adaptation
      const pointsEarned = 50;
      
      setAnimals(prev => 
        prev.map(a => 
          a.id === animalId ? {
            ...a,
            needsHelp: false,
            helped: true
          } : a
        )
      );
      
      // Mark adaptation as used
      setAdaptations(prev => 
        prev.map(a => 
          a.id === selectedAdaptation ? {
            ...a,
            used: true
          } : a
        )
      );
      
      // Award points
      setScore(prevScore => {
        const newScore = prevScore + pointsEarned;
        onScoreChange(newScore);
        return newScore;
      });
      
      setAnimalsHelped(prev => prev + 1);
      
      playSuccess();
      setMessage(`+${pointsEarned} points! ${animal.name} is now safe from the ${adaptation.weatherType} weather!`);
      
      // Show fact about animal
      setTimeout(() => {
        setMessage(null);
        setShowFact(animalId);
      }, 2000);
    } else {
      // Ineffective adaptation
      playHit();
      setMessage(`${adaptation.name} doesn't help with ${currentWeather} weather. Try a different adaptation!`);
    }
    
    setSelectedAdaptation(null);
  };
  
  // End the game
  const endGame = () => {
    if (weatherIntervalRef.current) clearInterval(weatherIntervalRef.current);
    if (timerRef.current) clearInterval(timerRef.current);
    
    // Calculate final score with bonus for animals helped
    const helpedBonus = animalsHelped * 20;
    
    setScore(prevScore => {
      const newScore = prevScore + helpedBonus;
      onScoreChange(newScore);
      return newScore;
    });
    
    setMessage(`Game Over! Animals helped bonus: +${helpedBonus} points!`);
    setTimeout(() => {
      onComplete(score + helpedBonus);
    }, 2000);
  };
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (weatherIntervalRef.current) clearInterval(weatherIntervalRef.current);
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  return (
    <div className="h-full w-full relative overflow-hidden">
      {/* Weather background */}
      <div className={`absolute inset-0 transition-colors duration-1000 ${
        currentWeather === "sunny" ? "bg-gradient-to-b from-blue-300 to-yellow-100" :
        currentWeather === "rainy" ? "bg-gradient-to-b from-blue-400 to-blue-200" :
        currentWeather === "snowy" ? "bg-gradient-to-b from-blue-100 to-gray-100" :
        currentWeather === "stormy" ? "bg-gradient-to-b from-gray-700 to-gray-500" :
        "bg-gradient-to-b from-yellow-400 to-yellow-200" // drought
      }`}>
        {/* Weather effects */}
        {currentWeather === "rainy" && (
          <div className="absolute inset-0 pointer-events-none">
            {[...Array(40)].map((_, i) => (
              <motion.div
                key={`rain-${i}`}
                className="absolute w-1 h-10 bg-blue-400 opacity-70"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `-10px`,
                }}
                animate={{
                  y: [0, 800],
                  opacity: [0.7, 0.5, 0.3]
                }}
                transition={{
                  duration: 1 + Math.random(),
                  repeat: Infinity,
                  delay: Math.random() * 2
                }}
              />
            ))}
          </div>
        )}
        
        {currentWeather === "snowy" && (
          <div className="absolute inset-0 pointer-events-none">
            {[...Array(30)].map((_, i) => (
              <motion.div
                key={`snow-${i}`}
                className="absolute w-2 h-2 bg-white rounded-full opacity-80"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `-10px`,
                }}
                animate={{
                  y: [0, 800],
                  x: [0, Math.random() * 50 - 25]
                }}
                transition={{
                  duration: 5 + Math.random() * 5,
                  repeat: Infinity,
                  delay: Math.random() * 5
                }}
              />
            ))}
          </div>
        )}
        
        {currentWeather === "stormy" && (
          <div className="absolute inset-0 pointer-events-none">
            {/* Random lightning flashes */}
            <motion.div
              className="absolute inset-0 bg-white opacity-0"
              animate={{
                opacity: [0, 0.8, 0]
              }}
              transition={{
                duration: 0.3,
                repeat: Infinity,
                repeatDelay: 5 + Math.random() * 10
              }}
            />
            
            {/* Wind-blown objects */}
            {[...Array(10)].map((_, i) => (
              <motion.div
                key={`leaf-${i}`}
                className="absolute w-3 h-3 bg-green-500 opacity-70 rounded-full"
                style={{
                  left: `-10px`,
                  top: `${50 + Math.random() * 300}px`,
                }}
                animate={{
                  x: [0, 1000],
                  rotate: [0, 360]
                }}
                transition={{
                  duration: 3 + Math.random() * 2,
                  repeat: Infinity,
                  delay: Math.random() * 5
                }}
              />
            ))}
          </div>
        )}
        
        {currentWeather === "drought" && (
          <div className="absolute inset-0 pointer-events-none">
            {/* Heat waves */}
            <motion.div
              className="absolute bottom-0 inset-x-0 h-20 bg-gradient-to-t from-yellow-500 to-transparent opacity-30"
              animate={{
                opacity: [0.2, 0.4, 0.2]
              }}
              transition={{
                duration: 3,
                repeat: Infinity
              }}
            />
          </div>
        )}
      </div>
      
      {!gameStarted ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl p-6 shadow-lg max-w-md text-center"
          >
            <h2 className="text-2xl font-bold text-blue-700 mb-3">Weather Watcher</h2>
            <p className="text-gray-700 mb-4">
              Learn about climate change and help animals adapt to different weather conditions! Use adaptations to keep them safe.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-blue-500 text-white font-bold py-3 px-8 rounded-full"
              onClick={handleStart}
            >
              Start Watching!
            </motion.button>
          </motion.div>
          
          <div className="absolute bottom-10 left-10">
            <CharacterGuide text="Weather is changing around the world. Let's learn how to help animals adapt to different conditions!" />
          </div>
        </div>
      ) : (
        <div className="h-full w-full relative" ref={gameAreaRef}>
          {/* Game UI */}
          <div className="absolute top-4 left-4 bg-white/80 backdrop-blur-sm rounded-lg p-3 shadow flex space-x-4">
            <div>
              <div className="text-xs text-gray-500">Score</div>
              <div className="text-2xl font-bold text-blue-700">{score}</div>
            </div>
            <div>
              <div className="text-xs text-gray-500">Time</div>
              <div className={`text-2xl font-bold ${timeLeft <= 30 ? 'text-red-500' : 'text-blue-600'}`}>
                {timeLeft}s
              </div>
            </div>
            <div>
              <div className="text-xs text-gray-500">Animals Helped</div>
              <div className="text-2xl font-bold text-green-600">{animalsHelped}</div>
            </div>
          </div>
          
          {/* Current weather info */}
          <div className="absolute top-4 right-4 bg-white/80 backdrop-blur-sm rounded-lg p-3 shadow max-w-xs">
            <div className="flex items-center space-x-2">
              <div className="text-4xl">
                {weatherEvents.find(e => e.type === currentWeather)?.emoji}
              </div>
              <div>
                <h3 className="font-semibold text-blue-800">
                  {weatherEvents.find(e => e.type === currentWeather)?.name}
                </h3>
                <p className="text-xs text-gray-600">
                  {weatherEvents.find(e => e.type === currentWeather)?.description}
                </p>
              </div>
            </div>
            
            <div className="mt-2">
              <h4 className="text-xs font-medium text-gray-700">Effects:</h4>
              <ul className="text-xs text-gray-600 list-disc pl-4">
                {weatherEvents.find(e => e.type === currentWeather)?.effects.map((effect, i) => (
                  <li key={i}>{effect}</li>
                ))}
              </ul>
            </div>
          </div>
          
          {/* Message */}
          {message && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="absolute top-20 left-1/2 transform -translate-x-1/2 py-2 px-4 rounded-lg bg-blue-100 text-blue-800"
            >
              {message}
            </motion.div>
          )}
          
          {/* Animals */}
          {animals.map(animal => (
            <motion.div
              key={animal.id}
              className={`absolute cursor-pointer ${animal.helped ? 'opacity-70' : 'opacity-100'}`}
              style={{ 
                left: animal.position.x - 30, 
                top: animal.position.y - 30 
              }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => animal.needsHelp && !animal.helped ? handleHelpAnimal(animal.id) : null}
            >
              <div className="relative flex flex-col items-center">
                <div className="text-5xl">{animal.emoji}</div>
                <div className="mt-1 text-xs bg-white/80 backdrop-blur-sm px-2 py-1 rounded font-medium">
                  {animal.name}
                </div>
                
                {/* Help indicator */}
                {animal.needsHelp && !animal.helped && (
                  <motion.div
                    className="absolute -top-4 -right-4 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white font-bold"
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ repeat: Infinity, duration: 1 }}
                  >
                    !
                  </motion.div>
                )}
                
                {/* Helped indicator */}
                {animal.helped && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="absolute -top-4 -right-4 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white"
                  >
                    ✓
                  </motion.div>
                )}
              </div>
            </motion.div>
          ))}
          
          {/* Adaptations */}
          <div className="absolute bottom-4 left-4 right-4 bg-white/80 backdrop-blur-sm rounded-lg p-3 shadow">
            <h3 className="font-semibold text-blue-800 mb-2">Climate Adaptations</h3>
            <div className="flex flex-wrap gap-2">
              {adaptations.map(adaptation => (
                <motion.div
                  key={adaptation.id}
                  whileHover={!adaptation.used ? { scale: 1.05 } : {}}
                  whileTap={!adaptation.used ? { scale: 0.95 } : {}}
                  className={`px-3 py-2 rounded-lg cursor-pointer flex flex-col items-center ${
                    adaptation.used ? 'opacity-50 cursor-not-allowed' : 
                    selectedAdaptation === adaptation.id ? 'bg-blue-500 text-white' : 
                    'bg-blue-100 text-blue-800'
                  }`}
                  onClick={() => !adaptation.used && handleSelectAdaptation(adaptation.id)}
                >
                  <div className="flex items-center space-x-2">
                    <span className="text-xl">{adaptation.emoji}</span>
                    <span className="text-sm font-medium">{adaptation.name}</span>
                  </div>
                  <span className="text-xs mt-1">For: {adaptation.weatherType}</span>
                </motion.div>
              ))}
            </div>
          </div>
          
          {/* Animal fact popup */}
          {showFact && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-xl p-4 shadow-xl max-w-sm"
            >
              {(() => {
                const animal = animals.find(a => a.id === showFact);
                if (!animal) return null;
                return (
                  <>
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-xl font-bold text-blue-700">{animal.name}</h3>
                      <button 
                        className="text-gray-500 hover:text-gray-700"
                        onClick={() => setShowFact(null)}
                      >
                        ✕
                      </button>
                    </div>
                    
                    <div className="flex items-center justify-center my-3">
                      <span className="text-6xl">{animal.emoji}</span>
                    </div>
                    
                    <div className="mb-3">
                      <p className="text-gray-700">{animal.fact}</p>
                    </div>
                    
                    <div className="mb-3 p-2 bg-blue-100 text-blue-800 rounded">
                      <h4 className="text-sm font-semibold mb-1">Natural Adaptations:</h4>
                      <p className="text-xs">This animal is naturally adapted to:</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {animal.adaptedTo.map(weather => (
                          <span key={weather} className="px-2 py-1 bg-blue-200 text-blue-800 rounded-full text-xs">
                            {weather} weather
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex justify-end">
                      <button 
                        className="bg-blue-100 text-blue-800 px-3 py-1 rounded-lg text-sm font-medium"
                        onClick={() => setShowFact(null)}
                      >
                        Continue Helping
                      </button>
                    </div>
                  </>
                );
              })()}
            </motion.div>
          )}
          
          {/* Terra character with tips */}
          <div className="absolute top-16 left-4">
            <CharacterGuide 
              text={`The weather is now ${weatherEvents.find(e => e.type === currentWeather)?.name}! Some animals need help adapting. Select the right adaptation for this weather.`}
              position="left"
              size="small"
              autoHide={true}
              hideDelay={8000}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default WeatherWatcher;
