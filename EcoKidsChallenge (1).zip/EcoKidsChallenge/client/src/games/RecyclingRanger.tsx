import { useState, useEffect, useRef } from "react";
import { motion, useAnimation } from "framer-motion";
import { useAudio } from "../lib/stores/useAudio";
import CharacterGuide from "../components/CharacterGuide";

interface Item {
  id: string;
  name: string;
  type: "paper" | "plastic" | "glass" | "metal" | "organic";
  emoji: string;
  dragging: boolean;
  position: { x: number; y: number };
}

interface Bin {
  id: string;
  type: "paper" | "plastic" | "glass" | "metal" | "organic";
  name: string;
  color: string;
  emoji: string;
}

interface RecyclingRangerProps {
  onComplete: (score: number) => void;
  onScoreChange: (score: number) => void;
}

const RecyclingRanger: React.FC<RecyclingRangerProps> = ({ onComplete, onScoreChange }) => {
  const [score, setScore] = useState(0);
  const [items, setItems] = useState<Item[]>([]);
  const [timeLeft, setTimeLeft] = useState(60); // 60 seconds game
  const [gameStarted, setGameStarted] = useState(false);
  const [feedback, setFeedback] = useState<{ message: string; correct: boolean } | null>(null);
  const { playHit, playSuccess } = useAudio();
  
  const gameAreaRef = useRef<HTMLDivElement>(null);
  const draggedItemRef = useRef<Item | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Define recycling bins
  const bins: Bin[] = [
    { id: "bin-paper", type: "paper", name: "Paper", color: "bg-blue-500", emoji: "📄" },
    { id: "bin-plastic", type: "plastic", name: "Plastic", color: "bg-yellow-500", emoji: "🥤" },
    { id: "bin-glass", type: "glass", name: "Glass", color: "bg-green-500", emoji: "🍶" },
    { id: "bin-metal", type: "metal", name: "Metal", color: "bg-red-500", emoji: "🥫" },
    { id: "bin-organic", type: "organic", name: "Organic", color: "bg-brown-500", emoji: "🍎" }
  ];
  
  // Items to sort
  const itemsData: Omit<Item, "position" | "dragging">[] = [
    { id: "item-1", name: "Newspaper", type: "paper", emoji: "📰" },
    { id: "item-2", name: "Water Bottle", type: "plastic", emoji: "🧴" },
    { id: "item-3", name: "Glass Jar", type: "glass", emoji: "🫙" },
    { id: "item-4", name: "Soda Can", type: "metal", emoji: "🥫" },
    { id: "item-5", name: "Banana Peel", type: "organic", emoji: "🍌" },
    { id: "item-6", name: "Cardboard Box", type: "paper", emoji: "📦" },
    { id: "item-7", name: "Plastic Bag", type: "plastic", emoji: "🛍️" },
    { id: "item-8", name: "Glass Bottle", type: "glass", emoji: "🍾" },
    { id: "item-9", name: "Aluminum Foil", type: "metal", emoji: "✨" },
    { id: "item-10", name: "Apple Core", type: "organic", emoji: "🍎" },
    { id: "item-11", name: "Magazine", type: "paper", emoji: "📔" },
    { id: "item-12", name: "Yogurt Container", type: "plastic", emoji: "🥛" },
    { id: "item-13", name: "Pickle Jar", type: "glass", emoji: "🥒" },
    { id: "item-14", name: "Soup Can", type: "metal", emoji: "🥣" },
    { id: "item-15", name: "Orange Peel", type: "organic", emoji: "🍊" }
  ];
  
  // Start the game
  const handleStart = () => {
    setGameStarted(true);
    generateNewItems();
    
    // Start the timer
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          // End game when timer hits 0
          clearInterval(timerRef.current!);
          onComplete(score);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };
  
  // Generate new items to sort
  const generateNewItems = () => {
    if (!gameAreaRef.current) return;
    
    const gameArea = gameAreaRef.current.getBoundingClientRect();
    const itemsToGenerate = Math.min(6, itemsData.length); // Generate up to 6 items at a time
    
    // Randomly select items
    const shuffled = [...itemsData].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, itemsToGenerate);
    
    const newItems = selected.map((item, index) => {
      // Position items in the upper part of the game area
      const x = 100 + (index % 3) * 150;
      const y = 100 + Math.floor(index / 3) * 130;
      
      return {
        ...item,
        dragging: false,
        position: { x, y }
      };
    });
    
    setItems(newItems);
  };
  
  // Handle item dragging
  const handleDragStart = (item: Item) => {
    draggedItemRef.current = item;
    
    setItems(items.map(i => 
      i.id === item.id ? { ...i, dragging: true } : i
    ));
  };
  
  // Handle item being dragged
  const handleDrag = (item: Item, info: { point: { x: number; y: number } }) => {
    setItems(items.map(i => 
      i.id === item.id ? { ...i, position: info.point } : i
    ));
  };
  
  // Handle item being dropped
  const handleDragEnd = (item: Item) => {
    // Check if item is dropped on a bin
    const itemElement = document.getElementById(item.id);
    if (!itemElement) return;
    
    const itemBounds = itemElement.getBoundingClientRect();
    
    // Check collision with each bin
    let droppedOnBin = false;
    for (const bin of bins) {
      const binElement = document.getElementById(bin.id);
      if (!binElement) continue;
      
      const binBounds = binElement.getBoundingClientRect();
      
      // Check if item is over the bin
      if (
        itemBounds.right > binBounds.left &&
        itemBounds.left < binBounds.right &&
        itemBounds.bottom > binBounds.top &&
        itemBounds.top < binBounds.bottom
      ) {
        droppedOnBin = true;
        
        // Check if correct bin
        if (item.type === bin.type) {
          // Correct bin - add points
          const pointsEarned = 100 + Math.floor(timeLeft / 2); // More points for faster sorting
          setScore(prev => {
            const newScore = prev + pointsEarned;
            onScoreChange(newScore);
            return newScore;
          });
          
          playSuccess();
          setFeedback({ message: `+${pointsEarned} points! Correct bin!`, correct: true });
        } else {
          // Wrong bin - lose points
          const pointsLost = 50;
          setScore(prev => {
            const newScore = Math.max(0, prev - pointsLost);
            onScoreChange(newScore);
            return newScore;
          });
          
          playHit();
          setFeedback({ 
            message: `-${pointsLost} points! "${item.name}" goes in the ${item.type} bin.`, 
            correct: false 
          });
        }
        
        // Remove the item
        setItems(items.filter(i => i.id !== item.id));
        break;
      }
    }
    
    // If not dropped on a bin, return to original position
    if (!droppedOnBin) {
      setItems(items.map(i => 
        i.id === item.id ? { ...i, dragging: false } : i
      ));
    }
    
    // Generate new items if all have been sorted
    if (items.length === 1 || items.length <= 3) {
      generateNewItems();
    }
    
    // Clear feedback after 2 seconds
    setTimeout(() => {
      setFeedback(null);
    }, 2000);
  };
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  return (
    <div className="h-full w-full relative overflow-hidden">
      {/* Game background */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-100 to-green-50"></div>
      
      {/* Recycling center decorations */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-10 left-10">
          <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="10" y="40" width="80" height="60" fill="#8B5A2B" />
            <rect x="20" y="20" width="60" height="20" fill="#8B5A2B" />
            <rect x="40" y="0" width="20" height="20" fill="#8B5A2B" />
            <circle cx="50" cy="60" r="15" fill="#76B947" />
          </svg>
        </div>
        
        <div className="absolute top-10 right-10">
          <svg width="120" height="80" viewBox="0 0 120 80" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="0" y="30" width="120" height="50" fill="#888" />
            <rect x="10" y="40" width="100" height="30" fill="#999" />
            <rect x="20" y="0" width="10" height="30" fill="#777" />
            <rect x="90" y="0" width="10" height="30" fill="#777" />
          </svg>
        </div>
      </div>
      
      {!gameStarted ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl p-6 shadow-lg max-w-md text-center"
          >
            <h2 className="text-2xl font-bold text-emerald-700 mb-3">Recycling Ranger</h2>
            <p className="text-gray-700 mb-4">
              Sort waste into the correct recycling bins! Drag each item to its proper bin and earn points.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-emerald-500 text-white font-bold py-3 px-8 rounded-full"
              onClick={handleStart}
            >
              Start Sorting!
            </motion.button>
          </motion.div>
          
          <div className="absolute bottom-10 left-10">
            <CharacterGuide text="Let's keep our planet clean by recycling! I'll help you sort everything correctly." />
          </div>
        </div>
      ) : (
        <div className="h-full w-full" ref={gameAreaRef}>
          {/* Game UI */}
          <div className="absolute top-4 left-4 bg-white/80 backdrop-blur-sm rounded-lg p-3 shadow flex space-x-4">
            <div>
              <div className="text-xs text-gray-500">Score</div>
              <div className="text-2xl font-bold text-emerald-700">{score}</div>
            </div>
            <div>
              <div className="text-xs text-gray-500">Time</div>
              <div className={`text-2xl font-bold ${timeLeft <= 10 ? 'text-red-500' : 'text-blue-600'}`}>
                {timeLeft}s
              </div>
            </div>
          </div>
          
          {/* Feedback message */}
          {feedback && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className={`absolute top-16 left-1/2 transform -translate-x-1/2 py-2 px-4 rounded-lg ${
                feedback.correct ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
              }`}
            >
              {feedback.message}
            </motion.div>
          )}
          
          {/* Recycling bins */}
          <div className="absolute bottom-8 left-0 right-0 flex justify-evenly">
            {bins.map(bin => (
              <div 
                key={bin.id} 
                id={bin.id}
                className={`${bin.color} w-24 h-32 rounded-t-lg border-2 border-gray-800 flex flex-col items-center justify-center shadow-lg`}
              >
                <div className="text-4xl mb-1">{bin.emoji}</div>
                <div className="bg-white py-1 px-3 rounded-lg text-xs font-bold">
                  {bin.name}
                </div>
              </div>
            ))}
          </div>
          
          {/* Draggable items */}
          {items.map(item => (
            <motion.div
              key={item.id}
              id={item.id}
              className={`absolute cursor-grab active:cursor-grabbing bg-white rounded-lg p-3 shadow-md ${
                item.dragging ? 'z-10 shadow-xl' : 'z-0'
              }`}
              drag
              dragConstraints={gameAreaRef}
              onDragStart={() => handleDragStart(item)}
              onDrag={(_, info) => handleDrag(item, info)}
              onDragEnd={() => handleDragEnd(item)}
              style={{
                x: item.position.x,
                y: item.position.y,
                opacity: item.dragging ? 0.8 : 1
              }}
            >
              <div className="flex flex-col items-center">
                <div className="text-4xl mb-1">{item.emoji}</div>
                <div className="text-xs font-medium text-gray-700">{item.name}</div>
              </div>
            </motion.div>
          ))}
          
          {/* Terra character with tips */}
          <div className="absolute top-16 right-4">
            <CharacterGuide 
              text={`Remember: Paper is blue, Plastic is yellow, Glass is green, Metal is red, and Organic is brown!`}
              position="right"
              size="small"
              autoHide={true}
              hideDelay={8000}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default RecyclingRanger;
