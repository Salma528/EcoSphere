import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import CharacterGuide from "../components/CharacterGuide";
import { useAudio } from "../lib/stores/useAudio";

interface ElectronicDevice {
  id: string;
  name: string;
  type: string;
  x: number;
  y: number;
  isOn: boolean;
  image: string;
}

interface EnergySource {
  id: string;
  name: string;
  type: "solar" | "wind" | "hydro" | "geothermal" | "biomass";
  image: string;
}

interface EnergyUse {
  id: string;
  name: string;
  type: "solar" | "wind" | "hydro" | "geothermal" | "biomass";
  image: string;
}

type GamePhase = "exploration" | "matching";

interface EnergyExplorerProps {
  onComplete: (score: number) => void;
  onScoreChange: (score: number) => void;
}

const EnergyExplorer: React.FC<EnergyExplorerProps> = ({ onComplete, onScoreChange }) => {
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);
  const [gameStarted, setGameStarted] = useState(false);
  const [gamePhase, setGamePhase] = useState<GamePhase>("exploration");
  const [devices, setDevices] = useState<ElectronicDevice[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [devicesFound, setDevicesFound] = useState(0);
  
  // Matching game state
  const [energySources, setEnergySources] = useState<EnergySource[]>([]);
  const [energyUses, setEnergyUses] = useState<EnergyUse[]>([]);
  const [selectedSource, setSelectedSource] = useState<string | null>(null);
  const [matchedPairs, setMatchedPairs] = useState<string[]>([]);
  
  const gameAreaRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  const { playHit, playSuccess } = useAudio();
  
  // Electronic device data
  const deviceData: Omit<ElectronicDevice, "x" | "y">[] = [
    { id: "device-1", name: "Television", type: "entertainment", isOn: true, image: "📺" },
    { id: "device-2", name: "Lamp", type: "lighting", isOn: true, image: "💡" },
    { id: "device-3", name: "Computer", type: "office", isOn: true, image: "💻" },
    { id: "device-4", name: "Air Conditioner", type: "climate", isOn: true, image: "❄️" },
    { id: "device-5", name: "Fan", type: "climate", isOn: true, image: "🌀" },
    { id: "device-6", name: "Game Console", type: "entertainment", isOn: true, image: "🎮" },
    { id: "device-7", name: "Microwave", type: "kitchen", isOn: true, image: "🔌" },
    { id: "device-8", name: "Radio", type: "entertainment", isOn: true, image: "📻" },
  ];
  
  // Energy sources and uses for matching
  const sourceData: EnergySource[] = [
    { id: "source-1", name: "Solar Panels", type: "solar", image: "☀️" },
    { id: "source-2", name: "Wind Turbines", type: "wind", image: "🌬️" },
    { id: "source-3", name: "Hydroelectric Dam", type: "hydro", image: "💧" },
    { id: "source-4", name: "Geothermal Plant", type: "geothermal", image: "♨️" },
    { id: "source-5", name: "Biomass", type: "biomass", image: "🌱" },
  ];
  
  const useData: EnergyUse[] = [
    { id: "use-1", name: "Powers Homes & Devices", type: "solar", image: "🏠" },
    { id: "use-2", name: "Generates Electricity", type: "wind", image: "⚡" },
    { id: "use-3", name: "Supplies Cities with Power", type: "hydro", image: "🏙️" },
    { id: "use-4", name: "Heats Buildings", type: "geothermal", image: "🔥" },
    { id: "use-5", name: "Creates Biofuel", type: "biomass", image: "🚗" },
  ];
  
  // Start the game
  const handleStart = () => {
    setGameStarted(true);
    
    // Use setTimeout to ensure the ref is mounted properly before getting dimensions
    setTimeout(() => {
      positionDevices();
      
      // Start the timer
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            // Move to matching phase or end game
            if (gamePhase === "exploration") {
              clearInterval(timerRef.current!);
              startMatchingPhase();
              return 60; // Reset timer for matching phase
            } else {
              clearInterval(timerRef.current!);
              onComplete(score);
              return 0;
            }
          }
          return prev - 1;
        });
      }, 1000);
    }, 100);
  };
  
  // Position electronic devices on the screen
  const positionDevices = () => {
    if (!gameAreaRef.current) return;
    
    const gameArea = gameAreaRef.current.getBoundingClientRect();
    const padding = 100; // Keep devices away from edges
    
    const positionedDevices = deviceData.map(device => ({
      ...device,
      x: padding + Math.random() * (gameArea.width - padding * 2),
      y: padding + Math.random() * (gameArea.height - padding * 2)
    }));
    
    setDevices(positionedDevices);
  };
  
  // Start the matching phase
  const startMatchingPhase = () => {
    setGamePhase("matching");
    setMessage("Match renewable energy sources to their uses!");
    
    // Shuffle the energy sources and uses
    setEnergySources([...sourceData].sort(() => Math.random() - 0.5));
    setEnergyUses([...useData].sort(() => Math.random() - 0.5));
  };
  
  // Handle clicking on an electronic device
  const handleDeviceClick = (deviceId: string) => {
    setDevices(prevDevices => {
      return prevDevices.map(device => {
        if (device.id === deviceId && device.isOn) {
          // Turn off the device
          const pointsEarned = 50;
          
          // Update score
          setScore(prevScore => {
            const newScore = prevScore + pointsEarned;
            onScoreChange(newScore);
            return newScore;
          });
          
          // Update devices found counter
          setDevicesFound(prev => prev + 1);
          
          // Show message
          setMessage(`+${pointsEarned} points! Energy saved by turning off ${device.name}!`);
          setTimeout(() => setMessage(null), 1500);
          
          // Play sound
          playSuccess();
          
          // Check if all devices are turned off
          const updatedDevicesFound = devicesFound + 1;
          if (updatedDevicesFound >= deviceData.length - 1) {
            // Almost all devices found, prepare to move to next phase
            setTimeout(() => {
              // Move to matching phase
              setGamePhase("matching");
              // Stop current timer
              if (timerRef.current) clearInterval(timerRef.current);
              // Display message about match phase
              setMessage("Match renewable energy sources to their uses!");
              // Reset timer for matching phase
              setTimeLeft(60);
              // Shuffle the energy sources and uses
              setEnergySources([...sourceData].sort(() => Math.random() - 0.5));
              setEnergyUses([...useData].sort(() => Math.random() - 0.5));
              // Start new timer for matching phase
              timerRef.current = setInterval(() => {
                setTimeLeft(prev => {
                  if (prev <= 1) {
                    clearInterval(timerRef.current!);
                    onComplete(score);
                    return 0;
                  }
                  return prev - 1;
                });
              }, 1000);
            }, 2000);
          }
          
          return { ...device, isOn: false };
        }
        return device;
      });
    });
  };
  
  // Handle selecting an energy source in matching phase
  const handleSourceClick = (sourceId: string) => {
    if (matchedPairs.includes(sourceId)) return;
    
    setSelectedSource(sourceId);
  };
  
  // Handle selecting an energy use in matching phase
  const handleUseClick = (useId: string, useType: string) => {
    if (!selectedSource || matchedPairs.includes(useId)) return;
    
    // Find the selected source
    const source = energySources.find(s => s.id === selectedSource);
    
    if (source && source.type === useType) {
      // Correct match
      const pointsEarned = 100;
      
      // Update score
      setScore(prevScore => {
        const newScore = prevScore + pointsEarned;
        onScoreChange(newScore);
        return newScore;
      });
      
      // Add to matched pairs
      setMatchedPairs(prev => [...prev, selectedSource, useId]);
      
      // Show message
      setMessage(`+${pointsEarned} points! Correct match!`);
      setTimeout(() => setMessage(null), 1500);
      
      // Play sound
      playSuccess();
      
      // Check if all pairs are matched
      if (matchedPairs.length + 2 >= sourceData.length * 2) {
        // All pairs matched, end game
        setTimeout(() => {
          onComplete(score);
          if (timerRef.current) clearInterval(timerRef.current);
        }, 1500);
      }
    } else {
      // Incorrect match
      playHit();
      
      // Show message
      setMessage("Try again! That's not the right match.");
      setTimeout(() => setMessage(null), 1500);
    }
    
    // Reset selected source
    setSelectedSource(null);
  };
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  return (
    <div className="h-full w-full relative overflow-hidden">
      {/* Game background */}
      <div className="absolute inset-0 bg-gradient-to-b from-yellow-100 to-blue-100"></div>
      
      {!gameStarted ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl p-6 shadow-lg max-w-md text-center"
          >
            <h2 className="text-2xl font-bold text-yellow-600 mb-3">Energy Explorer</h2>
            <p className="text-gray-700 mb-4">
              Find and switch off unused electronics, then match renewable energy sources to their uses!
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-yellow-500 text-white font-bold py-3 px-8 rounded-full"
              onClick={handleStart}
            >
              Start Exploring!
            </motion.button>
          </motion.div>
          
          <div className="absolute bottom-10 left-10">
            <CharacterGuide text="Let's save energy and learn about renewable power sources!" />
          </div>
        </div>
      ) : (
        <div className="h-full w-full relative" ref={gameAreaRef}>
          {/* Game UI */}
          <div className="absolute top-4 left-4 bg-white/80 backdrop-blur-sm rounded-lg p-3 shadow flex space-x-4">
            <div>
              <div className="text-xs text-gray-500">Score</div>
              <div className="text-2xl font-bold text-yellow-600">{score}</div>
            </div>
            <div>
              <div className="text-xs text-gray-500">Time</div>
              <div className={`text-2xl font-bold ${timeLeft <= 10 ? 'text-red-500' : 'text-blue-600'}`}>
                {timeLeft}s
              </div>
            </div>
            <div>
              <div className="text-xs text-gray-500">Phase</div>
              <div className="text-2xl font-bold text-emerald-600">
                {gamePhase === "exploration" ? `${devicesFound}/${deviceData.length}` : `${matchedPairs.length/2}/${sourceData.length}`}
              </div>
            </div>
          </div>
          
          {/* Message */}
          {message && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="absolute top-16 left-1/2 transform -translate-x-1/2 py-2 px-4 rounded-lg bg-yellow-100 text-yellow-800"
            >
              {message}
            </motion.div>
          )}
          
          {/* Game content based on phase */}
          {gamePhase === "exploration" && (
            <div className="h-full w-full">
              {/* House background elements */}
              <div className="absolute inset-0 pointer-events-none">
                {/* Walls */}
                <div className="absolute inset-0 border-8 border-gray-300"></div>
                
                {/* Windows */}
                <div className="absolute top-20 left-20 w-32 h-24 border-4 border-blue-300 bg-blue-100 rounded"></div>
                <div className="absolute top-20 right-20 w-32 h-24 border-4 border-blue-300 bg-blue-100 rounded"></div>
                
                {/* Door */}
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-24 h-40 bg-amber-700 rounded-t"></div>
                
                {/* Roof */}
                <div className="absolute top-0 left-0 right-0 h-20 bg-amber-900"></div>
              </div>
              
              {/* Electronic devices */}
              {devices.map(device => (
                <motion.div
                  key={device.id}
                  className={`absolute cursor-pointer ${device.isOn ? 'opacity-100' : 'opacity-40'}`}
                  style={{ 
                    left: device.x, 
                    top: device.y,
                    pointerEvents: device.isOn ? 'auto' : 'none'
                  }}
                  whileHover={device.isOn ? { scale: 1.1 } : {}}
                  whileTap={device.isOn ? { scale: 0.9 } : {}}
                  onClick={() => handleDeviceClick(device.id)}
                >
                  <div className="flex flex-col items-center">
                    <div className="text-4xl mb-1">{device.image}</div>
                    <div className="bg-white/80 backdrop-blur px-2 py-1 rounded text-xs font-semibold">
                      {device.name}
                    </div>
                    {device.isOn && (
                      <div className="mt-1 w-3 h-3 rounded-full bg-red-500 animate-pulse" />
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
          
          {gamePhase === "matching" && (
            <div className="h-full w-full p-10 flex flex-col justify-between">
              {/* Energy sources */}
              <div className="bg-white/80 backdrop-blur rounded-lg p-4 shadow">
                <h3 className="text-lg font-bold text-yellow-700 mb-3">Renewable Energy Sources</h3>
                <div className="flex flex-wrap gap-4 justify-center">
                  {energySources.map(source => (
                    <motion.div
                      key={source.id}
                      className={`w-32 h-32 bg-white rounded-lg shadow-md flex flex-col items-center justify-center p-2 cursor-pointer ${
                        selectedSource === source.id ? 'ring-4 ring-yellow-500' : ''
                      } ${matchedPairs.includes(source.id) ? 'bg-green-100' : ''}`}
                      whileHover={!matchedPairs.includes(source.id) ? { scale: 1.05 } : {}}
                      whileTap={!matchedPairs.includes(source.id) ? { scale: 0.95 } : {}}
                      onClick={() => handleSourceClick(source.id)}
                      animate={matchedPairs.includes(source.id) ? { 
                        backgroundColor: ['#d1fae5', '#ffffff', '#d1fae5'],
                        transition: { repeat: 2, duration: 1 }
                      } : {}}
                    >
                      <div className="text-4xl mb-2">{source.image}</div>
                      <div className="text-center text-sm font-medium">{source.name}</div>
                    </motion.div>
                  ))}
                </div>
              </div>
              
              {/* Energy uses */}
              <div className="bg-white/80 backdrop-blur rounded-lg p-4 shadow">
                <h3 className="text-lg font-bold text-blue-700 mb-3">Energy Uses</h3>
                <div className="flex flex-wrap gap-4 justify-center">
                  {energyUses.map(use => (
                    <motion.div
                      key={use.id}
                      className={`w-32 h-32 bg-white rounded-lg shadow-md flex flex-col items-center justify-center p-2 cursor-pointer ${
                        matchedPairs.includes(use.id) ? 'bg-green-100' : ''
                      }`}
                      whileHover={!matchedPairs.includes(use.id) ? { scale: 1.05 } : {}}
                      whileTap={!matchedPairs.includes(use.id) ? { scale: 0.95 } : {}}
                      onClick={() => handleUseClick(use.id, use.type)}
                      animate={matchedPairs.includes(use.id) ? { 
                        backgroundColor: ['#d1fae5', '#ffffff', '#d1fae5'],
                        transition: { repeat: 2, duration: 1 }
                      } : {}}
                    >
                      <div className="text-4xl mb-2">{use.image}</div>
                      <div className="text-center text-sm font-medium">{use.name}</div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          {/* Terra character with tips */}
          <div className="absolute top-16 right-4">
            <CharacterGuide 
              text={
                gamePhase === "exploration" 
                  ? "Find and click on all the electronic devices that are turned on!" 
                  : "Match each renewable energy source with its use. Think about how each type of energy is used!"
              }
              position="right"
              size="small"
              autoHide={true}
              hideDelay={8000}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default EnergyExplorer;
