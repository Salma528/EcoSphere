import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useAudio } from "../lib/stores/useAudio";
import CharacterGuide from "../components/CharacterGuide";

interface Trash {
  id: string;
  type: "plastic" | "fishing" | "oil" | "chemical";
  name: string;
  emoji: string;
  position: {
    x: number;
    y: number;
  };
  collected: boolean;
  speed: number;
}

interface MarineAnimal {
  id: string;
  name: string;
  emoji: string;
  position: {
    x: number;
    y: number;
  };
  saved: boolean;
  endangered: boolean;
  fact: string;
}

interface OceanObserverProps {
  onComplete: (score: number) => void;
  onScoreChange: (score: number) => void;
}

const OceanObserver: React.FC<OceanObserverProps> = ({ onComplete, onScoreChange }) => {
  const [score, setScore] = useState(0);
  const [gameStarted, setGameStarted] = useState(false);
  const [trash, setTrash] = useState<Trash[]>([]);
  const [animals, setAnimals] = useState<MarineAnimal[]>([]);
  const [timeLeft, setTimeLeft] = useState(60);
  const [message, setMessage] = useState<string | null>(null);
  const [showFact, setShowFact] = useState<string | null>(null);
  const [playerPosition, setPlayerPosition] = useState({ x: 0, y: 0 });
  const [trashCollected, setTrashCollected] = useState(0);
  const [animalsSaved, setAnimalsSaved] = useState(0);
  
  const gameAreaRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const trashIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  
  const { playHit, playSuccess } = useAudio();
  
  // Trash data
  const trashData: Omit<Trash, "position" | "collected" | "speed">[] = [
    {
      id: "trash-1",
      type: "plastic",
      name: "Plastic Bottle",
      emoji: "🍶"
    },
    {
      id: "trash-2",
      type: "plastic",
      name: "Plastic Bag",
      emoji: "🛍️"
    },
    {
      id: "trash-3",
      type: "fishing",
      name: "Fishing Net",
      emoji: "🥅"
    },
    {
      id: "trash-4",
      type: "oil",
      name: "Oil Spill",
      emoji: "🛢️"
    },
    {
      id: "trash-5",
      type: "chemical",
      name: "Chemical Waste",
      emoji: "☣️"
    }
  ];
  
  // Marine animal data
  const animalData: Omit<MarineAnimal, "position" | "saved">[] = [
    {
      id: "animal-1",
      name: "Dolphin",
      emoji: "🐬",
      endangered: false,
      fact: "Dolphins are highly intelligent marine mammals that use echolocation to find food and navigate."
    },
    {
      id: "animal-2",
      name: "Sea Turtle",
      emoji: "🐢",
      endangered: true,
      fact: "Sea turtles can hold their breath for up to 7 hours underwater!"
    },
    {
      id: "animal-3",
      name: "Whale",
      emoji: "🐋",
      endangered: true,
      fact: "The blue whale is the largest animal ever known to have lived on Earth."
    },
    {
      id: "animal-4",
      name: "Octopus",
      emoji: "🐙",
      endangered: false,
      fact: "Octopuses have three hearts, nine brains, and blue blood!"
    },
    {
      id: "animal-5",
      name: "Fish",
      emoji: "🐟",
      endangered: false,
      fact: "There are over 34,000 different species of fish in the world."
    }
  ];
  
  // Start the game
  const handleStart = () => {
    setGameStarted(true);
    
    // Initialize player position in the middle
    if (gameAreaRef.current) {
      const rect = gameAreaRef.current.getBoundingClientRect();
      setPlayerPosition({
        x: rect.width / 2,
        y: rect.height / 2
      });
    }
    
    // Spawn initial trash
    spawnTrash(5);
    
    // Spawn marine animals
    spawnAnimals();
    
    // Start spawning trash periodically
    trashIntervalRef.current = setInterval(() => {
      spawnTrash(1);
    }, 3000);
    
    // Start timer
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          // End game
          endGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    // Start game loop
    startGameLoop();
  };
  
  // Spawn trash in the ocean
  const spawnTrash = (count: number) => {
    if (!gameAreaRef.current) return;
    
    const gameArea = gameAreaRef.current.getBoundingClientRect();
    const padding = 50; // Stay away from edges
    
    const newTrash: Trash[] = [];
    
    for (let i = 0; i < count; i++) {
      // Select random trash type
      const randomTrash = trashData[Math.floor(Math.random() * trashData.length)];
      
      // Random position
      const x = padding + Math.random() * (gameArea.width - padding * 2);
      const y = padding + Math.random() * (gameArea.height - padding * 2);
      
      newTrash.push({
        ...randomTrash,
        id: `trash-${Date.now()}-${i}`,
        position: { x, y },
        collected: false,
        speed: 0.5 + Math.random() * 1
      });
    }
    
    setTrash(prev => [...prev, ...newTrash]);
  };
  
  // Spawn marine animals
  const spawnAnimals = () => {
    if (!gameAreaRef.current) return;
    
    const gameArea = gameAreaRef.current.getBoundingClientRect();
    const padding = 60; // Stay away from edges
    
    const newAnimals = animalData.map(animal => {
      // Random position
      const x = padding + Math.random() * (gameArea.width - padding * 2);
      const y = padding + Math.random() * (gameArea.height - padding * 2);
      
      return {
        ...animal,
        position: { x, y },
        saved: false
      };
    });
    
    setAnimals(newAnimals);
  };
  
  // Game loop
  const startGameLoop = () => {
    const updateGame = () => {
      // Move trash with gentle floating motion
      setTrash(prev => {
        return prev.map(item => {
          if (item.collected) return item;
          
          // Simple floating motion
          const newX = item.position.x + Math.sin(Date.now() * 0.001) * item.speed;
          const newY = item.position.y + Math.cos(Date.now() * 0.001) * item.speed;
          
          return {
            ...item,
            position: { x: newX, y: newY }
          };
        });
      });
      
      // Check for collisions with player
      checkCollisions();
      
      animationFrameRef.current = requestAnimationFrame(updateGame);
    };
    
    animationFrameRef.current = requestAnimationFrame(updateGame);
  };
  
  // Check collisions between player and objects
  const checkCollisions = () => {
    const playerRadius = 30; // Player collision radius
    
    // Check trash collisions
    setTrash(prev => {
      let collectedAny = false;
      
      const updatedTrash = prev.map(item => {
        if (item.collected) return item;
        
        // Calculate distance to player
        const distance = Math.sqrt(
          Math.pow(item.position.x - playerPosition.x, 2) + 
          Math.pow(item.position.y - playerPosition.y, 2)
        );
        
        if (distance < playerRadius + 20) {
          // Collision detected
          collectedAny = true;
          
          // Award points
          const pointsEarned = 10;
          setScore(prevScore => {
            const newScore = prevScore + pointsEarned;
            onScoreChange(newScore);
            return newScore;
          });
          
          setTrashCollected(prev => prev + 1);
          
          return { ...item, collected: true };
        }
        
        return item;
      });
      
      if (collectedAny) {
        playSuccess();
        setMessage("Trash collected! +10 points");
        setTimeout(() => setMessage(null), 1500);
      }
      
      return updatedTrash;
    });
    
    // Check animal rescues
    setAnimals(prev => {
      let savedAny = false;
      
      // Count trash around each animal
      const updatedAnimals = prev.map(animal => {
        if (animal.saved) return animal;
        
        // Check if area around animal is clean (no trash within radius)
        const animalRadius = 50;
        const trashNearby = trash.filter(t => {
          if (t.collected) return false;
          
          const distance = Math.sqrt(
            Math.pow(t.position.x - animal.position.x, 2) + 
            Math.pow(t.position.y - animal.position.y, 2)
          );
          
          return distance < animalRadius;
        });
        
        // If no trash nearby and player is close, animal is saved
        const distanceToPlayer = Math.sqrt(
          Math.pow(animal.position.x - playerPosition.x, 2) + 
          Math.pow(animal.position.y - playerPosition.y, 2)
        );
        
        if (trashNearby.length === 0 && distanceToPlayer < playerRadius + animalRadius) {
          savedAny = true;
          
          // Award points (bonus for endangered species)
          const pointsEarned = animal.endangered ? 50 : 30;
          setScore(prevScore => {
            const newScore = prevScore + pointsEarned;
            onScoreChange(newScore);
            return newScore;
          });
          
          setAnimalsSaved(prev => prev + 1);
          
          return { ...animal, saved: true };
        }
        
        return animal;
      });
      
      if (savedAny) {
        playSuccess();
        setMessage("Animal saved! Clean water helps marine life!");
        setTimeout(() => {
          setMessage(null);
          // Show fact about the animal
          const savedAnimal = updatedAnimals.find(a => a.saved && !prev.find(p => p.id === a.id)?.saved);
          if (savedAnimal) {
            setShowFact(savedAnimal.id);
          }
        }, 1500);
      }
      
      return updatedAnimals;
    });
  };
  
  // End the game
  const endGame = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (trashIntervalRef.current) clearInterval(trashIntervalRef.current);
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    
    // Add time bonus if all animals are saved
    const allAnimalsSaved = animals.every(a => a.saved);
    let timeBonus = 0;
    
    if (allAnimalsSaved) {
      timeBonus = timeLeft * 5;
      setScore(prevScore => {
        const newScore = prevScore + timeBonus;
        onScoreChange(newScore);
        return newScore;
      });
      
      setMessage(`All animals saved! Time bonus: +${timeBonus} points!`);
    } else {
      setMessage("Game Over!");
    }
    
    setTimeout(() => {
      onComplete(score + (allAnimalsSaved ? timeBonus : 0));
    }, 2000);
  };
  
  // Handle player movement with mouse
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!gameAreaRef.current) return;
    
    const rect = gameAreaRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    setPlayerPosition({ x, y });
  };
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (trashIntervalRef.current) clearInterval(trashIntervalRef.current);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, []);

  return (
    <div className="h-full w-full relative overflow-hidden">
      {/* Ocean background */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-300 to-blue-700"></div>
      
      {!gameStarted ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl p-6 shadow-lg max-w-md text-center"
          >
            <h2 className="text-2xl font-bold text-blue-700 mb-3">Ocean Observer</h2>
            <p className="text-gray-700 mb-4">
              Clean up ocean pollution to save marine animals! Move your cursor to control the submarine.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-blue-500 text-white font-bold py-3 px-8 rounded-full"
              onClick={handleStart}
            >
              Start Cleaning!
            </motion.button>
          </motion.div>
          
          <div className="absolute bottom-10 left-10">
            <CharacterGuide text="Our oceans are full of amazing creatures, but pollution threatens their homes. Let's help clean up!" />
          </div>
        </div>
      ) : (
        <div 
          className="h-full w-full relative cursor-none" 
          ref={gameAreaRef}
          onMouseMove={handleMouseMove}
        >
          {/* Underwater decorations */}
          <div className="absolute inset-0 pointer-events-none">
            {/* Bubbles */}
            {[...Array(20)].map((_, i) => (
              <motion.div
                key={`bubble-${i}`}
                className="absolute w-4 h-4 rounded-full bg-white/30"
                style={{
                  left: `${Math.random() * 100}%`,
                  bottom: `-20px`,
                }}
                animate={{
                  y: [0, -500 - Math.random() * 500],
                  x: [0, (Math.random() - 0.5) * 100],
                }}
                transition={{
                  duration: 10 + Math.random() * 20,
                  repeat: Infinity,
                  repeatType: "loop",
                  ease: "linear",
                  delay: Math.random() * 10,
                }}
              />
            ))}
            
            {/* Seaweed */}
            <div className="absolute bottom-0 left-10 w-10 h-40 flex justify-center">
              <motion.div
                className="w-6 h-full bg-green-800 rounded-t-full origin-bottom"
                animate={{ skewX: [5, -5, 5] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              />
            </div>
            <div className="absolute bottom-0 left-40 w-10 h-32 flex justify-center">
              <motion.div
                className="w-6 h-full bg-green-700 rounded-t-full origin-bottom"
                animate={{ skewX: [-5, 5, -5] }}
                transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut" }}
              />
            </div>
            <div className="absolute bottom-0 right-20 w-10 h-36 flex justify-center">
              <motion.div
                className="w-6 h-full bg-green-700 rounded-t-full origin-bottom"
                animate={{ skewX: [5, -5, 5] }}
                transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut" }}
              />
            </div>
          </div>
          
          {/* Game UI */}
          <div className="absolute top-4 left-4 bg-white/70 backdrop-blur-sm rounded-lg p-3 shadow flex space-x-4">
            <div>
              <div className="text-xs text-gray-500">Score</div>
              <div className="text-2xl font-bold text-blue-700">{score}</div>
            </div>
            <div>
              <div className="text-xs text-gray-500">Time</div>
              <div className={`text-2xl font-bold ${timeLeft <= 10 ? 'text-red-500' : 'text-blue-600'}`}>
                {timeLeft}s
              </div>
            </div>
            <div>
              <div className="text-xs text-gray-500">Collected</div>
              <div className="text-2xl font-bold text-green-600">{trashCollected}</div>
            </div>
            <div>
              <div className="text-xs text-gray-500">Saved</div>
              <div className="text-2xl font-bold text-amber-600">{animalsSaved}/{animals.length}</div>
            </div>
          </div>
          
          {/* Message */}
          {message && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="absolute top-16 left-1/2 transform -translate-x-1/2 py-2 px-4 rounded-lg bg-blue-100 text-blue-800"
            >
              {message}
            </motion.div>
          )}
          
          {/* Marine animals */}
          {animals.map(animal => (
            <motion.div
              key={animal.id}
              className="absolute cursor-pointer"
              style={{ 
                left: animal.position.x - 30, 
                top: animal.position.y - 30 
              }}
              animate={animal.saved ? {
                y: [0, -10, 0],
                rotate: [0, 5, 0, -5, 0],
              } : {}}
              transition={animal.saved ? {
                repeat: Infinity,
                duration: 3,
                ease: "easeInOut",
              } : {}}
            >
              <div className="relative flex flex-col items-center">
                <div className="text-5xl">{animal.emoji}</div>
                
                {/* Danger indicator if trash is nearby */}
                {!animal.saved && trash.some(t => {
                  if (t.collected) return false;
                  const distance = Math.sqrt(
                    Math.pow(t.position.x - animal.position.x, 2) + 
                    Math.pow(t.position.y - animal.position.y, 2)
                  );
                  return distance < 50;
                }) && (
                  <motion.div
                    className="absolute -top-4 -right-4 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white font-bold"
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ repeat: Infinity, duration: 1 }}
                  >
                    !
                  </motion.div>
                )}
                
                {/* Saved indicator */}
                {animal.saved && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="absolute -top-4 -right-4 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white"
                  >
                    ✓
                  </motion.div>
                )}
              </div>
            </motion.div>
          ))}
          
          {/* Trash */}
          {trash.map(item => (
            !item.collected && (
              <motion.div
                key={item.id}
                className="absolute"
                style={{ 
                  left: item.position.x - 15, 
                  top: item.position.y - 15 
                }}
                animate={{
                  rotate: [0, 10, -10, 0],
                }}
                transition={{
                  repeat: Infinity,
                  duration: 3 + Math.random() * 2,
                  ease: "easeInOut",
                }}
              >
                <div className="text-3xl">{item.emoji}</div>
              </motion.div>
            )
          ))}
          
          {/* Player submarine */}
          <motion.div
            className="absolute pointer-events-none w-60 h-40"
            style={{ 
              left: playerPosition.x - 30, 
              top: playerPosition.y - 20 
            }}
            animate={{
              rotate: [0, 2, 0, -2, 0],
            }}
            transition={{
              repeat: Infinity,
              duration: 3,
              ease: "easeInOut",
            }}
          >
            <svg viewBox="0 0 100 50" width="100%" height="100%">
              <path 
                d="M30,25 C30,10 70,10 70,25 C70,40 30,40 30,25 Z" 
                fill="#FFD700" 
                stroke="#000" 
                strokeWidth="2"
              />
              <circle cx="40" cy="25" r="5" fill="#87CEEB" stroke="#000" strokeWidth="1" />
              <circle cx="55" cy="25" r="5" fill="#87CEEB" stroke="#000" strokeWidth="1" />
              <circle cx="70" cy="25" r="5" fill="#87CEEB" stroke="#000" strokeWidth="1" />
            </svg>
          </motion.div>
          
          {/* Animal fact popup */}
          {showFact && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-xl p-4 shadow-xl max-w-sm"
            >
              {(() => {
                const animal = animals.find(a => a.id === showFact);
                if (!animal) return null;
                return (
                  <>
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-xl font-bold text-blue-700">{animal.name}</h3>
                      <button 
                        className="text-gray-500 hover:text-gray-700"
                        onClick={() => setShowFact(null)}
                      >
                        ✕
                      </button>
                    </div>
                    
                    <div className="flex items-center justify-center my-3">
                      <span className="text-6xl">{animal.emoji}</span>
                    </div>
                    
                    <div className="mb-3">
                      <p className="text-gray-700">{animal.fact}</p>
                    </div>
                    
                    {animal.endangered && (
                      <div className="mb-3 p-2 bg-red-100 text-red-800 rounded">
                        <p className="text-sm">This species is endangered and needs protection.</p>
                      </div>
                    )}
                    
                    <div className="flex justify-end">
                      <button 
                        className="bg-blue-100 text-blue-800 px-3 py-1 rounded-lg text-sm font-medium"
                        onClick={() => setShowFact(null)}
                      >
                        Continue Cleaning
                      </button>
                    </div>
                  </>
                );
              })()}
            </motion.div>
          )}
          
          {/* Terra character with tips */}
          <div className="absolute top-16 right-4">
            <CharacterGuide 
              text="Move your cursor to collect trash! Clear trash around marine animals to save them."
              position="right"
              size="small"
              autoHide={true}
              hideDelay={8000}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default OceanObserver;
