import { useState, useEffect, useRef } from "react";
import { motion, useAnimation } from "framer-motion";
import { useAudio } from "../lib/stores/useAudio";
import CharacterGuide from "../components/CharacterGuide";

interface WaterDrop {
  id: string;
  x: number;
  y: number;
  size: number;
  speed: number;
  collected: boolean;
}

interface LeakingTap {
  id: string;
  x: number;
  y: number;
  isLeaking: boolean;
  fixTime: number; // How long it takes to fix
  fixProgress: number; // Current fix progress
}

interface CloudData {
  id: string;
  x: number;
  y: number;
  width: number;
  speed: number;
  hasRainwater: boolean;
  collected: boolean;
}

interface WaterWarriorProps {
  onComplete: (score: number) => void;
  onScoreChange: (score: number) => void;
}

const WaterWarrior: React.FC<WaterWarriorProps> = ({ onComplete, onScoreChange }) => {
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60); // 60 seconds game
  const [waterDrops, setWaterDrops] = useState<WaterDrop[]>([]);
  const [leakingTaps, setLeakingTaps] = useState<LeakingTap[]>([]);
  const [clouds, setClouds] = useState<CloudData[]>([]);
  const [gameStarted, setGameStarted] = useState(false);
  const [waterSaved, setWaterSaved] = useState(0);
  const [message, setMessage] = useState<string | null>(null);
  
  const gameAreaRef = useRef<HTMLDivElement>(null);
  const dropsIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const tapsIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const cloudsIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const gameLoopRef = useRef<number | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  const { playHit, playSuccess } = useAudio();
  
  // Start the game
  const handleStart = () => {
    setGameStarted(true);
    
    // Initialize game elements
    createInitialTaps();
    createInitialClouds();
    
    // Start spawning water drops
    dropsIntervalRef.current = setInterval(createWaterDrop, 1500);
    
    // Start game loop
    startGameLoop();
    
    // Start the timer
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          // End game when timer hits 0
          clearInterval(timerRef.current!);
          endGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };
  
  // End the game
  const endGame = () => {
    // Clear all intervals
    if (dropsIntervalRef.current) clearInterval(dropsIntervalRef.current);
    if (tapsIntervalRef.current) clearInterval(tapsIntervalRef.current);
    if (cloudsIntervalRef.current) clearInterval(cloudsIntervalRef.current);
    if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
    
    // Call the complete callback
    onComplete(score);
  };
  
  // Create initial leaking taps
  const createInitialTaps = () => {
    const taps: LeakingTap[] = [
      { id: "tap-1", x: 150, y: 150, isLeaking: true, fixTime: 3000, fixProgress: 0 },
      { id: "tap-2", x: 350, y: 200, isLeaking: true, fixTime: 3000, fixProgress: 0 },
      { id: "tap-3", x: 550, y: 250, isLeaking: true, fixTime: 3000, fixProgress: 0 }
    ];
    setLeakingTaps(taps);
  };
  
  // Create initial clouds
  const createInitialClouds = () => {
    const newClouds: CloudData[] = [
      { id: "cloud-1", x: -100, y: 80, width: 120, speed: 1, hasRainwater: true, collected: false },
      { id: "cloud-2", x: -300, y: 40, width: 150, speed: 0.7, hasRainwater: true, collected: false },
      { id: "cloud-3", x: -500, y: 120, width: 100, speed: 1.2, hasRainwater: true, collected: false }
    ];
    setClouds(newClouds);
    
    // Periodically refresh clouds
    cloudsIntervalRef.current = setInterval(() => {
      setClouds(prev => {
        // Remove clouds that have moved off screen
        const filtered = prev.filter(cloud => cloud.x < window.innerWidth);
        
        // Add new clouds if needed
        if (filtered.length < 3) {
          const newCloud = {
            id: `cloud-${Date.now()}`,
            x: -150,
            y: Math.random() * 150, // Random height
            width: 100 + Math.random() * 50, // Random width
            speed: 0.5 + Math.random(), // Random speed
            hasRainwater: Math.random() > 0.3, // 70% chance to have rainwater
            collected: false
          };
          return [...filtered, newCloud];
        }
        
        return filtered;
      });
    }, 5000);
  };
  
  // Create a new water drop
  const createWaterDrop = () => {
    // Only create drops from leaking taps
    const leakingTapsArr = leakingTaps.filter(tap => tap.isLeaking);
    if (leakingTapsArr.length === 0) return;
    
    // Randomly select a leaking tap
    const randomTap = leakingTapsArr[Math.floor(Math.random() * leakingTapsArr.length)];
    
    const newDrop: WaterDrop = {
      id: `drop-${Date.now()}`,
      x: randomTap.x,
      y: randomTap.y + 30, // Position below the tap
      size: 20 + Math.random() * 10, // Random size
      speed: 2 + Math.random() * 2, // Random speed
      collected: false
    };
    
    setWaterDrops(prev => [...prev, newDrop]);
  };
  
  // Game loop for updating positions
  const startGameLoop = () => {
    const updateGame = () => {
      // Update water drops
      setWaterDrops(prev => {
        return prev.map(drop => {
          if (drop.collected) return drop;
          
          // Move drop down
          const newY = drop.y + drop.speed;
          
          // Check if drop has reached bottom
          if (newY > (gameAreaRef.current?.clientHeight || 600) - 50) {
            // Water wasted
            return { ...drop, y: newY, collected: true };
          }
          
          return { ...drop, y: newY };
        }).filter(drop => drop.y < (gameAreaRef.current?.clientHeight || 600) + 50); // Remove drops that fall off screen
      });
      
      // Update clouds
      setClouds(prev => {
        return prev.map(cloud => {
          // Move cloud horizontally
          return { ...cloud, x: cloud.x + cloud.speed };
        });
      });
      
      gameLoopRef.current = requestAnimationFrame(updateGame);
    };
    
    gameLoopRef.current = requestAnimationFrame(updateGame);
  };
  
  // Handle collecting a water drop
  const collectWaterDrop = (dropId: string) => {
    setWaterDrops(prev => {
      return prev.map(drop => {
        if (drop.id === dropId && !drop.collected) {
          // Collect the drop
          const pointsEarned = Math.ceil(drop.size); // Points based on drop size
          
          // Update score
          setScore(prevScore => {
            const newScore = prevScore + pointsEarned;
            onScoreChange(newScore);
            return newScore;
          });
          
          // Update water saved counter
          setWaterSaved(prev => prev + 1);
          
          // Show message
          setMessage(`+${pointsEarned} points! Water saved!`);
          setTimeout(() => setMessage(null), 1500);
          
          // Play sound
          playSuccess();
          
          return { ...drop, collected: true };
        }
        return drop;
      });
    });
  };
  
  // Handle fixing a leaking tap
  const handleTapClick = (tapId: string) => {
    setLeakingTaps(prev => {
      return prev.map(tap => {
        if (tap.id === tapId && tap.isLeaking) {
          // Start or continue fixing the tap
          const newProgress = tap.fixProgress + 1000; // Increment fix progress
          
          if (newProgress >= tap.fixTime) {
            // Tap is fixed
            playSuccess();
            
            // Award points
            const pointsEarned = 50;
            setScore(prevScore => {
              const newScore = prevScore + pointsEarned;
              onScoreChange(newScore);
              return newScore;
            });
            
            // Show message
            setMessage(`+${pointsEarned} points! Tap fixed!`);
            setTimeout(() => setMessage(null), 1500);
            
            return { ...tap, isLeaking: false, fixProgress: tap.fixTime };
          }
          
          // Still fixing
          playHit();
          return { ...tap, fixProgress: newProgress };
        }
        return tap;
      });
    });
  };
  
  // Handle collecting rainwater from a cloud
  const collectRainwater = (cloudId: string) => {
    setClouds(prev => {
      return prev.map(cloud => {
        if (cloud.id === cloudId && cloud.hasRainwater && !cloud.collected) {
          // Collect rainwater
          const pointsEarned = 30;
          
          // Update score
          setScore(prevScore => {
            const newScore = prevScore + pointsEarned;
            onScoreChange(newScore);
            return newScore;
          });
          
          // Update water saved counter
          setWaterSaved(prev => prev + 3); // Rainwater counts as 3 drops
          
          // Show message
          setMessage(`+${pointsEarned} points! Rainwater collected!`);
          setTimeout(() => setMessage(null), 1500);
          
          // Play sound
          playSuccess();
          
          return { ...cloud, collected: true, hasRainwater: false };
        }
        return cloud;
      });
    });
  };
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (dropsIntervalRef.current) clearInterval(dropsIntervalRef.current);
      if (tapsIntervalRef.current) clearInterval(tapsIntervalRef.current);
      if (cloudsIntervalRef.current) clearInterval(cloudsIntervalRef.current);
      if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  return (
    <div className="h-full w-full relative overflow-hidden">
      {/* Game background */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-400 to-blue-100"></div>
      
      {!gameStarted ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl p-6 shadow-lg max-w-md text-center"
          >
            <h2 className="text-2xl font-bold text-blue-700 mb-3">Water Warrior</h2>
            <p className="text-gray-700 mb-4">
              Save precious water by catching falling drops, fixing leaking taps, and collecting rainwater!
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-blue-500 text-white font-bold py-3 px-8 rounded-full"
              onClick={handleStart}
            >
              Start Saving Water!
            </motion.button>
          </motion.div>
          
          <div className="absolute bottom-10 left-10">
            <CharacterGuide text="Every drop of water counts! Let's make sure none goes to waste." />
          </div>
        </div>
      ) : (
        <div className="h-full w-full relative" ref={gameAreaRef}>
          {/* Game UI */}
          <div className="absolute top-4 left-4 bg-white/80 backdrop-blur-sm rounded-lg p-3 shadow flex space-x-4">
            <div>
              <div className="text-xs text-gray-500">Score</div>
              <div className="text-2xl font-bold text-blue-700">{score}</div>
            </div>
            <div>
              <div className="text-xs text-gray-500">Time</div>
              <div className={`text-2xl font-bold ${timeLeft <= 10 ? 'text-red-500' : 'text-blue-600'}`}>
                {timeLeft}s
              </div>
            </div>
            <div>
              <div className="text-xs text-gray-500">Water Saved</div>
              <div className="text-2xl font-bold text-blue-500">{waterSaved} 💧</div>
            </div>
          </div>
          
          {/* Message */}
          {message && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="absolute top-16 left-1/2 transform -translate-x-1/2 py-2 px-4 rounded-lg bg-blue-100 text-blue-800"
            >
              {message}
            </motion.div>
          )}
          
          {/* Clouds */}
          {clouds.map(cloud => (
            <motion.div
              key={cloud.id}
              className="absolute"
              style={{ left: cloud.x, top: cloud.y, width: cloud.width }}
              animate={{ x: window.innerWidth + 200 }}
              transition={{ duration: 30 / cloud.speed, ease: "linear" }}
            >
              {/* Cloud shape */}
              <div className="relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <svg viewBox="0 0 100 60" width="100%" height="60">
                    <path 
                      d="M10,40 C10,30 20,20 30,20 C35,10 50,10 55,20 C70,15 80,25 80,35 C90,35 95,40 95,50 C95,55 90,60 80,60 L20,60 C10,60 5,50 10,40 Z" 
                      fill="white" 
                    />
                  </svg>
                </div>
                
                {/* Rainwater indicator */}
                {cloud.hasRainwater && !cloud.collected && (
                  <motion.button
                    className="absolute inset-0 flex items-center justify-center cursor-pointer"
                    onClick={() => collectRainwater(cloud.id)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <div className="bg-blue-500 text-white rounded-full px-2 py-1 text-xs shadow-md">
                      Collect 💧
                    </div>
                  </motion.button>
                )}
              </div>
            </motion.div>
          ))}
          
          {/* Leaking taps */}
          {leakingTaps.map(tap => (
            <div 
              key={tap.id}
              className="absolute"
              style={{ left: tap.x, top: tap.y }}
            >
              {/* Tap */}
              <div className="relative">
                <svg width="40" height="40" viewBox="0 0 40 40">
                  <rect x="10" y="0" width="20" height="10" fill="#888" />
                  <rect x="15" y="10" width="10" height="20" fill="#888" />
                  {tap.isLeaking && (
                    <circle cx="20" cy="35" r="3" fill="#3498db" opacity="0.7" />
                  )}
                </svg>
                
                {/* Tap interaction */}
                {tap.isLeaking && (
                  <motion.button
                    className="absolute inset-0 flex items-end justify-center cursor-pointer"
                    onClick={() => handleTapClick(tap.id)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <div className="bg-orange-500 text-white rounded-full px-2 py-1 text-xs shadow-md mb-8">
                      Fix Tap
                    </div>
                  </motion.button>
                )}
                
                {/* Progress bar for fixing */}
                {tap.isLeaking && tap.fixProgress > 0 && (
                  <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-6 w-20 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-green-500" 
                      style={{ width: `${(tap.fixProgress / tap.fixTime) * 100}%` }}
                    />
                  </div>
                )}
              </div>
            </div>
          ))}
          
          {/* Water drops */}
          {waterDrops.map(drop => (
            !drop.collected && (
              <motion.div
                key={drop.id}
                className="absolute rounded-full bg-blue-500 cursor-pointer"
                style={{ 
                  left: drop.x, 
                  top: drop.y, 
                  width: drop.size, 
                  height: drop.size * 1.2,
                  opacity: 0.8,
                  borderRadius: '50% 50% 50% 50% / 60% 60% 40% 40%'
                }}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => collectWaterDrop(drop.id)}
              />
            )
          ))}
          
          {/* Ocean at bottom */}
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-blue-500 opacity-70" />
          
          {/* Terra character with tips */}
          <div className="absolute top-16 right-4">
            <CharacterGuide 
              text="Tap the water drops to save them! Fix leaking taps and collect rainwater to earn more points."
              position="right"
              size="small"
              autoHide={true}
              hideDelay={8000}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default WaterWarrior;
