import { create } from "zustand";
import { getLocalStorage, setLocalStorage } from "../utils";

export interface GameProgress {
  completed: boolean;
  score: number;
  badges: string[];
  highScore: number;
  lastPlayed: string | null;
}

export interface GameData {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  badgeIcon: string;
}

interface ProgressState {
  games: Record<string, GameProgress>;
  totalBadges: number;
  totalScore: number;
  
  // Game data utility
  getGameData: (gameId: string) => GameData;
  
  // Initialize progress data
  initializeProgress: () => void;
  
  // Update game progress
  updateGameProgress: (gameId: string, updates: Partial<GameProgress>) => void;
  
  // Calculate overall stats
  calculateTotalScore: () => number;
  calculateTotalBadges: () => number;
  getCompletedGamesCount: () => number;
}

// Game data for all 10 games
const GAME_DATA: Record<string, GameData> = {
  "recycling-ranger": {
    id: "recycling-ranger",
    title: "Recycling Ranger",
    description: "Sort items into the correct recycling bins",
    thumbnail: "recycling-ranger",
    badgeIcon: "badge-recycling"
  },
  "water-warrior": {
    id: "water-warrior",
    title: "Water Warrior",
    description: "Save water drops from being wasted",
    thumbnail: "water-warrior",
    badgeIcon: "badge-water"
  },
  "energy-explorer": {
    id: "energy-explorer",
    title: "Energy Explorer",
    description: "Find and switch off unused electronics",
    thumbnail: "energy-explorer",
    badgeIcon: "badge-energy"
  },
  "garden-guardian": {
    id: "garden-guardian",
    title: "Garden Guardian",
    description: "Plant and grow virtual gardens",
    thumbnail: "garden-guardian",
    badgeIcon: "badge-garden"
  },
  "wildlife-protector": {
    id: "wildlife-protector",
    title: "Wildlife Protector",
    description: "Match animals to their habitats",
    thumbnail: "wildlife-protector",
    badgeIcon: "badge-wildlife"
  },
  "clean-air-champion": {
    id: "clean-air-champion",
    title: "Clean Air Champion",
    description: "Help reduce air pollution",
    thumbnail: "clean-air-champion",
    badgeIcon: "badge-air"
  },
  "ocean-observer": {
    id: "ocean-observer",
    title: "Ocean Observer",
    description: "Clean up ocean pollution",
    thumbnail: "ocean-observer",
    badgeIcon: "badge-ocean"
  },
  "eco-detective": {
    id: "eco-detective",
    title: "Eco Detective",
    description: "Solve environmental mysteries",
    thumbnail: "eco-detective",
    badgeIcon: "badge-detective"
  },
  "weather-watcher": {
    id: "weather-watcher",
    title: "Weather Watcher",
    description: "Learn about climate change",
    thumbnail: "weather-watcher",
    badgeIcon: "badge-weather"
  },
  "green-city-builder": {
    id: "green-city-builder",
    title: "Green City Builder",
    description: "Design an eco-friendly city",
    thumbnail: "green-city-builder",
    badgeIcon: "badge-city"
  }
};

// Default game progress structure
const DEFAULT_PROGRESS: GameProgress = {
  completed: false,
  score: 0,
  badges: [],
  highScore: 0,
  lastPlayed: null
};

// Create the store
export const useProgress = create<ProgressState>((set, get) => ({
  games: {},
  totalBadges: 0,
  totalScore: 0,
  
  getGameData: (gameId: string) => {
    return GAME_DATA[gameId];
  },
  
  initializeProgress: () => {
    // Try to load progress from localStorage
    const savedProgress = getLocalStorage("ecosphere-progress");
    
    if (savedProgress) {
      // If we have saved progress, use it
      set({ 
        games: savedProgress,
        totalBadges: Object.values(savedProgress).reduce((acc, game) => acc + game.badges.length, 0),
        totalScore: Object.values(savedProgress).reduce((acc, game) => acc + game.highScore, 0)
      });
    } else {
      // Otherwise initialize empty progress for all games
      const initialGames: Record<string, GameProgress> = {};
      
      // Create initial progress entry for each game
      Object.keys(GAME_DATA).forEach(gameId => {
        initialGames[gameId] = { ...DEFAULT_PROGRESS };
      });
      
      set({ games: initialGames, totalBadges: 0, totalScore: 0 });
      setLocalStorage("ecosphere-progress", initialGames);
    }
  },
  
  updateGameProgress: (gameId: string, updates: Partial<GameProgress>) => {
    set(state => {
      // Get current progress for the game
      const currentProgress = state.games[gameId] || { ...DEFAULT_PROGRESS };
      
      // Create updated progress
      const updatedProgress = {
        ...currentProgress,
        ...updates,
        // Update highScore if the new score is higher
        highScore: updates.score && updates.score > currentProgress.highScore 
          ? updates.score 
          : currentProgress.highScore,
        // Update lastPlayed to now
        lastPlayed: new Date().toISOString()
      };
      
      // Create updated games object
      const updatedGames = {
        ...state.games,
        [gameId]: updatedProgress
      };
      
      // Save to localStorage
      setLocalStorage("ecosphere-progress", updatedGames);
      
      // Update total badges and score
      return {
        games: updatedGames,
        totalBadges: get().calculateTotalBadges(),
        totalScore: get().calculateTotalScore()
      };
    });
  },
  
  calculateTotalScore: () => {
    const { games } = get();
    return Object.values(games).reduce((total, game) => total + game.highScore, 0);
  },
  
  calculateTotalBadges: () => {
    const { games } = get();
    return Object.values(games).reduce((total, game) => total + game.badges.length, 0);
  },
  
  getCompletedGamesCount: () => {
    const { games } = get();
    return Object.values(games).filter(game => game.completed).length;
  }
}));
