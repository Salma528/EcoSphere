import { create } from 'zustand';

export type Language = 'en' | 'ar';

interface LanguageState {
  language: Language;
  setLanguage: (language: Language) => void;
  translations: Record<string, Record<Language, string>>;
  t: (key: string) => string;
}

// Define translations
const translations: Record<string, Record<Language, string>> = {
  // App
  'app.title': {
    en: 'Ecosphere',
    ar: 'البيئة'
  },
  'app.start': {
    en: 'Start',
    ar: 'ابدأ'
  },
  'app.back': {
    en: 'Back',
    ar: 'عودة'
  },
  
  // Main Menu
  'menu.title': {
    en: 'Welcome to Ecosphere',
    ar: 'مرحبًا بك في البيئة'
  },
  'menu.subtitle': {
    en: 'Learn about the environment and sustainability!',
    ar: 'تعلم عن البيئة والاستدامة!'
  },
  'menu.play': {
    en: 'Play Now',
    ar: 'العب الآن'
  },
  
  // Game Selection
  'gameSelection.title': {
    en: 'Choose a Game',
    ar: 'اختر لعبة'
  },
  'gameSelection.subtitle': {
    en: 'Select an environmental challenge to play!',
    ar: 'اختر تحديًا بيئيًا للعب!'
  },
  
  // Games
  'games.recycling-ranger.title': {
    en: 'Recycling Ranger',
    ar: 'حارس إعادة التدوير'
  },
  'games.recycling-ranger.description': {
    en: 'Sort items into the correct recycling bins',
    ar: 'فرز العناصر في صناديق إعادة التدوير الصحيحة'
  },
  'games.recycling-ranger.instructions': {
    en: 'Drag and drop the items into the correct recycling bins. Be quick to earn more points!',
    ar: 'اسحب وأسقط العناصر في صناديق إعادة التدوير الصحيحة. كن سريعًا لكسب المزيد من النقاط!'
  },
  'games.water-warrior.title': {
    en: 'Water Warrior',
    ar: 'محارب المياه'
  },
  'games.water-warrior.description': {
    en: 'Save water by fixing leaks and collecting rainwater',
    ar: 'حافظ على المياه من خلال إصلاح التسربات وجمع مياه الأمطار'
  },
  'games.water-warrior.instructions': {
    en: 'Tap on the dripping water to save it. Fix leaking taps and collect rainwater.',
    ar: 'انقر على الماء المتساقط لحفظه. أصلح الصنابير المتسربة واجمع مياه الأمطار.'
  },
  'games.energy-explorer.title': {
    en: 'Energy Explorer',
    ar: 'مستكشف الطاقة'
  },
  'games.energy-explorer.description': {
    en: 'Learn about renewable energy sources',
    ar: 'تعلم عن مصادر الطاقة المتجددة'
  },
  'games.energy-explorer.instructions': {
    en: 'Find and switch off all unused electronics. Match renewable energy sources with their uses.',
    ar: 'ابحث عن الأجهزة الإلكترونية غير المستخدمة وأطفئها. طابق مصادر الطاقة المتجددة مع استخداماتها.'
  },
  'games.garden-guardian.title': {
    en: 'Garden Guardian',
    ar: 'حارس الحديقة'
  },
  'games.garden-guardian.description': {
    en: 'Grow plants and create a sustainable garden',
    ar: 'ازرع النباتات وأنشئ حديقة مستدامة'
  },
  'games.garden-guardian.instructions': {
    en: 'Plant seeds and care for your garden. Learn about different plants and their benefits.',
    ar: 'ازرع البذور واعتن بحديقتك. تعلم عن النباتات المختلفة وفوائدها.'
  },
  'games.wildlife-protector.title': {
    en: 'Wildlife Protector',
    ar: 'حامي الحياة البرية'
  },
  'games.wildlife-protector.description': {
    en: 'Help animals find their natural habitats',
    ar: 'ساعد الحيوانات في العثور على موائلها الطبيعية'
  },
  'games.wildlife-protector.instructions': {
    en: 'Match animals to their correct habitats. Learn about endangered species and how to protect them.',
    ar: 'طابق الحيوانات مع موائلها الصحيحة. تعلم عن الأنواع المهددة بالانقراض وكيفية حمايتها.'
  },
  'games.clean-air-champion.title': {
    en: 'Clean Air Champion',
    ar: 'بطل الهواء النظيف'
  },
  'games.clean-air-champion.description': {
    en: 'Reduce pollution and improve air quality',
    ar: 'قلل التلوث وحسن جودة الهواء'
  },
  'games.clean-air-champion.instructions': {
    en: 'Reduce air pollution by planting trees and choosing eco-friendly transportation options.',
    ar: 'قلل تلوث الهواء بزراعة الأشجار واختيار وسائل النقل الصديقة للبيئة.'
  },
  'games.ocean-observer.title': {
    en: 'Ocean Observer',
    ar: 'مراقب المحيط'
  },
  'games.ocean-observer.description': {
    en: 'Clean up the ocean and protect marine life',
    ar: 'نظف المحيط واحمِ الحياة البحرية'
  },
  'games.ocean-observer.instructions': {
    en: 'Clean up the ocean by collecting floating trash. Learn about marine life protection.',
    ar: 'نظف المحيط بجمع القمامة العائمة. تعلم عن حماية الحياة البحرية.'
  },
  'games.eco-detective.title': {
    en: 'Eco Detective',
    ar: 'محقق البيئة'
  },
  'games.eco-detective.description': {
    en: 'Solve environmental mysteries',
    ar: 'حل ألغاز بيئية'
  },
  'games.eco-detective.instructions': {
    en: 'Solve environmental mysteries by finding clues and fixing eco-problems.',
    ar: 'حل الألغاز البيئية من خلال العثور على الأدلة وإصلاح المشكلات البيئية.'
  },
  'games.weather-watcher.title': {
    en: 'Weather Watcher',
    ar: 'مراقب الطقس'
  },
  'games.weather-watcher.description': {
    en: 'Learn about weather patterns and climate change',
    ar: 'تعلم عن أنماط الطقس وتغير المناخ'
  },
  'games.weather-watcher.instructions': {
    en: 'Learn about climate change and help animals adapt to different weather conditions.',
    ar: 'تعلم عن تغير المناخ وساعد الحيوانات على التكيف مع ظروف الطقس المختلفة.'
  },
  'games.green-city-builder.title': {
    en: 'Green City Builder',
    ar: 'بناء المدينة الخضراء'
  },
  'games.green-city-builder.description': {
    en: 'Build a sustainable eco-friendly city',
    ar: 'ابنِ مدينة مستدامة صديقة للبيئة'
  },
  'games.green-city-builder.instructions': {
    en: 'Design an eco-friendly city by placing renewable energy sources and sustainable buildings.',
    ar: 'صمم مدينة صديقة للبيئة بوضع مصادر الطاقة المتجددة والمباني المستدامة.'
  },
  
  // Common Game UI
  'game.start': {
    en: 'Start Game',
    ar: 'ابدأ اللعبة'
  },
  'game.score': {
    en: 'Score',
    ar: 'النتيجة'
  },
  'game.time': {
    en: 'Time',
    ar: 'الوقت'
  },
  'game.complete': {
    en: 'Complete!',
    ar: 'مكتمل!'
  },
  'game.tryAgain': {
    en: 'Try Again',
    ar: 'حاول مرة أخرى'
  },
  'game.next': {
    en: 'Next',
    ar: 'التالي'
  },
  'game.instructions': {
    en: 'Instructions',
    ar: 'التعليمات'
  },
  'game.howToPlay': {
    en: 'How to Play',
    ar: 'كيفية اللعب'
  },
  'game.greatJob': {
    en: 'Great Job!',
    ar: 'عمل رائع!'
  },
  'game.completed': {
    en: "You've completed the game!",
    ar: 'لقد أكملت اللعبة!'
  },
  'game.finalScore': {
    en: 'Final Score',
    ar: 'النتيجة النهائية'
  },
  'game.playAgain': {
    en: 'Play Again',
    ar: 'العب مرة أخرى'
  },
  'game.backToMenu': {
    en: 'Back to Menu',
    ar: 'العودة إلى القائمة'
  },
  'game.newBadge': {
    en: 'New Badge Earned!',
    ar: 'حصلت على شارة جديدة!'
  },
  
  // Settings
  'settings.language': {
    en: 'Language',
    ar: 'اللغة'
  },
  'settings.english': {
    en: 'English',
    ar: 'الإنجليزية'
  },
  'settings.arabic': {
    en: 'Arabic',
    ar: 'العربية'
  },
  'settings.badges': {
    en: 'Badges',
    ar: 'الشارات'
  },
  'settings.points': {
    en: 'Points',
    ar: 'النقاط'
  },
  
  // Badges
  'badges.Recycling Master': {
    en: 'Recycling Master',
    ar: 'سيد إعادة التدوير'
  },
  'badges.Water Saver': {
    en: 'Water Saver',
    ar: 'موفر المياه'
  },
  'badges.Energy Expert': {
    en: 'Energy Expert',
    ar: 'خبير الطاقة'
  },
  'badges.Garden Guru': {
    en: 'Garden Guru',
    ar: 'خبير الحدائق'
  },
  'badges.Wildlife Friend': {
    en: 'Wildlife Friend',
    ar: 'صديق الحياة البرية'
  },
  'badges.Clean Air Hero': {
    en: 'Clean Air Hero',
    ar: 'بطل الهواء النظيف'
  },
  'badges.Ocean Protector': {
    en: 'Ocean Protector',
    ar: 'حامي المحيط'
  },
  'badges.Eco Investigator': {
    en: 'Eco Investigator',
    ar: 'محقق بيئي'
  },
  'badges.Climate Scholar': {
    en: 'Climate Scholar',
    ar: 'باحث المناخ'
  },
  'badges.Sustainable Architect': {
    en: 'Sustainable Architect',
    ar: 'مهندس معماري مستدام'
  },
  
  // Terra the Owl
  'terra.welcome': {
    en: "Hi! I'm Terra the Owl. Let's learn about the environment together!",
    ar: "مرحبًا! أنا تيرا البومة. هيا نتعلم عن البيئة معًا!"
  },
  'terra.chooseGame': {
    en: "Pick a game to start your environmental adventure!",
    ar: "اختر لعبة لبدء مغامرتك البيئية!"
  },
  
  // Intro Video
  'intro.welcome': {
    en: 'Welcome to Ecosphere!',
    ar: 'مرحبًا بك في البيئة!'
  },
  'intro.joinTerra': {
    en: 'Join Terra the Owl on an exciting journey to become an EcoHero!',
    ar: 'انضم إلى تيرا البومة في رحلة مثيرة لتصبح بطل البيئة!'
  },
  'intro.startAdventure': {
    en: 'Start Adventure',
    ar: 'ابدأ المغامرة'
  },
  'intro.skip': {
    en: 'Skip Intro',
    ar: 'تخطي المقدمة'
  },
  'intro.next': {
    en: 'Next',
    ar: 'التالي'
  },
  'intro.letsPlay': {
    en: "Let's Play!",
    ar: 'هيا نلعب!'
  },
  
  // Intro Steps
  'intro.step1.title': {
    en: 'Welcome to Ecosphere!',
    ar: 'مرحبًا بك في البيئة!'
  },
  'intro.step1.description': {
    en: 'A world where you can learn about the environment while having fun!',
    ar: 'عالم يمكنك فيه تعلم كل شيء عن البيئة أثناء الاستمتاع!'
  },
  'intro.step1.terra': {
    en: "Hoot! I'm Terra, your guide to becoming an EcoHero!",
    ar: 'مرحبًا! أنا تيرا، دليلك لتصبح بطل البيئة!'
  },
  'intro.step2.title': {
    en: '10 Fun Games',
    ar: '10 ألعاب ممتعة'
  },
  'intro.step2.description': {
    en: 'Explore different ways to help the environment through exciting challenges!',
    ar: 'استكشف طرقًا مختلفة لمساعدة البيئة من خلال تحديات مثيرة!'
  },
  'intro.step2.terra': {
    en: "From recycling to saving wildlife, there's so much to explore!",
    ar: 'من إعادة التدوير إلى إنقاذ الحياة البرية، هناك الكثير لاستكشافه!'
  },
  'intro.step3.title': {
    en: 'Collect Badges',
    ar: 'اجمع الشارات'
  },
  'intro.step3.description': {
    en: 'Complete activities to earn special EcoHero badges and track your progress!',
    ar: 'أكمل الأنشطة لكسب شارات بطل البيئة الخاصة وتتبع تقدمك!'
  },
  'intro.step3.terra': {
    en: 'Earn badges to show off your eco-knowledge!',
    ar: 'اكسب الشارات لإظهار معرفتك البيئية!'
  },
  'intro.step4.title': {
    en: 'Ready to Start?',
    ar: 'مستعد للبدء؟'
  },
  'intro.step4.description': {
    en: "Let's begin our adventure and save the planet together!",
    ar: 'لنبدأ مغامرتنا وننقذ الكوكب معًا!'
  },
  'intro.step4.terra': {
    en: "I can't wait to see what an amazing EcoHero you'll become!",
    ar: 'لا أستطيع الانتظار لأرى ما ستصبح عليه كبطل بيئة مذهل!'
  },
};

export const useLanguage = create<LanguageState>((set, get) => ({
  language: 'en',
  translations,
  setLanguage: (language: Language) => set({ language }),
  t: (key: string) => {
    const { language, translations } = get();
    if (!translations[key]) {
      console.warn(`Translation key not found: ${key}`);
      return key;
    }
    return translations[key][language] || key;
  }
}));