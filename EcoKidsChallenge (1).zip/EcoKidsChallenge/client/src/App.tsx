import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import IntroVideo from "./components/IntroVideo";
import MainMenu from "./components/MainMenu";
import GameSelection from "./components/GameSelection";
import Game from "./components/Game";
import AudioControls from "./components/AudioControls";
import LanguageToggle from "./components/LanguageToggle";
import { useAudio } from "./lib/stores/useAudio";
import { useProgress } from "./lib/stores/useProgress";
import { useLanguage } from "./lib/stores/useLanguage";

// Define app screens
type AppScreen = "intro" | "menu" | "game-selection" | "game";

function App() {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>("intro");
  const [selectedGame, setSelectedGame] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);
  const { setBackgroundMusic, setHitSound, setSuccessSound } = useAudio();
  
  // Initialize progress tracking
  const { initializeProgress } = useProgress();

  // Load audio assets and prepare app
  useEffect(() => {
    const loadAudio = async () => {
      try {
        // Load background music
        const bgMusic = new Audio("/sounds/background.mp3");
        bgMusic.loop = true;
        bgMusic.volume = 0.3;
        setBackgroundMusic(bgMusic);
        
        // Load sound effects
        const hitSfx = new Audio("/sounds/hit.mp3");
        setHitSound(hitSfx);
        
        const successSfx = new Audio("/sounds/success.mp3");
        setSuccessSound(successSfx);
        
        // Initialize progress data
        initializeProgress();
        
        setIsReady(true);
      } catch (error) {
        console.error("Failed to load audio:", error);
        // Continue without audio if it fails
        setIsReady(true);
      }
    };
    
    loadAudio();
  }, []);

  const handleIntroComplete = () => {
    setCurrentScreen("menu");
  };

  const handleGameSelect = (gameId: string) => {
    setSelectedGame(gameId);
    setCurrentScreen("game");
  };

  const handleBackToMenu = () => {
    setCurrentScreen("menu");
    setSelectedGame(null);
  };

  const handleShowGameSelection = () => {
    setCurrentScreen("game-selection");
  };

  // Get translation function
  const { t, language } = useLanguage();

  // Show loading state until assets are ready
  if (!isReady) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-emerald-100">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-emerald-700 mb-4">{t('app.title')}...</h1>
          <div className="w-64 h-4 bg-emerald-200 rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-emerald-500"
              initial={{ width: 0 }}
              animate={{ width: "100%" }}
              transition={{ duration: 2, ease: "easeInOut" }}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="h-screen w-screen overflow-hidden relative"
      dir={language === 'ar' ? 'rtl' : 'ltr'}
    >
      <AnimatePresence mode="wait">
        {currentScreen === "intro" && (
          <motion.div
            key="intro"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="h-full w-full"
          >
            <IntroVideo onComplete={handleIntroComplete} />
          </motion.div>
        )}

        {currentScreen === "menu" && (
          <motion.div
            key="menu"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="h-full w-full"
          >
            <MainMenu 
              onPlayClick={handleShowGameSelection} 
            />
          </motion.div>
        )}

        {currentScreen === "game-selection" && (
          <motion.div
            key="game-selection"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="h-full w-full"
          >
            <GameSelection 
              onGameSelect={handleGameSelect}
              onBackClick={handleBackToMenu}
            />
          </motion.div>
        )}

        {currentScreen === "game" && selectedGame && (
          <motion.div
            key="game"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="h-full w-full"
          >
            <Game
              gameId={selectedGame}
              onBackClick={handleBackToMenu}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Language toggle on all screens */}
      <div className={`absolute top-4 ${language === 'ar' ? 'left-4' : 'right-4'} z-50`}>
        <LanguageToggle />
      </div>

      {/* Audio controls visible on all screens except intro */}
      {currentScreen !== "intro" && (
        <div className={`absolute top-4 ${language === 'ar' ? 'right-4' : 'left-4'} z-50`}>
          <AudioControls />
        </div>
      )}
    </div>
  );
}

export default App;
