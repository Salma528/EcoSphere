import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import CharacterGuide from "./CharacterGuide";
import ProgressTracker from "./ProgressTracker";
import { useAudio } from "../lib/stores/useAudio";
import { useLanguage } from "../lib/stores/useLanguage";

// Import all game components
import RecyclingRanger from "../games/RecyclingRanger";
import WaterWarrior from "../games/WaterWarrior";
import EnergyExplorer from "../games/EnergyExplorer";
import GardenGuardian from "../games/GardenGuardian";
import WildlifeProtector from "../games/WildlifeProtector";
import CleanAirChampion from "../games/CleanAirChampion";
import OceanObserver from "../games/OceanObserver";
import EcoDetective from "../games/EcoDetective";
import WeatherWatcher from "../games/WeatherWatcher";
import GreenCityBuilder from "../games/GreenCityBuilder";

interface GameProps {
  gameId: string;
  onBackClick: () => void;
}

// Game instructions are now handled by the translation system

// Map game IDs to their corresponding components
const GAME_COMPONENTS: Record<string, React.ComponentType<any>> = {
  "recycling-ranger": RecyclingRanger,
  "water-warrior": WaterWarrior,
  "energy-explorer": EnergyExplorer,
  "garden-guardian": GardenGuardian,
  "wildlife-protector": WildlifeProtector,
  "clean-air-champion": CleanAirChampion,
  "ocean-observer": OceanObserver,
  "eco-detective": EcoDetective,
  "weather-watcher": WeatherWatcher,
  "green-city-builder": GreenCityBuilder
};

// Game phases
type GamePhase = "instructions" | "playing" | "celebration";

const Game: React.FC<GameProps> = ({ gameId, onBackClick }) => {
  const [phase, setPhase] = useState<GamePhase>("instructions");
  const [score, setScore] = useState(0);
  const [showBadge, setShowBadge] = useState<string | null>(null);
  const { playSuccess } = useAudio();
  const { t } = useLanguage();
  
  // Reset state when game changes
  useEffect(() => {
    setPhase("instructions");
    setScore(0);
    setShowBadge(null);
  }, [gameId]);
  
  // Get the appropriate game component
  const GameComponent = GAME_COMPONENTS[gameId];
  
  // Handle game completion
  const handleGameComplete = (finalScore: number) => {
    setScore(finalScore);
    setPhase("celebration");
    playSuccess();
  };
  
  // Handle starting the game
  const handleStartGame = () => {
    setPhase("playing");
  };
  
  // Handle badge earned notification
  const handleEarnBadge = (badgeName: string) => {
    setShowBadge(badgeName);
    playSuccess();
    
    // Hide badge notification after 3 seconds
    setTimeout(() => {
      setShowBadge(null);
    }, 3000);
  };
  
  return (
    <div className="h-full w-full relative bg-blue-50 flex flex-col">
      {/* Game header */}
      <header className="p-4 bg-emerald-500 text-white flex items-center justify-between shadow-md">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="bg-white/20 hover:bg-white/30 rounded-full p-2"
          onClick={onBackClick}
          aria-label="Back to menu"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6"></polyline>
          </svg>
        </motion.button>
        
        <h1 className="text-xl font-bold">
          {t(`games.${gameId}.title`)}
        </h1>
        
        <div className="w-8"></div> {/* Spacer for alignment */}
      </header>
      
      {/* Game content */}
      <div className="flex-1 relative overflow-hidden">
        {phase === "instructions" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 bg-gradient-to-br from-emerald-100 to-blue-100">
            <div className="absolute top-6 left-6">
              <CharacterGuide 
                text={t(`games.${gameId}.instructions`)}
                size="medium"
              />
            </div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white rounded-2xl p-6 shadow-xl max-w-md w-full text-center"
            >
              <h2 className="text-2xl font-bold text-emerald-700 mb-4">{t('game.howToPlay')}</h2>
              <p className="text-gray-700 mb-6">{t(`games.${gameId}.instructions`)}</p>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3 px-6 rounded-full text-lg shadow-md"
                onClick={handleStartGame}
              >
                {t('game.start')}
              </motion.button>
            </motion.div>
          </div>
        )}
        
        {phase === "playing" && (
          <div className="h-full w-full">
            <GameComponent 
              onComplete={handleGameComplete}
              onScoreChange={setScore}
            />
            
            {/* Progress tracker */}
            <div className="absolute top-4 right-4 w-64">
              <ProgressTracker 
                gameId={gameId} 
                score={score} 
                completionThreshold={1000} 
                onEarnBadge={handleEarnBadge}
              />
            </div>
          </div>
        )}
        
        {phase === "celebration" && (
          <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-emerald-100 to-blue-100">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="bg-white rounded-2xl p-6 shadow-xl max-w-md w-full text-center"
            >
              <h2 className="text-3xl font-bold text-emerald-700 mb-2">{t('game.greatJob')}</h2>
              <p className="text-xl text-emerald-600 mb-4">{t('game.completed')}</p>
              
              <div className="mb-6">
                <div className="text-5xl font-bold text-amber-500">{score}</div>
                <div className="text-gray-500">{t('game.finalScore')}</div>
              </div>
              
              <div className="flex space-x-4 justify-center">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg"
                  onClick={() => setPhase("playing")}
                >
                  {t('game.playAgain')}
                </motion.button>
                
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-2 px-4 rounded-lg"
                  onClick={onBackClick}
                >
                  {t('game.backToMenu')}
                </motion.button>
              </div>
            </motion.div>
          </div>
        )}
        
        {/* Badge notification */}
        {showBadge && (
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 50, opacity: 0 }}
            className="absolute bottom-10 left-1/2 transform -translate-x-1/2 bg-amber-100 border-2 border-amber-300 rounded-lg p-4 shadow-lg flex items-center space-x-3"
          >
            <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center text-2xl">
              🏆
            </div>
            <div>
              <div className="font-bold text-amber-800">{t('game.newBadge')}</div>
              <div className="text-amber-700">{t(`badges.${showBadge}`)}</div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Game;
