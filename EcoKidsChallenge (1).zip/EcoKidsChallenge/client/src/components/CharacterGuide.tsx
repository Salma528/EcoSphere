import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface CharacterGuideProps {
  text: string;
  position?: "left" | "right";
  size?: "small" | "medium" | "large";
  autoHide?: boolean;
  hideDelay?: number;
}

const CharacterGuide: React.FC<CharacterGuideProps> = ({
  text,
  position = "left",
  size = "medium",
  autoHide = false,
  hideDelay = 5000
}) => {
  const [isVisible, setIsVisible] = useState(true);
  const [isTalking, setIsTalking] = useState(true);

  // Automatically hide after delay if autoHide is true
  useEffect(() => {
    if (autoHide && isVisible) {
      const timer = setTimeout(() => {
        setIsVisible(false);
      }, hideDelay);
      
      return () => clearTimeout(timer);
    }
  }, [autoHide, isVisible, hideDelay]);
  
  // Talking animation effect
  useEffect(() => {
    if (isVisible) {
      const talkingInterval = setInterval(() => {
        setIsTalking(prev => !prev);
      }, 300);
      
      return () => clearInterval(talkingInterval);
    }
  }, [isVisible]);

  // Determine the size of the character
  const sizeClass = {
    small: "w-20 h-20",
    medium: "w-28 h-28",
    large: "w-36 h-36"
  }[size];
  
  const bubbleWidth = {
    small: "w-48",
    medium: "w-56",
    large: "w-64"
  }[size];

  return (
    <div className="relative">
      {/* Character */}
      <motion.div
        className={`${sizeClass} relative`}
        initial={{ y: 20 }}
        animate={{ y: 0 }}
        whileHover={{ scale: 1.05 }}
      >
        {/* Terra the Owl SVG */}
        <svg width="100%" height="100%" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
          {/* Body */}
          <circle cx="100" cy="100" r="70" fill="#8C6239" />
          <circle cx="100" cy="95" r="60" fill="#A67C52" />
          
          {/* Belly */}
          <ellipse cx="100" cy="110" rx="40" ry="35" fill="#D4B886" />
          
          {/* Eyes */}
          <circle cx="75" cy="80" r="20" fill="white" />
          <circle cx="125" cy="80" r="20" fill="white" />
          
          {/* Pupils - animate based on talking state */}
          <motion.circle 
            cx="75" 
            cy={isTalking ? "78" : "80"} 
            r="10" 
            fill="#000" 
          />
          <motion.circle 
            cx="125" 
            cy={isTalking ? "78" : "80"} 
            r="10" 
            fill="#000" 
          />
          
          {/* Beak */}
          <motion.path 
            d="M100,95 L85,105 L100,115 L115,105 Z" 
            fill="#FF9B42"
            animate={isTalking ? { scaleY: [1, 0.7, 1] } : {}}
            transition={{ repeat: Infinity, duration: 0.3 }}
          />
          
          {/* Wings */}
          <ellipse cx="50" cy="100" rx="20" ry="40" fill="#8C6239" />
          <ellipse cx="150" cy="100" rx="20" ry="40" fill="#8C6239" />
          
          {/* Eyebrows */}
          <path d="M60,68 Q75,60 90,68" stroke="#5D4037" strokeWidth="3" fill="transparent" />
          <path d="M110,68 Q125,60 140,68" stroke="#5D4037" strokeWidth="3" fill="transparent" />
          
          {/* Graduation Cap for wise character */}
          <rect x="70" y="40" width="60" height="10" fill="#333" />
          <rect x="75" y="30" width="50" height="10" fill="#333" />
          <rect x="85" y="20" width="30" height="10" fill="#333" />
          <rect x="125" y="40" width="20" height="3" fill="#333" />
          <circle cx="145" cy="45" r="5" fill="#333" />
        </svg>
      </motion.div>
      
      {/* Speech bubble */}
      <AnimatePresence>
        {isVisible && (
          <motion.div
            className={`absolute ${position === "left" ? "left-24" : "right-24"} top-2 ${bubbleWidth} bg-white rounded-2xl p-3 shadow-lg`}
            initial={{ opacity: 0, y: 10, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
          >
            {/* Speech bubble tail */}
            <div 
              className={`absolute ${position === "left" ? "left-0" : "right-0"} top-6 w-4 h-4 bg-white transform ${position === "left" ? "-translate-x-2" : "translate-x-2"} rotate-45`}
            />
            
            <p className="text-gray-800 font-medium text-sm">{text}</p>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Toggle button (only show if autoHide is false) */}
      {!autoHide && (
        <motion.button
          className="absolute -bottom-2 right-0 w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center shadow-md"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsVisible(!isVisible)}
        >
          <span className="text-white text-xs">
            {isVisible ? "✕" : "?"}
          </span>
        </motion.button>
      )}
    </div>
  );
};

export default CharacterGuide;
