import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import CharacterGuide from "./CharacterGuide";
import { useAudio } from "../lib/stores/useAudio";
import { useProgress } from "../lib/stores/useProgress";
import { useLanguage } from "../lib/stores/useLanguage";

interface MainMenuProps {
  onPlayClick: () => void;
}

const MainMenu: React.FC<MainMenuProps> = ({ onPlayClick }) => {
  const [showHelp, setShowHelp] = useState(false);
  const { backgroundMusic, isMuted, toggleMute } = useAudio();
  const { totalBadges, totalScore, getCompletedGamesCount } = useProgress();
  const { t } = useLanguage();
  
  // Start background music when main menu loads
  useEffect(() => {
    if (backgroundMusic && !isMuted) {
      backgroundMusic.play().catch(error => {
        console.log("Background music play prevented:", error);
      });
    }
    
    return () => {
      if (backgroundMusic) {
        backgroundMusic.pause();
      }
    };
  }, [backgroundMusic, isMuted]);

  return (
    <div className="h-full w-full relative overflow-hidden bg-gradient-to-b from-blue-400 to-green-300">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Clouds */}
        <motion.div
          className="absolute top-10 left-10 w-32 h-16 bg-white rounded-full opacity-80"
          animate={{
            x: [0, 100, 0],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        />
        <motion.div
          className="absolute top-20 right-20 w-40 h-20 bg-white rounded-full opacity-70"
          animate={{
            x: [0, -120, 0],
          }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
        />
        
        {/* Trees */}
        <div className="absolute bottom-0 left-10 w-24 h-40">
          <div className="w-6 h-20 bg-amber-800 absolute bottom-0 left-1/2 transform -translate-x-1/2"></div>
          <div className="w-24 h-24 bg-emerald-600 rounded-full absolute bottom-16"></div>
        </div>
        <div className="absolute bottom-0 right-10 w-24 h-36">
          <div className="w-6 h-16 bg-amber-800 absolute bottom-0 left-1/2 transform -translate-x-1/2"></div>
          <div className="w-24 h-24 bg-emerald-700 rounded-full absolute bottom-12"></div>
        </div>
      </div>
      
      {/* Main content */}
      <div className="absolute inset-0 flex flex-col items-center justify-between py-12 px-6">
        {/* Title */}
        <motion.div
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <h1 className="text-5xl sm:text-6xl font-bold text-white drop-shadow-lg mb-2">{t('app.title')}</h1>
          <p className="text-white text-xl opacity-90">{t('menu.subtitle')}</p>
        </motion.div>
        
        {/* Progress stats */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="bg-white/80 backdrop-blur-sm rounded-2xl p-4 w-full max-w-sm shadow-lg"
        >
          <h2 className="text-emerald-800 font-bold text-xl mb-3 text-center">{t('menu.title')}</h2>
          
          <div className="grid grid-cols-3 gap-2 mb-3">
            <div className="bg-emerald-100 rounded-xl p-3 text-center">
              <div className="text-2xl font-bold text-emerald-700">{getCompletedGamesCount()}</div>
              <div className="text-xs text-emerald-600">{t('game.score')}</div>
            </div>
            <div className="bg-amber-100 rounded-xl p-3 text-center">
              <div className="text-2xl font-bold text-amber-700">{totalBadges}</div>
              <div className="text-xs text-amber-600">{t('settings.badges')}</div>
            </div>
            <div className="bg-blue-100 rounded-xl p-3 text-center">
              <div className="text-2xl font-bold text-blue-700">{totalScore}</div>
              <div className="text-xs text-blue-600">{t('settings.points')}</div>
            </div>
          </div>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="w-full py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl text-lg shadow"
            onClick={onPlayClick}
          >
            {t('menu.play')}
          </motion.button>
        </motion.div>
        
        {/* Help button and character */}
        <motion.div
          initial={{ x: 100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="absolute bottom-10 left-10"
        >
          <CharacterGuide 
            text={showHelp ? t('terra.chooseGame') : t('terra.welcome')}
            autoHide={showHelp}
            hideDelay={6000}
          />
          
          {!showHelp && (
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              className="absolute bottom-0 right-0 w-10 h-10 bg-amber-500 rounded-full flex items-center justify-center shadow-md text-white font-bold"
              onClick={() => setShowHelp(true)}
            >
              ?
            </motion.button>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default MainMenu;
