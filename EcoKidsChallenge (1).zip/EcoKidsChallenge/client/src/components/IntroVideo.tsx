import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import CharacterGuide from "./CharacterGuide";
import { useLanguage } from "../lib/stores/useLanguage";

interface IntroVideoProps {
  onComplete: () => void;
}

interface IntroStep {
  id: number;
  titleKey: string;
  descriptionKey: string;
  visual: JSX.Element;
  terraTextKey: string;
  bgColor: string;
}

const IntroVideo: React.FC<IntroVideoProps> = ({ onComplete }) => {
  const [step, setStep] = useState(0);
  const [playing, setPlaying] = useState(false);
  const { t } = useLanguage();
  
  // Skip automatic progression in development mode
  const AUTO_ADVANCE = true;
  
  // Define the intro steps
  const INTRO_STEPS: IntroStep[] = [
    {
      id: 1,
      titleKey: "intro.step1.title",
      descriptionKey: "intro.step1.description",
      visual: (
        <div className="relative w-64 h-64">
          <motion.div 
            className="absolute inset-0 rounded-full bg-emerald-400 opacity-70"
            animate={{
              scale: [1, 1.1, 1],
            }}
            transition={{
              repeat: Infinity,
              duration: 4,
            }}
          />
          <motion.div 
            className="absolute inset-8 rounded-full bg-blue-400 opacity-70"
            animate={{
              scale: [1.1, 1, 1.1],
            }}
            transition={{
              repeat: Infinity,
              duration: 4,
            }}
          />
          <div className="absolute inset-0 flex items-center justify-center text-6xl">
            🌎
          </div>
        </div>
      ),
      terraTextKey: "intro.step1.terra",
      bgColor: "rgb(16, 150, 100)",
    },
    {
      id: 2,
      titleKey: "intro.step2.title",
      descriptionKey: "intro.step2.description",
      visual: (
        <div className="flex flex-wrap justify-center gap-3">
          {[...Array(10)].map((_, i) => (
            <motion.div
              key={i}
              className="w-16 h-16 bg-white rounded-lg flex items-center justify-center shadow-md"
              initial={{ rotateY: 180, opacity: 0 }}
              animate={{ 
                rotateY: 0, 
                opacity: 1,
                transition: { delay: i * 0.1 }
              }}
            >
              <span className="text-3xl" role="img" aria-label="game icon">
                {['🌿', '💧', '💡', '🌱', '🦊', '🌤️', '🌊', '🔍', '🌡️', '🏙️'][i]}
              </span>
            </motion.div>
          ))}
        </div>
      ),
      terraTextKey: "intro.step2.terra",
      bgColor: "rgb(56, 132, 196)",
    },
    {
      id: 3,
      titleKey: "intro.step3.title",
      descriptionKey: "intro.step3.description",
      visual: (
        <div className="flex items-center justify-center space-x-4">
          <motion.div
            className="flex flex-col items-center"
            animate={{
              y: [0, -10, 0],
            }}
            transition={{
              repeat: Infinity,
              duration: 2,
              ease: "easeInOut",
            }}
          >
            <div className="w-20 h-20 bg-yellow-500 rounded-full flex items-center justify-center shadow-lg border-4 border-yellow-300">
              <span className="text-4xl">🏆</span>
            </div>
            <div className="mt-2 bg-yellow-400 text-yellow-800 px-3 py-1 rounded-full text-sm font-bold">
              Eco Master
            </div>
          </motion.div>
          
          <motion.div
            className="flex flex-col items-center"
            animate={{
              y: [-10, 0, -10],
            }}
            transition={{
              repeat: Infinity,
              duration: 2,
              ease: "easeInOut",
            }}
          >
            <div className="w-20 h-20 bg-blue-500 rounded-full flex items-center justify-center shadow-lg border-4 border-blue-300">
              <span className="text-4xl">💧</span>
            </div>
            <div className="mt-2 bg-blue-400 text-blue-800 px-3 py-1 rounded-full text-sm font-bold">
              Water Hero
            </div>
          </motion.div>
        </div>
      ),
      terraTextKey: "intro.step3.terra",
      bgColor: "rgb(86, 60, 170)",
    },
    {
      id: 4,
      titleKey: "intro.step4.title",
      descriptionKey: "intro.step4.description",
      visual: (
        <motion.div 
          className="w-40 h-40 bg-white rounded-full flex items-center justify-center shadow-lg"
          animate={{
            scale: [1, 1.1, 1],
            boxShadow: [
              "0 10px 15px -3px rgba(0, 0, 0, 0.1)",
              "0 20px 25px -5px rgba(0, 0, 0, 0.1)",
              "0 10px 15px -3px rgba(0, 0, 0, 0.1)",
            ]
          }}
          transition={{
            repeat: Infinity,
            duration: 2,
            ease: "easeInOut",
          }}
        >
          <span className="text-6xl">🚀</span>
        </motion.div>
      ),
      terraTextKey: "intro.step4.terra",
      bgColor: "rgb(236, 72, 153)",
    },
  ];
  
  useEffect(() => {
    if (AUTO_ADVANCE && playing) {
      const timer = setTimeout(() => {
        if (step < INTRO_STEPS.length - 1) {
          setStep(step + 1);
        } else {
          onComplete();
        }
      }, 4000); // Auto advance after 4 seconds
      
      return () => clearTimeout(timer);
    }
  }, [step, playing, onComplete]);
  
  const handleStart = () => {
    setPlaying(true);
  };
  
  const handleSkip = () => {
    onComplete();
  };
  
  const handleNext = () => {
    if (step < INTRO_STEPS.length - 1) {
      setStep(step + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-b from-blue-200 to-green-100 relative overflow-hidden">
      {!playing ? (
        // Intro start screen
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center text-center p-4"
        >
          <h1 className="text-4xl sm:text-5xl font-bold text-emerald-700 mb-6">{t('intro.welcome')}</h1>
          <p className="text-xl mb-8 text-emerald-800 max-w-md">
            {t('intro.joinTerra')}
          </p>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-emerald-500 text-white font-bold py-3 px-6 rounded-full text-xl shadow-lg mb-4"
            onClick={handleStart}
          >
            {t('intro.startAdventure')}
          </motion.button>
          
          <button 
            className="text-emerald-700 underline"
            onClick={handleSkip}
          >
            {t('intro.skip')}
          </button>
        </motion.div>
      ) : (
        // Intro animation sequence
        <div className="w-full h-full flex flex-col relative">
          <div className="absolute top-4 right-4 z-10">
            <button 
              className="bg-white/70 hover:bg-white px-4 py-2 rounded-full text-emerald-700 font-bold"
              onClick={handleSkip}
            >
              {t('intro.skip')}
            </button>
          </div>
          
          {/* Background animations */}
          <motion.div 
            className="absolute inset-0 z-0"
            animate={{
              backgroundColor: INTRO_STEPS[step].bgColor,
            }}
            transition={{ duration: 1 }}
          >
            {/* Add subtle moving background elements */}
            <motion.div 
              className="absolute w-24 h-24 rounded-full bg-white/10 top-1/4 left-1/4"
              animate={{
                x: [0, 20, 0],
                y: [0, -20, 0],
              }}
              transition={{
                repeat: Infinity,
                duration: 5,
                ease: "easeInOut",
              }}
            />
            <motion.div 
              className="absolute w-16 h-16 rounded-full bg-white/10 bottom-1/4 right-1/3"
              animate={{
                x: [0, -30, 0],
                y: [0, 10, 0],
              }}
              transition={{
                repeat: Infinity,
                duration: 7,
                ease: "easeInOut",
              }}
            />
          </motion.div>
          
          {/* Content area */}
          <div className="flex-1 flex flex-col items-center justify-center p-6 relative z-10">
            <motion.div
              key={INTRO_STEPS[step].id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="text-center max-w-xl"
            >
              <h2 className="text-3xl font-bold mb-4 text-white">{t(INTRO_STEPS[step].titleKey)}</h2>
              <p className="text-xl mb-6 text-white/90">{t(INTRO_STEPS[step].descriptionKey)}</p>
              
              {/* Visual element */}
              <motion.div
                className="h-48 sm:h-64 mb-8 flex items-center justify-center"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.3, duration: 0.5 }}
              >
                {INTRO_STEPS[step].visual}
              </motion.div>
            </motion.div>
            
            {/* Terra character */}
            <div className="absolute bottom-16 left-8 sm:left-16 z-20">
              <CharacterGuide text={t(INTRO_STEPS[step].terraTextKey)} />
            </div>
          </div>
          
          {/* Navigation */}
          <div className="h-16 flex justify-between items-center px-6 relative z-10">
            {/* Progress indicators */}
            <div className="flex space-x-1">
              {INTRO_STEPS.map((_, i) => (
                <div 
                  key={i} 
                  className={`w-3 h-3 rounded-full ${step === i ? 'bg-white' : 'bg-white/40'}`}
                />
              ))}
            </div>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-white text-emerald-700 font-bold py-2 px-6 rounded-full shadow-lg"
              onClick={handleNext}
            >
              {step < INTRO_STEPS.length - 1 ? t('intro.next') : t('intro.letsPlay')}
            </motion.button>
          </div>
        </div>
      )}
    </div>
  );
};

export default IntroVideo;
