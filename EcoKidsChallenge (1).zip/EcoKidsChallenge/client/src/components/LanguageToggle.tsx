import { Button } from "./ui/button";
import { useLanguage } from "../lib/stores/useLanguage";

const LanguageToggle: React.FC = () => {
  const { language, setLanguage, t } = useLanguage();

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'ar' : 'en');
  };

  return (
    <Button
      variant="outline"
      onClick={toggleLanguage}
    >
      {t('settings.language')}: {language === 'en' ? t('settings.arabic') : t('settings.english')}
    </Button>
  );
};

export default LanguageToggle;