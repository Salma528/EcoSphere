import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import CharacterGuide from "./CharacterGuide";
import { useProgress } from "../lib/stores/useProgress";
import { useLanguage } from "../lib/stores/useLanguage";

interface GameSelectionProps {
  onGameSelect: (gameId: string) => void;
  onBackClick: () => void;
}

const GameSelection: React.FC<GameSelectionProps> = ({ onGameSelect, onBackClick }) => {
  const [showInfo, setShowInfo] = useState<string | null>(null);
  const { games, getGameData } = useProgress();
  const { t } = useLanguage();
  
  // All available games
  const gameIds = [
    "recycling-ranger",
    "water-warrior",
    "energy-explorer",
    "garden-guardian",
    "wildlife-protector",
    "clean-air-champion",
    "ocean-observer",
    "eco-detective",
    "weather-watcher",
    "green-city-builder"
  ];
  
  // Game icons for visual representation
  const gameIcons: Record<string, string> = {
    "recycling-ranger": "♻️",
    "water-warrior": "💧",
    "energy-explorer": "💡",
    "garden-guardian": "🌱",
    "wildlife-protector": "🦊",
    "clean-air-champion": "🌤️",
    "ocean-observer": "🌊",
    "eco-detective": "🔍",
    "weather-watcher": "🌡️",
    "green-city-builder": "🏙️"
  };

  return (
    <div className="h-full w-full bg-gradient-to-br from-emerald-100 to-blue-100 flex flex-col p-4 sm:p-8">
      <header className="flex items-center justify-between mb-6">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center px-3 py-2 bg-white/70 backdrop-blur rounded-full shadow"
          onClick={onBackClick}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
            <polyline points="15 18 9 12 15 6"></polyline>
          </svg>
          <span>{t('app.back')}</span>
        </motion.button>
        
        <h1 className="text-2xl sm:text-3xl font-bold text-emerald-800">{t('gameSelection.title')}</h1>
        
        <div className="w-10" /> {/* Spacer for alignment */}
      </header>
      
      <div className="flex-1 overflow-y-auto py-2">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
          {gameIds.map((gameId) => {
            const gameData = getGameData(gameId);
            const gameProgress = games[gameId];
            const completed = gameProgress?.completed || false;
            const highScore = gameProgress?.highScore || 0;
            
            return (
              <motion.div
                key={gameId}
                whileHover={{ scale: 1.03, y: -5 }}
                className="relative"
              >
                {/* Game card */}
                <div 
                  className={`relative bg-white rounded-xl shadow-lg overflow-hidden flex flex-col cursor-pointer ${
                    completed ? "ring-2 ring-emerald-500" : ""
                  }`}
                  onClick={() => onGameSelect(gameId)}
                >
                  {/* Game icon */}
                  <div className="h-32 sm:h-36 bg-gradient-to-br from-blue-100 to-emerald-100 flex items-center justify-center">
                    <span className="text-5xl">{gameIcons[gameId]}</span>
                  </div>
                  
                  {/* Game info */}
                  <div className="p-3">
                    <h3 className="font-bold text-emerald-800 mb-1">{gameData.title}</h3>
                    <div className="flex justify-between items-center text-xs text-gray-600">
                      <span>{t('game.score')}: {highScore}</span>
                      <button 
                        className="p-1 hover:bg-gray-100 rounded-full"
                        onClick={(e) => {
                          e.stopPropagation();
                          setShowInfo(showInfo === gameId ? null : gameId);
                        }}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <circle cx="12" cy="12" r="10"></circle>
                          <line x1="12" y1="16" x2="12" y2="12"></line>
                          <line x1="12" y1="8" x2="12.01" y2="8"></line>
                        </svg>
                      </button>
                    </div>
                  </div>
                  
                  {/* Completed badge */}
                  {completed && (
                    <div className="absolute top-2 right-2 bg-emerald-500 text-white rounded-full w-6 h-6 flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                  )}
                </div>
                
                {/* Game info popup */}
                <AnimatePresence>
                  {showInfo === gameId && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="absolute top-full left-0 right-0 z-10 mt-2 bg-white rounded-lg shadow-xl p-3"
                    >
                      <p className="text-sm text-gray-700 mb-2">{gameData.description}</p>
                      <button 
                        className="text-xs text-emerald-600 hover:text-emerald-700 font-medium"
                        onClick={(e) => {
                          e.stopPropagation();
                          setShowInfo(null);
                          onGameSelect(gameId);
                        }}
                      >
                        {t('game.start')}
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </div>
      
      {/* Terra Character Guide */}
      <div className="absolute bottom-4 right-4">
        <CharacterGuide 
          text={t('terra.chooseGame')}
          position="right"
          autoHide={true}
          hideDelay={8000}
        />
      </div>
    </div>
  );
};

export default GameSelection;
