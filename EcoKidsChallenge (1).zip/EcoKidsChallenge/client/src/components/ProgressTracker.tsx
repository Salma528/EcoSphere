import { motion } from "framer-motion";
import { useProgress, GameProgress } from "../lib/stores/useProgress";

interface ProgressTrackerProps {
  gameId: string;
  score: number;
  completionThreshold: number;
  onEarnBadge?: (badgeName: string) => void;
}

const ProgressTracker: React.FC<ProgressTrackerProps> = ({
  gameId,
  score,
  completionThreshold,
  onEarnBadge
}) => {
  const { games, getGameData, updateGameProgress } = useProgress();
  const gameData = getGameData(gameId);
  const gameProgress = games[gameId] || { completed: false, score: 0, badges: [], highScore: 0, lastPlayed: null };
  
  // Check if current score has earned a new badge
  const checkForBadge = (currentScore: number, progress: GameProgress) => {
    // Define badge thresholds
    const badgeThresholds = [
      { score: completionThreshold * 0.25, name: "Bronze" },
      { score: completionThreshold * 0.5, name: "Silver" },
      { score: completionThreshold * 0.75, name: "Gold" },
      { score: completionThreshold, name: "Platinum" }
    ];
    
    // Check each threshold to see if a new badge has been earned
    for (const badge of badgeThresholds) {
      const badgeName = `${badge.name} ${gameData.title}`;
      if (currentScore >= badge.score && !progress.badges.includes(badgeName)) {
        // Add badge to player's collection
        progress.badges.push(badgeName);
        
        // Call the onEarnBadge callback if provided
        if (onEarnBadge) {
          onEarnBadge(badgeName);
        }
      }
    }
    
    return progress;
  };
  
  // Update progress when score changes
  const saveProgress = () => {
    // Mark as completed if score exceeds threshold
    const completed = score >= completionThreshold;
    
    // Check for new badges
    let updatedProgress = { ...gameProgress, score, completed };
    updatedProgress = checkForBadge(score, updatedProgress);
    
    // Save progress
    updateGameProgress(gameId, updatedProgress);
  };
  
  // Calculate progress percentage
  const progressPercentage = Math.min(100, Math.round((score / completionThreshold) * 100));

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-md">
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-bold text-emerald-800">{gameData.title} Progress</h3>
        <button 
          className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full"
          onClick={saveProgress}
        >
          Save Progress
        </button>
      </div>
      
      <div className="w-full h-4 bg-gray-200 rounded-full overflow-hidden mb-2">
        <motion.div 
          className="h-full bg-emerald-500"
          initial={{ width: 0 }}
          animate={{ width: `${progressPercentage}%` }}
          transition={{ duration: 0.5 }}
        />
      </div>
      
      <div className="flex justify-between text-xs text-gray-600">
        <span>Current Score: {score}</span>
        <span>Goal: {completionThreshold}</span>
      </div>
      
      {/* Badges */}
      {gameProgress.badges.length > 0 && (
        <div className="mt-3">
          <h4 className="text-xs font-semibold text-gray-700 mb-1">Earned Badges:</h4>
          <div className="flex flex-wrap gap-1">
            {gameProgress.badges.map((badge, index) => (
              <div 
                key={index}
                className="px-2 py-1 bg-amber-100 text-amber-800 rounded-full text-xs"
              >
                {badge}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ProgressTracker;
